<!DOCTYPE html>
<html lang="en">
    
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta name="description" content="Navigate The Complex Telecom Market With Connected2Fiber’s Network Finder - Network Finder">
        <meta name="author" content="Connected2Fiber" />
        <!-- SITE TITLE -->
        <title>Navigate The Complex Telecom Market With Connected2Fiber’s Network Finder - Network Finder</title>
        <!-- STYLESHEETS -->
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="css/animate.css" rel="stylesheet">
        <link href="css/style.css?v=1" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">

        <!-- FAVICON  -->
        <link rel="icon" href="/admin/img/shared/favicon.png">
    </head>
    <body>
        <!-- PRELOADER -->
        <div id="preloader">
            <div class="spinner"></div>
        </div>
		
        <!-- MAIN NAV -->
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header page-scroll">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-menu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <!-- MAIN NAV LOGO -->
                    <a class="logo page-scroll" href="/"><img src="//p6.zdassets.com/hc/settings_assets/1086441/200323487/t1xK5wLNxfHtRXum4xBEUA-SmallLogo.png" 
                    class="img-responsive" alt="" height="500px"></a>
                </div>
                <div class="collapse navbar-collapse" id="main-menu">
                    <!-- MAIN NAV LINKS -->
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="page-scroll" href="#header">Home</a></li> 
						<li><a class="page-scroll" href="#features">Features</a>
						<li><a class="page-scroll" href="#brief">Brief</a></li>
                        <!--<li><a class="page-scroll" href="#video">Video</a></li>-->
                        <li><a class="page-scroll" href="#appho_price_table">Pricing</a></li>
                        <li><a class="page-scroll" href="#team">Team</a></li>
                        <li><a class="page-scroll" href="#client">Clients</a></li>
                        <li><a class="page-scroll" href="#contact">Contact</a></li>
                        <?php
                        session_start(); 
                        if (isset($_SESSION['uname'])) {
							echo '<li><a class="page-scroll" href="/includes/logout.php">Logout</a></li>';
						} else {
							echo '<li><a class="page-scroll" href="login.php">Login</a></li>';
						}
                        ?>
                    </ul>
                    <!-- END MAIN NAV LINKS -->
                </div>
            </div>
        </nav>
        <!-- END MAIN NAV -->
        <!-- HEADER -->
        <header id="header">
            <!-- HEADING, FEATURES AND REGISTRATION FORM CONTAINER -->
	<div class="container">
	
	 <div class="row">
		
		<div class="col-md-7 col-sm-7">
	
			<!-- left heading -->
            <div class="intro-text">
                 <h1 class="intro-lead-in">Navigate The Complex Telecom Market With Connected2Fiber’s Network Finder</h1>
                    <!--<span class="intro-heading">Appho is a great way to show effectiveness of your apps & softwares. </span>-->
                    <div class="header-buttons">
                        <a href="#appho_price_table" class="primary-button page-scroll">Buy Now</a>
                        <a href="#features" class="primary-button button-inverse page-scroll hidden-xs">Learn More</a>
                      </div> 
					</div>
                 </div>
			 
			
			<!-- RIGHT - MOCKUP -->
          <div class="row">
			<div class="col-md-5 col-sm-5">
			 <div class="header-dashboard wow fadeInDown"  data-wow-delay=".1s"> 
                        <img src="img/connect.png" class="dashboard" style="margin-bottom:30%; visibility:hidden;" alt="">
                     </div>
					</div>
			     </div>
			<!-- /END - MOCKUP -->
	   </div>
	  </div>
	  
	<!-- /END HEADING, FEATURES AND REGISTRATION FORM CONTAINER -->
            <div id="headerbackground"></div>
        </header>
        <!-- END HEADER -->
        <!-- SERVICES -->
        <section id="features" class="features-bg">
            <div class="container">
               
                    <!-- SERVICES HEADING -->
                    <div class="text-center">
                        <h2 class="section-heading wow fadeInUp" data-wow-delay=".1s">Network Finder Features</h2>                 
                    </div>
                    <!-- END SERVICES HEADING -->
                
                <div class="row">
                    <!-- SINGLE FEATURE BOX -->
			<div class="col-lg-4 col-md-4 col-sm-6">
				<div class="feature">
					<div class="icon">
					<i class="fa fa-venus-double"></i>
					</div>
					<h4>Market Intelligence</h4>
					<p>
						Understand the network industry landscape, including network profiles for ILECs, CLECs, Utilities, Municipalities. See what products they offer and where they connect.
					</p>
				</div>
			  </div>
			
			<!-- SINGLE FEATURE BOX -->
			<div class="col-lg-4 col-md-4 col-sm-6">
				<div class="feature">
					<div class="icon">
						<i class="fa fa-smile-o"></i>
					</div>
					<h4>Location Intelligence</h4>
					<p>
						Find out who is connected where. LEC, cable, competitive fiber. Location intelligence in Network Sonar can enrich and analyze location data for enhanced business insight, specific for the world of fiber optics.
					</p>
				</div>
			  </div>

			<!-- SINGLE FEATURE BOX -->
			<div class="col-lg-4 col-md-4 col-sm-6">
				<div class="feature">
					<div class="icon">
						<i class="fa fa-rocket"></i>
					</div>
					<h4>Powerful Search</h4>
					<p>
						Simple, intuitive and fast. Address or network based lookups. Get answers to help you navigate the market. Who has what where.
					</p>
				</div>
			</div>
		</div>	

		
		<!-- FEATURES ROW 2 -->
		<div class="row">
			
			<!-- SINGLE FEATURE BOX -->
			<div class="col-lg-4 col-md-4 col-sm-6">
				<div class="feature">
					<div class="icon">
						<i class="fa fa-folder-open-o"></i>
					</div>
					<h4>Actionable Insights</h4>
					<p>
						Data matters and every industry has their own unique insights that help understand who to partner with and who not to.
					</p>
				</div>
			</div>

			<!-- SINGLE FEATURE BOX -->
			<div class="col-lg-4 col-md-4 col-sm-6">
				<div class="feature">
					<div class="icon">
						<i class="fa fa-map-o"></i>
					</div>
					<h4>Sales Acceleration</h4>
					<p>
						Help your clients get answers they need on who connects the locations that matter to them. Find the right partners to execute.
					</p>
				</div>
			</div>

			<!-- SINGLE FEATURE BOX -->
			<div class="col-lg-4 col-md-4 col-sm-6">
				<div class="feature">
					<div class="icon">
						<i class="fa fa-comments-o"></i>
					</div>
					<h4>Knowledge At Your Fingertips</h4>
					<p>
						Don’t see the answer, ask, complete access to trained network industry veterans to help you navigate design, partner and pricing decisions. 
					</p>
				</div>
			  </div>	
			</div>
		</div>	  
      </div> 
    </section>
        <!-- END FEATURES -->
		
        <!--BRIEF -->
        <section id="brief">
		 <div class="gray-bg brief-features"> 
            <div class="container">
                <div class="row">
				<div class="brief-awesomeness brief-top">
                    <div class="col-lg-7 col-md-7 col-sm-7">
			
			<!-- DETAILS WITH LIST -->
			<div class="brief text-left">
				
				<!-- HEADING -->
				<h2>Discover Connected2Fiber’s Network Finder</h2>
				<div class="colored-line pull-left">
				</div>
				
				<!-- TEXT -->
				<p>
					Connected2Fiber is the leading sales and marketing intelligence platform for the connectivity industry. Enabling a marketplace to improve transparency, speed and effectiveness. Network Finder is designed for partners, top sales professionals and network buyers.
				</p>
				
				<!-- FEATURE LIST -->
				<ul class="feature-list-2">
					
					<!-- FEATURE -->
					<li>
					<!-- ICON -->
					<div class="icon-container pull-left">
						<i class="fa fa-rocket"></i>
					</div>
					<!-- DETAILS -->
					<div class="details pull-left">
						<h6>Easy to search</h6>
						<p>
							Single line, enter and you get fast, accurate results. Coverage, company information, products and interconnects on demand. 
						</p>
					</div>
					</li>
					
						<!-- FEATURE -->
					<li>
					<!-- ICON -->
					<div class="icon-container pull-left">
						<i class="fa fa-cart-plus"></i>
					</div>
					<!-- DETAILS -->
					<div class="details pull-left">
						<h6>Network Industry Transparency</h6>
						<p>
							See the market from both a company perspective and a location perspective. Access neutral intelligence to help see over 2,500 network operators and understand where they operate. 
						</p>
					</div>
					</li>
					
					<!-- FEATURE -->
					<li>
					<!-- ICON -->
					<div class="icon-container pull-left">
						<i class="fa fa-cloud-download"></i>
					</div>
					<!-- DETAILS -->
					<div class="details pull-left">
						<h6>24/7 Help Desk</h6>
						<p>
							Get feedback on carriers. Ask who to call? Ask what protocol would be best? Where to interconnect two networks? You need answers, we have them. 
						</p>
					</div>
					</li>
					
				</ul>
			
		   </div>
		</div> <!-- /END DETAILS WITH LIST -->
		
			<div class="col-lg-5 col-md-5 col-sm-5">
			
			<!-- SCREENSHOT -->
			
			<div class="right-screenshot pull-right wow fadeInRight" data-wow-delay=".1s">
				<img src="img/connect.png" alt="Feature" class="img-responsive">
			</div>
		   </div> 	<!-- END SCREENSHOT -->
       </div>
	     
		</div> <!-- End row -->
			
			  </div>
			 </div>  <!-- End brief features top -->
		<?php
		/*	 
        <div class="brief-features-down">
		  <div class="container">
		    <div class="row">
			  <div class="col-lg-5 col-md-5 col-sm-5">
			
			<!-- SCREENSHOT -->
			
			<div class="left-screenshot pull-left">
				<img src="img/mobile2.png" alt="Feature" class="img-responsive">
			</div>
		   </div> 	<!-- END SCREENSHOT -->
		   
		       <div class="col-lg-7 col-md-7 col-sm-7">
			       <div class="brief-awesomeness-down">                   
			
			<!-- DETAILS WITH LIST -->
			<div class="brief text-right">
				
				<!-- HEADING -->
				<h2>Awesome Key features</h2>
				<div class="colored-line pull-left">
				</div>
				
				<!-- TEXT -->
				<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut.
				</p>
				
				<!-- FEATURE LIST -->
				<ul class="feature-list-2">
					
					<!-- FEATURE -->
					<li>
					<!-- ICON -->
					<div class="icon-container pull-left">
						<i class="fa fa-flag"></i>
					</div>
					<!-- DETAILS -->
					<div class="details pull-left">
						<h6>Clean Design</h6>
						<p>
							Lorem lean startup ipsum product market fit customer development acquihire technical cofounder.
						</p>
					</div>
					</li>
					<li>
					<!-- ICON -->
					<div class="icon-container pull-left">
						<i class="fa fa-rocket"></i>
					</div>
					<!-- DETAILS -->
					<div class="details pull-left">
						<h6>Bootstrap 3x</h6>
						<p>
							Lorem lean startup ipsum product market fit customer development acquihire technical cofounder.
						</p>
					</div>
					</li>	
					<li>
					<!-- ICON -->
					<div class="icon-container pull-left">
						<i class="fa fa-signal"></i>
					</div>
					<!-- DETAILS -->
					<div class="details pull-left">
						<h6>Font Awesome</h6>
						<p>
							Lorem lean startup ipsum product market fit customer development acquihire technical cofounder.
						</p>
					</div>
					</li>		
					
				</ul>
			
		   </div>
		</div> <!-- /END DETAILS WITH LIST -->
			   </div>
			</div>
		  </div>
         </div>	<!-- END brief-features-down -->
         */
         ?>		 
        </section>
        <!-- END FEATURES -->
        <!-- VIDEO -->
        <?php /**
        <section id="video" class="parallax">
            <div class="overlay parallax"></div>
            <div class="container">
                <div class="row">
                    <!-- VIDEO HEADING -->
                    <div class="col-lg-12 text-center">
                        <h2 class="section-heading">Our video</h2>
                    </div>
                    <!-- END VIDEO HEADING -->
                </div>
                <div class="row">
                    <div class="video-container">                  
                        <a data-toggle="modal" data-target="#video-modal" data-backdrop="true">
                        <img src="img/video/video.png" class="video-image" alt="">
                        <span class="play-video"><span class="fa fa-play"></span></span></a>
                    </div>
                    <!-- VIDEO SOCIALS -->
                    <div class="video-socials">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-linkedin"></i></a>
                    </div>
                    <!-- END VIDEO SOCIALS -->
                </div>
            </div>
        </section>
        <!-- VIDEO POPUP -->
        <div class="modal fade video-modal" id="video-modal" role="dialog">
            <div class="modal-content">
                <div class="row">
					<iframe width="712" height="400" src="https://www.youtube.com/embed/4gqR6Sy7s4E"  allowfullscreen></iframe>
                </div>
            </div>
        </div>
        <!-- END VIDEO POPUP -->
        <!-- END VIDEO -->
        */
        ?>

        <!-- PRICING TABLES -->
		
        <section id="appho_price_table">		
		 <div class="pricing ">
            <div class="container"> 
            <div class="row">
                <div class="col-md-12">
                    <!--PRICE HEADING START-->
                    <div class="price-heading clearfix">
                        <h2>Choose Your Packages</h2>
                    </div>
                    <!--//PRICE HEADING END-->
                </div>
            </div>
        </div>
	 </div>
        <div class="container">
            
            <!--BLOCK ROW START-->
            <div class="row">
                <div class="col-md-4">
                
                	<!--PRICE CONTENT START-->
                    <div class="appho_content clearfix wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
                        
                        <!--PRICE HEAD START-->
                        <div class="appho_price_head">
                            <h3>GOLD</h3>
                        </div>
                        <!--//PRICE HEAD END-->
                        
                        <!--PRICE START-->
                        <div class="appho_price">
                        	<p>
                                <span class="sign">$</span>
                                <span class="currency">99</span>
                                <span class="month">/MON</span>
                            </p>    
                        </div>
                        <!--//PRICE END-->
                        
                        <!--FEATURE LIST START-->
                        <div class="appho_feature_list">
                        	<ul>
                                <li><i class="fa fa-life-ring"></i>Network Sales Acceleration Platform</li>	
                                <li><i class="fa fa-database"></i>Market Transparency</li>
                                <li><i class="fa fa-floppy-o"></i>Unlimited Location Searches</li>								
                                <li><i class="fa fa-envelope"></i>Network Operator Profiles</li>								
                            	<li><i class="fa fa-cloud-download"></i>Interconnection Points</li>
                                <li><span><i class="fa fa-floppy-o"></i>Help Desk</span></li>							
                                <li><i class="fa fa-database"></i>24/7 Technical Support</li>
                                <li><span><i class="fa fa-envelope"></i>Pricing Benchmark Help Desk</span></li>
                            </ul>
                        </div>
                        <!--//FEATURE LIST END-->
                        
                        <!--PRICE BUTTON START-->
                        <div class="appho_btn clearfix">
                           <a class="" href="signup.php?p=1">Sign Up Now</a>
                        	
                        </div>
                        <!--//PRICE BUTTON END-->
                        
                    </div>
                    <!--//PRICE CONTENT END-->
                        
                </div>
                <div class="col-md-4">
                
                	<!--PRICE CONTENT START-->
                    <div class="appho_content active appho-standard clearfix wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0"> 
                        <!--PRICE HEAD START-->
                        <div class="appho_price_head">
                            <h3> Platinum </h3>
                        </div>
                        <!--//PRICE HEAD END-->
                        
                        <!--PRICE START-->
                        <div class="appho_price">
                        	<p>
                                <span class="sign">$</span>
                                <span class="currency">199</span>
                                <span class="month">/MON</span>
                            </p>    
                        </div>
                        <!--//PRICE END-->
					  
                        <!--FEATURE LIST START-->
                        <div class="appho_feature_list">
                        	<ul>
                                <li><i class="fa fa-life-ring"></i>Network Sales Acceleration Platform</li>	
                                <li><i class="fa fa-database"></i>Market Transparency</li>
                                <li><i class="fa fa-floppy-o"></i>Unlimited Location Searches</li>								
                                <li><i class="fa fa-envelope"></i>Network Operator Profiles</li>								
                            	<li><i class="fa fa-cloud-download"></i>Interconnection Points</li>
                                <li><i class="fa fa-floppy-o"></i>Help Desk</li>							
                                <li><i class="fa fa-database"></i>24/7 Technical Support</li>
                                <li><span><i class="fa fa-envelope"></i>Pricing Benchmark Help Desk</span></li>
                            </ul>
                        </div>
                        <!--//FEATURE LIST END-->
                        
                        <!--PRICE BUTTON START-->
                        <div class="appho_btn clearfix">
                        	<a class="" href="signup.php?p=2">Sign Up Now</a>
                        </div>
                        <!--//PRICE BUTTON END-->
                        
                    </div>
                    <!--//PRICE CONTENT END-->
                        
                </div>
                <div class="col-md-4">
                
                	<!--PRICE CONTENT START-->
                    <div class="appho_content clearfix wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
                        
                        <!--PRICE HEAD START-->
                        <div class="appho_price_head">
                            <h3>Team</h3>
                        </div>
                        <!--//PRICE HEAD END-->
                        
                        <!--PRICE START-->
                        <div class="appho_price">
                        	<p>
                                <span class="sign">$</span>
                                <span class="currency">590</span>
                                <span class="month">/MON</span>
                            </p>    
                        </div>
                        <!--//PRICE END-->
                        
                        <!--FEATURE LIST START-->
                        <div class="appho_feature_list">
                        	<ul>
                                <li><i class="fa fa-life-ring"></i>Network Sales Acceleration Platform</li>	
                                <li><i class="fa fa-database"></i>Market Transparency</li>
                                <li><i class="fa fa-floppy-o"></i>Unlimited Location Searches</li>								
                                <li><i class="fa fa-envelope"></i>Network Operator Profiles</li>								
                            	<li><i class="fa fa-cloud-download"></i>Interconnection Points</li>
                                <li><i class="fa fa-floppy-o"></i>Help Desk</li>							
                                <li><i class="fa fa-database"></i>24/7 Technical Support</li>
                                <li><i class="fa fa-envelope"></i>Pricing Benchmark Help Desk</li>
                            </ul>
                        </div>
                        <!--//FEATURE LIST END-->
                        
                        <!--PRICE BUTTON START-->
                        <div class="appho_btn clearfix">
                        	<a class="" href="signup.php?p=3">Sign Up Now</a>
                        </div>
                        <!--//PRICE BUTTON END-->
                        
                    </div>
                    <!--//PRICE CONTENT END-->
                        
                </div>
            </div>	
            <!--//BLOCK ROW END-->
         </div>  
        </section>
        <!-- PRICING TABLES -->
        <!-- TESTIMONIALS -->
        <?php
        /*
        <section id="testimonials" class="testimonials-bg">
            <div class="container">
                <div class="row">
                    <div class="slider">
                        <!-- TESTIMONIALS 1 -->
                        <div class="tt-content">
                            <h3><span class="tt-quote">“</span><span class="tt-quote tt-quote-right">”</span>Boast your Apps & Softwares with appho that is a great way to show effectiveness of your apps & softwares.</h3>
                            <div class="tt-container">
                                <h4 >Maickel Jackson</h4>
                                <span class="content">UX/UI Designer, Envato</span>
                            </div>
                        </div>
                        <!-- TESTIMONIALS 2 -->
                        <div class="tt-content">
                            <h3 ><span class="tt-quote">“</span><span class="tt-quote tt-quote-right">”</span>Boast your Apps & Softwares with appho that is a great way to show effectiveness of your apps & softwares.</h3>
                            <div class="tt-container">
                                <h4 >Maickel Jackson</h4>
                                <span class="content">UX/UI Designer, Envato</span>
                            </div>
                        </div>
                        <!-- TESTIMONIALS 3 -->
                        <div class="tt-content">
                            <h3 ><span class="tt-quote">“</span><span class="tt-quote tt-quote-right">”</span>Boast your Apps & Softwares with appho that is a great way to show effectiveness of your apps & softwares.</h3>
                            <div class="tt-container">
                                <h4 >Maickel Jackson</h4>
                                <span class="content">UX/UI Designer, Envato</span>
                            </div>
                        </div>
                    </div>
                    <!-- TESTIMONIALS IMAGE CAPTIONS -->
                    <div class="tt-images">
                        <div class="tt-image"><img width="80" height="80" src="img/testimonials/testimonial1.png" alt="team"></div>
                        <div class="tt-image"><img width="80" height="80" src="img/testimonials/testimonial2.png" alt="team"></div>
                        <div class="tt-image"><img width="80" height="80" src="img/testimonials/testimonial3.png" alt="team"></div>
                    </div>
                    <!-- END TESTIMONIALS IMAGE CAPTIONS -->
                 </div>
               </div>
        </section>
        */
        ?> 
        <!-- END TESTIMONIALS -->
  <!-- =========================
     SECTION TEAM 
============================== -->
<section id="team" class="team-bg">

<div class="container">
	
	<div class="row">
				 <div class="team-header">
						 <h2>Meet Our Team</h2>
						
						</div>     <!-- End Team header -->
					
					  <!-- Team Member -->
    				<div class="col-md-3 col-sm-6">
					  <div class="team-member">
					     <img src="img/ben.png" alt="team" />
					     <h6>Ben Edmond</h6>
						 <p>CEO</p>
						 <p class="email_add">ben@connected2fiber.com</p>
						 <!--<a href="#"><i class="fa fa-facebook"></i></a>
						 <a href="#"><i class="fa fa-twitter"></i></a>
						 <a href="#"><i class="fa fa-linkedin"></i></a>-->
					  </div>     					 
    				</div>    <!-- End Team member --> 
					 
					   <!--Team Member -->
    				<div class="col-md-3 col-sm-6">
					  <div class="team-member">
					     <img src="img/brandon.png" alt="team" />
					     <h6>Brandon Pemberton</h6>
						 <p>VP of Customer</p>
						 <p class="email_add">brandon@connected2fiber.com</p>
						 <!--<a href="#"><i class="fa fa-facebook"></i></a>
						 <a href="#"><i class="fa fa-twitter"></i></a>
						 <a href="#"><i class="fa fa-linkedin"></i></a>-->
					  </div>     					 
    				</div>    <!-- End Team member --> 
					 
					  <!-- End Team Member -->
    				<div class="col-md-6 col-sm-6">
					  <div class="team-member">
					     <img class="customer_support" src="img/slide_7.3.png" alt="team" />
					     <h6>Danielle Escano</h6>
						 <p>24/7 support</p>
						 <p class="email_add">descano@connected2fiber.com</p>
						 <!--<a href="#"><i class="fa fa-facebook"></i></a>
						 <a href="#"><i class="fa fa-twitter"></i></a>
						 <a href="#"><i class="fa fa-linkedin"></i></a>-->
					  </div>     					 
    				</div>    <!-- End Team member --> 
					
					  <!-- End Team Member -->
    				<!--<div class="col-md-3 col-sm-6">
					  <div class="team-member">
					     <img src="img/team/team4.jpg" alt="team" />
					     <h6>Jonathon Due</h6>
						 <p>Product Manager</p>
						 <a href="#"><i class="fa fa-facebook"></i></a>
						 <a href="#"><i class="fa fa-twitter"></i></a>
						 <a href="#"><i class="fa fa-linkedin"></i></a>
					  </div>     					 
    				</div>-->    <!-- End Team member --> 
					
    			</div>
	
</div> <!-- /END CONTAINER -->

</section>
        <!-- CLIENTS -->
		
 <section id="client">	

		<!--- Clients logo -->
        <div id="clients" class="gray-bg">		
            <div class="container">
			 <h2 class="client-heading">Our Happy Clients</h2> 
                <div class="slider">
                    <div class="clients-content">
                        <a href="#"><img style="position:relative;top:0px;" src="img/global-capacity.png" alt=""></a>
                    </div>
                    <div class="clients-content">
                        <a href="#"> <img src="img/sudden-link.png" alt=""></a>
                    </div>
                    <div class="clients-content">
                        <a href="#"> <img style="position:relative;top:8px;" src="img/first-light.png" alt=""></a>
                    </div>
                    <div class="clients-content">
                        <a href="#"> <img src="img/usa-fiber.png" alt=""></a>
                    </div>
                 </div>
               </div>
			  </div>
        </section>

        <!-- END CLIENTS -->
		
        <!-- SUBSCRIBE -->
<section class="subscribe-section" id="section7">			
		
		<!-- MAILCHIMP SUBSCRIBE FORM -->
		
	   <div class="subscribe-section">  
		<div class="container">
		 <div class="row">
		  <div class="col-md-12 col-sm-12">

            <h3>Subscribe to our mailing list</h3>
			
			<form action="//connected2fiber.us14.list-manage.com/subscribe/post?u=d2259345e5ed6f936517fd0e2&amp;id=2470fc73be" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="subscription-form mailchimp form-inline validate" target="_blank" novalidate>
				<input type="email" name="EMAIL" required id="subscriber-email" placeholder="Email Address" class="form-control input-box">
				<input type="text" name="FNAME" id="subscriber-email" placeholder="First Name" class="form-control input-box">
				<input type="text" name="LNAME" id="subscriber-email" placeholder="Last Name" class="form-control input-box">
				 <div style="position: absolute; left: -5000px;" aria-hidden="true">
				<input type="text" name="b_d2259345e5ed6f936517fd0e2_2470fc73be" tabindex="-1" value="">
				</div>
				<button name="subscribe" type="submit" id="subscribe-button" class="btn standard-button">Subscribe</button>
			</form>
		</div>
		<!-- /END SUBSCRIPTION FORM -->
		
		   
	    
	   </div>  <!-- /END ROW -->
	</div> 
</div>  <!-- /END CONTAINER -->

</section>
        <!-- END SUBSCRIBE -->
        <!-- CONTACT -->
        <section id="contact">
                <!-- GOOGLE MAP-->
            <div class="container">
				<div class="col-md-6">
				<h2>Head Office</h2>
				<div class="row" style="font-size: 17px; line-height: 2.2;">
				<h4>Get a demo: 508-202-1807</h4> 
				<h4>Inquiries</h4>
				105b South Street
				Hopkinton, MA 01748
				<br/>sales@connected2fiber.com
				<br/>
				Tel: 508-202-1807
				<br/>
				Fax: 508-202-1807
				<br/><br/>
				To apply for a job with Connected2Fiber, please send a cover letter together with your C.V. to: HR@connected2fiber.com
               </div>
               </div>
                <div class="contact-form-container">
                    <!-- CONTACT HEADING -->
                    <div class="row">
                        <h2 class="section-heading  wow fadeInUp" data-wow-delay=".1s">Contact Us</h2>
                    </div>
                    <!-- END CONTACT HEADING -->
                    <div class="row ">
                        <!-- CONTACT FORM -->
                        <form name="sentMessage" id="contactForm" novalidate>
                            <div class="row">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Name" id="entername" required data-validation-required-message="Please enter your name.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group pull-right">
                                    <input type="email" class="form-control" placeholder="Email" id="emailname" required data-validation-required-message="Please enter your email address.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group form-textarea">
                                    <textarea class="form-control" placeholder="Message" id="message" required data-validation-required-message="Please enter a message."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="clearfix"></div>
                                <div class="text-center">
                                    <div id="success"></div>
                                    <button type="submit" class="btn btn-xl">Send Message</button>
                                </div>
                            </div>
                          </form>
                        <!-- END CONTACT FORM -->
                    </div>
                </div>
            </div>
        </section>
        <!-- END CONTACT -->
        <!-- =========================
  <!---Footer Section-->
<?php include("includes/footer.php"); ?>
<!-- /END Footer -->
		
		
        <!-- SCRIPTS -->
        <!-- jQuery -->
        <script src="js/jquery-1.12.3.min.js"></script>
        <!-- Easing -->		
        <script src="js/jquery.easing.min.js"></script>
        <!-- Bootstrap -->		
        <script src="js/bootstrap.min.js"></script>
        <!-- smoothscroll  -->
        <script src="js/smoothscroll.js"></script>
        <!-- piechart  -->
        <script src="js/jquery.easytabs.min.js"></script>
        <!-- sliders -->
        <script src="js/owl.carousel.min.js"></script>
		 <!-- counterup -->
		<script src="js/jquery.countTo.js"></script>
		 <!-- wow js -->
		<script src="js/wow.min.js"></script>
        <!-- contact form -->
        <script src="js/jqBootstrapValidation.js"></script>
        <script src="js/contact_me.js"></script>
        <!-- google map -->
        <!--<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>-->
        <!-- custom script -->
        <script src="js/scripts.js"></script>
    </script>
    </body>



</html>
