<?php 
include("includes/config.php");

if(isset($_GET['p'])) {
  if ($_GET['p'] == 1) {
      $package = 99;
  } else if ($_GET['p'] == 2) {
      $package = 199;
  } else {
      $package = 590;
  }
  $_SESSION['package_amount'] =$package;
  header("location:signup.php");
}

if(isset($_POST['submit'])){

$_SESSION['v_email']= $_POST['u_email'];
$_SESSION['v_uname'] = $_POST['u_name'];
$_SESSION['v_pswd']  = md5($_POST['u_pswd']);
	

if(isset($_SESSION['v_email'])){

echo '
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Paypal</title>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
</head>
<body onload="submitPaypal();">
	<form class="paypal" action="payments.php" method="post" id="submitPayPal">
		<input type="hidden" name="cmd" value="_xclick" />
		<input type="hidden" name="no_note" value="1" />
		<input type="hidden" name="lc" value="US" />
		<input type="hidden" name="currency_code" value="USD" />
		<input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest" />
		<input type="hidden" name="first_name" value="'.$_SESSION['v_uname'].'"  />
		<input type="hidden" name="last_name" value="'.$lname.'"  />
		<input type="hidden" name="payer_email" value="'.$_SESSION['v_email'].'"  />
		<input type="hidden" name="item_number" value="1" / >
		<input type="hidden" name="package" value="'.$_SESSION['package_amount'].'" / >
	</form>
	
<script type="text/javascript">
function submitPaypal(){
$("#submitPayPal").submit();
}
</script>	
</body>
</html>
';
exit();
}
	
}

 


?>


<!doctype html>
<html>
<head>

<script type="text/javascript" src="js/jquery-1.12.3.min.js"></script>
<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	
<script>

function payapl_submit(){
    var button = document.getElementById('loginSubmit');
    button.form.submit();

}

$( document ).ready( function () {
			$( "#user_signup" ).validate( {
				rules: {
					u_email:{
					   required: true,
					   email:true	
					},
					u_pswd:
					{
						required: true,
						minlength: 6
						
					},
					
					c_pswd:
					{
						equalTo : "#u_pswd"
						
						
					},
					
				},
				messages: {
					u_name: {
						required: "Please Provide Your Username",
						minlength: "Your Username must consist of at least 3 characters",
						minlength: "Your Username must not Excced From 6 characters"
					},
					
					u_email:{
							required: 'Please Provide Your Email ',
							email: 'Please Enter a Valid Email Address'	
						},
			
					u_pswd: {
						required: "Please Provide a password",
						minlength: "Your password must be at least 6 characters long",
					},	
			
					c_pswd: {
						
						equalTo: "Please Enter the same password as above"
					},		
				},
				
				
			} );
		} );

</script>

<meta charset="utf-8">
<title>Sign Up - Connected2Fiber</title>




        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="css/animate.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">

        <!-- FAVICON  -->
        <link rel="icon" href="/admin/img/shared/favicon.png">


</head>

<body>
  <!-- MAIN NAV -->
        <nav class="navbar navbar-default navbar-fixed-top" style="background-color:#4C545F">
            <div class="container">
                <div class="navbar-header page-scroll">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-menu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <!-- MAIN NAV LOGO -->
                    <a class="logo page-scroll" href="/"><img src="//p6.zdassets.com/hc/settings_assets/1086441/200323487/t1xK5wLNxfHtRXum4xBEUA-SmallLogo.png" 
                    class="img-responsive" alt="" height="500px"></a>
                </div>
                <div class="collapse navbar-collapse" id="main-menu">
                    <!-- MAIN NAV LINKS -->
                   <ul class="nav navbar-nav navbar-right">
                        <li><a class="page-scroll" href="/index.php#header">Home</a></li> 
						<li><a class="page-scroll" href="/index.php#features">Features</a>
						<li><a class="page-scroll" href="/index.php#brief">Brief</a></li>
                        <!--<li><a class="page-scroll" href="#video">Video</a></li>-->
                        <li><a class="page-scroll" href="/index.php#appho_price_table">Pricing</a></li>
                        <li><a class="page-scroll" href="/index.php#team">Team</a></li>
                        <li><a class="page-scroll" href="/index.php#client">Clients</a></li>
                        <li><a class="page-scroll" href="/index.php#contact">Contact</a></li>
                        <?php
                        session_start(); 
                        if (isset($_SESSION['uname'])) {
							echo '<li><a class="page-scroll" href="/includes/logout.php">Logout</a></li>';
						} else {
							echo '<li><a class="page-scroll" href="login.php">Login</a></li>';
						}
                        ?>
                    </ul>
                    <!-- END MAIN NAV LINKS -->
                </div>
            </div>
        </nav>
        <!-- END MAIN NAV -->
          <!-- START HEADER -->
  <header>
 	<div class="container">
	   <div class="row">
		  <div class="col-md-12 col-sm-12">
	      </div>
			<br /><br /><br />
	   </div>
	</div>
	<div id="headerbackground"></div>
 </header>
        <!-- END HEADER -->
  
 <!-- START LOGIN -->
        <section  class="features-bg">
           <form action="signup.php" method="post" name="user_signup" id="user_signup"> 
            <div class="container">
                   <div class="text-center">
                        <h2 class="section-heading wow fadeInUp" data-wow-delay=".1s">Sign Up</h2>                 
                    </div>
                     <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                           
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                           <div class="row">
                             <div class="col-lg-3">
                             </div>
                             <div class="col-lg-6">
                              <div style="margin-bottom:35px;">
                                
                                   <input type="text" name="u_name" id="u_name" class="form-control" 
                                   placeholder="Please Enter your Name" />
                                 
                                 
                                                               
                             </div>
                            </div>
                            <div class="col-lg-3">
                            </div>
                          </div>  
                         
                           <div class="row">
                             <div class="col-lg-3">
                             </div>
                             <div class="col-lg-6">
                              <div style="margin-bottom:35px;">
                                
                                   <input type="email" name="u_email" id="u_email" class="form-control" 
                                   placeholder="Please Enter your Email" />
                                 
                                 
                                                               
                             </div>
                            </div>
                            <div class="col-lg-3">
                            </div>
                          </div>  
                         
                          <div class="row">
                             <div class="col-lg-3">
                             </div>
                             <div class="col-lg-6">
                              <div style="margin-bottom:35px;">
                                
                                   <input type="password" name="u_pswd" id="u_pswd" class="form-control" 
                                   placeholder="Please Enter your Password"  />
                                
                             </div>
                            </div>
                            <div class="col-lg-3">
                            </div>
                          </div>  
                          <div class="row">
                             <div class="col-lg-3">
                             </div>
                             <div class="col-lg-6">
                              <div style="margin-bottom:35px;">
                                
                                   <input type="password" name="c_pswd" id="c_pswd" class="form-control" 
                                   placeholder="Please Re-type Password to Confirm" />
                                
                             </div>
                            </div>
                            <div class="col-lg-3">
                            </div>
                          </div>  
                          
                          <div class="row">
                             <div class="col-lg-7">
                             </div>
                             <div class="col-lg-2">
                              <div style="margin-bottom:35px;text-align:center">
                                
                                   <input type="submit" name="submit" id="submit" value="Sign Up" class="btn btn-xl" />
                                
                             </div>
                            </div>
                            <div class="col-lg-3">
                            </div>
                          </div>  
                          
                          
                        </div>
  		           </div>
		    </div>	  
     </form>     
    </section>
        <!-- END FEATURES -->
		
     
		


      
        
<!---Footer Section-->
<?php include("includes/footer.php"); ?>
<!-- END FOOTER -->        
        
        
        <!-- SCRIPTS -->
        	
      
        <!-- Bootstrap -->		
        <script src="js/bootstrap.min.js"></script>
        <!-- smoothscroll  -->
        <script src="js/smoothscroll.js"></script>
        <!-- piechart  -->
        <script src="js/jquery.easytabs.min.js"></script>
        <!-- sliders -->
        <script src="js/owl.carousel.min.js"></script>
		 <!-- counterup -->
		<script src="js/jquery.countTo.js"></script>
		 <!-- wow js -->
		<script src="js/wow.min.js"></script>
        <!-- contact form -->
        
        <script src="js/scripts.js"></script>
      
</body>
 <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" name="payment_paypal1" id="payment_paypal1">

 <input type="hidden" name="business" value="test@yahoo.com" />
 <input type="hidden" name="cmd" value="_xclick" />
 <input type="hidden" name="item_name" value="Total Amount" />
 <input type="hidden" name="amount" value="<?php echo $_GET['p']; ?>" />
 <input type="hidden" name="currency_code" value="$" />
 <input type="hidden" name="return" value="Success.php" />
 <input type="hidden" name="cancel_return" value="cancel.php" />
 <input type="submit" name="submit" id="loginSubmit"  style="background-color: #B32122;display:none; border-style: none;
 border-radius: 6px;color: white;" class="btn" value="Checkout With Paypal"> <br/><br/>

</form>
     <!-- custom script -->
      
</html>
<?php mysql_close($conection);  ?>
