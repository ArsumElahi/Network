<?php 
include("includes/config.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Paypal - Connected2Fiber</title>




        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="css/animate.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">

        <!-- FAVICON  -->
        <link rel="icon" href="img/shared/favicon.png">


</head>
<body onload="document.getElementById('loginSubmit').click();">
  <!-- MAIN NAV -->
        <nav class="navbar navbar-default navbar-fixed-top" style="background-color:#4C545F">
            <div class="container">
                <div class="navbar-header page-scroll">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-menu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <!-- MAIN NAV LOGO -->
                    <a class="logo page-scroll" href="#header"><img src="admin/img/shared/dch-logo.png" 
                    class="img-responsive" alt="" height="500px"></a>
                </div>
                <div class="collapse navbar-collapse" id="main-menu">
                    <!-- MAIN NAV LINKS -->
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="page-scroll" href="index.php#header">Home</a></li> 
						<li><a class="page-scroll" href="index.php#features">Features</a>
						<li><a class="page-scroll" href="index.php#brief">Brief</a></li>
                        <li><a class="page-scroll" href="index.php#video">Video</a></li>
                        <li><a class="page-scroll" href="index.php#appho_price_table">Pricing</a></li>
                        <li><a class="page-scroll" href="index.php#team">Team</a></li>
                        <li><a class="page-scroll" href="index.php#client">Clients</a></li>
                        <li><a class="page-scroll" href="index.php#contact">Contact</a></li>
                        <li><a class="page-scroll" href="#login">Login</a></li>
                    </ul>
                    <!-- END MAIN NAV LINKS -->
                </div>
            </div>
        </nav>
        <!-- END MAIN NAV -->
          <!-- START HEADER -->
  <header>
 	<div class="container">
	   <div class="row">
		  <div class="col-md-12 col-sm-12">
	      </div>
			<br /><br /><br />
	   </div>
	</div>
	<div id="headerbackground"></div>
 </header>
        <!-- END HEADER -->
  
 <!-- START LOGIN -->
     <section  class="features-bg">
          
          <img src="img/loading.gif"  class="center-block img-responsive"/>
           <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" name="payment_paypal1" id="payment_paypal1">
                 <input type="hidden" name="business" value="test@yahoo.com" />
                 <input type="hidden" name="cmd" value="_xclick" />
                 <input type="hidden" name="item_name" value="Total Amount" />
                 <input type="hidden" name="amount" value="<?php echo $_SESSION['package_amount']; ?>" />
                 <input type="hidden" name="currency_code" value="USD" />
                 <input type="hidden" name="return" value="http://mapmyinvoice.com/success.php" />
                 <input type="hidden" name="cancel_return" value="http://mapmyinvoice.com/cancel.php" />
                 <input type="submit" name="submit" id="loginSubmit"  
                 style="background-color: #B32122;display:none; border-style: none;
                 border-radius: 6px;color: white;" class="btn" value="Checkout With Paypal"> 

          </form>
    
          
    </section>
        <!-- END FEATURES -->
		
     
		


      
        
<!---Footer Section-->
<?php include("includes/footer.php"); ?>
<!-- END FOOTER -->        
        
        
        <!-- SCRIPTS -->
        	
      
        <!-- Bootstrap -->		
        <script src="js/bootstrap.min.js"></script>
        <!-- smoothscroll  -->
        <script src="js/smoothscroll.js"></script>
        <!-- piechart  -->
        <script src="js/jquery.easytabs.min.js"></script>
        <!-- sliders -->
        <script src="js/owl.carousel.min.js"></script>
		 <!-- counterup -->
		<script src="js/jquery.countTo.js"></script>
		 <!-- wow js -->
		<script src="js/wow.min.js"></script>
        <!-- contact form -->
        
        <script src="js/scripts.js"></script>
      
</body>
 
     <!-- custom script -->

</html>