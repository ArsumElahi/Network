<?php include("../includes/checkSession.php"); ?>

<!DOCTYPE HTML>

<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if IE 9]>    <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js" lang="en" prefix="og: http://ogp.me/ns#">
<!--<![endif]-->

<head><meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />




	<title>Equinix -Connected2Fiber</title>


<meta name="description" content="Learn more about and browse list of data centers from Equinix on Connected2Fiber" />


<meta name="author" content="Connected2Fiber" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
<meta name="viewport" content="width=device-width" />


	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:site" content="@Connected2Fiber" />
	<meta property="og:title" content="Search Equinix Data Centers" />
	<meta property="og:description" content="Search Connected2Fiber to find information on industry leading data center providers." />
	<meta property="og:image" content="https://www.datacenterhawk.com/img/twitter/providers.png" />
	<meta property="og:url" content="https://www.datacenterhawk.com/providers/equinix" />


<link rel="stylesheet" href="css/jquery.rating.css" />
<link rel="icon" type="image/png" href="img/shared/favicon.png" />



<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap-edited.min.css" />

<!-- Optional theme -->
<link rel="stylesheet" href="css/bootstrap-theme.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="css/dataTables.fixedColumns.min.css" />

<link rel="stylesheet" href="css/main-1091214527.css" />

<!-- Latest compiled and minified JavaScript -->
<script src="js/jquery-2.1.1.min.js"></script>

<script src="js/jquery-ui.min.js"></script>
<script src="js/jquery.ui.touch-punch.min.js"></script>

<script src="js/bootstrap.min.js"></script>

<script src="js/libs/jquery.dataTables.min.js"></script>
<script src="js/libs/dataTables.fixedColumns.min.js"></script>

<script src="js/libs/modernizr-2.5.3.min.js"></script>

<script src="js/heap-analytics.js"></script>

<script src="js/hawk.js"></script>
<script src="js/util.js"></script>
<script src="js/media.js"></script>
<script src="js/mapbox.utils.js"></script>

<script src="js/mapbox.js"></script>
<link href="css/mapbox.css" rel="stylesheet" />
<script src="js/NonTiledLayer.js"></script>
<script src="js/NonTiledLayer.WMS.js"></script>

<script src="js/svg4everybody.js"></script>
<script src="js/jquery.placeholder.js"></script>
<!-- Google Tag Manager -->
<noscript>
	<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KRVGLX" height="0" width="0" style="display: none; visibility: hidden"></iframe>
</noscript>
<script>/*<![CDATA[*/(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NTMD2G');/*]]>*/</script>
<!-- End Google Tag Manager -->

<!-- TypeKit for ProximaNova font -->
<script src="https://use.typekit.net/aan4rbc.js"></script>
<script>
	try {
		Typekit.load();
	} catch (e) {
	}
	svg4everybody();
</script>

<script type="text/javascript" src="js/lib-1305157643.js"></script>

<script type="text/javascript" src="js/heatclinic-119894065.js"></script>
</head>

<body id="catalog-provider">
	<div class="hawk-content-wrapper texture-bg">
	 <!-- Start Header----->
	         <?php  include("includes/header.php");?>
     <!-- End Header----->
<div><button id="noAccessModalToggle" data-toggle="modal" data-target="#noAccessModal" class="hidden"></button>
<div class="modal hawk-modal" id="noAccessModal" tabindex="-1" role="dialog" aria-labelledby="noAccessModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title" id="noAccessModalLabel"></h4>
			</div>
			<div class="modal-body">
				<h4 class="message ur">Upgrade now for access</h4>
				<h4 class="message sr">Subscribe now for access</h4>
				<h4 class="message sm">Select a market to begin using Fiber Products</h4>
				<span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#search"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#zoom"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#scope"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#compare"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#finance"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#research"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#swap"></use></svg></span>
				<form action="/support" class="message ur">
					<button>CONTACT US</button>
				</form>
				<form action="/plans" class="message sr">
					<button>SIGN UP</button>
				</form>
				<form action="/account/select-market" class="message sm">
					<button>SELECT MARKET</button>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	// <![CDATA[

	var isIE = /* @cc_on!@ */false || !!document.documentMode;

	var param = null;

	var HawkModal = {
		toggle : function(type) {
			$(".message", $("#noAccessModal")).hide();
			$("." + type, $("#noAccessModal")).show();
			$('#noAccessModalToggle').click();
		}
	};

	$('#noAccessModal').on('hidden.bs.modal', function () {
		if (window.location.search.indexOf("?r=") == 0) {
			window.location.search = "";
		}
	});

	$(function() {
		if (param && param.length > 0) {
			param = param[0];
			if (param == "sr" || param == "ur") {
				HawkModal.toggle(param);

			}
		}
	});
	//]]>
</script></div>
<div><button id="registerModalToggle" data-toggle="modal" data-target="#register-modal" class="hidden"></button>
<div class="modal hawk-modal" id="register-modal" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<h4>Register below to join now!</h4>
				<div class="form-wrapper">
					<form id="registration-form" method="POST" action="/register">
						<div class="col-md-12">
							<label>Company Email</label>
							<input type="email" id="customer.emailAddress" name="customer.emailAddress" />
							<div class="col-md-6">
								<label>First Name</label>
								<input type="text" id="customer.firstName" name="customer.firstName" />
							</div>
							<div class="col-md-6">
								<label>Last Name</label>
								<input type="text" id="customer.lastName" name="customer.lastName" />
							</div>
							<label>Password</label>
							<input type="password" id="password" name="password" />
							<label>Confirm Password</label>
							<input type="password" id="passwordConfirm" name="passwordConfirm" />
							<label class="tos-label"><input id="modal-confirm-tos" type="checkbox" /><span>
							I agree to Connected2Fiber's<a href="/terms-of-service" target="_blank">Terms of Service and Privacy Policy</a></span></label>
							<button type="submit" id="modal-register-button" class="register-button" data-dismiss="modal" disabled="disabled">Register</button>
						</div>
					<input type="hidden" name="csrfToken" value="ZWNA-PFM4-9V28-6CLZ-COOO-952I-571Y-QWBG" /></form>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	//<![CDATA[

	$(".register-link, .register-text").click(function() {
		$("#registerModalToggle").click();
	});

	$("#modal-register-button").click(function() {
		$("#registration-form").submit();
	})

	$("#modal-confirm-tos").click(function() {
		$("#modal-register-button").attr("disabled", !this.checked);
	});



	//]]>
</script></div>
	<div class="xs-menu">
		<ul>
			<li>
				<a href="/products">Products</a>
			</li>
			<li>
				<a href="/register">Register</a>
			</li>
			<li>
				<a href="/blog">Blog</a>
			</li>
			<li>
				<a href="/about">About Us</a>
			</li>
			<li>
				<a href="/support">Contact Us</a>
			</li>
			<li>
				<hr />
			</li>
			<li>
				<p>sales@connected2fiber.com</p>
			</li>
			<li>
				<p>508-202-1807</p>
			</li>
			<li class="address">
				<p>105b South Street</p>
				<p>Hopkinton, MA 01748</p>
			</li>
		</ul>
	</div>


		<div class="hawk-content" role="main">




<div id="provider-content">
	<div id="loader" class="hide"></div>
	<div id="provider-map"></div>
	<div class="container">
		<div class="row">
			<div class="provider-search-bar">
				<div class="input-group search-bar">
					<input id="provider-search" type="text" name="provider-search" class="form-control" placeholder="Search by Provider" value="Equinix" />
					<span class="input-group-addon search-magnifier"><svg><use xlink:href="/img/shared/icons.svg#search"></use></svg></span>
				</div>
			</div>
		</div>
	</div>

	<div class="container content-padding">
		<div class="col-sm-3 provider-info">
			<h4>Equinix</h4>
			<p>One Lagoon Drive</p>
			<p>Redwood City, California 94065</p>
			<a target="_blank" href="http://www.equinix.com">www.equinix.com</a>
			<ul class="details">
				<li><p>Type: Public</p></li>
				<li><p>Ticker: NASDAQ: EQIX</p></li>
				<li><p>Number of Employees: 1001-5000</p></li>
				<li><p>Year Founded: 1998</p></li>
			</ul>
			<img src="cmsstatic/dcproviders/219/Equinix_Logo_000001.jpg" />
			<h2>Services Available</h2>
			<ul class="checklist">
				<li>Cabinets</li>
				<li>Cages</li>
				<li>Cloud</li>
				<li>Colocation</li>
				<li class="disabled">Dedicated Infrastructure</li>
				<li class="disabled">Managed Hosting</li>
				<li class="disabled">Managed Services</li>
				<li>Internet Exchange</li>
				<li>Private Suites</li>
			</ul>
		</div>
		<div class="col-sm-9 facilities">

				<h4>Company Information</h4>
				<p>Equinix is a global data center company providing colocation, interconnection, and connectivity services to users. The California-based company has over 100 data centers in 32 markets throughout the world, and gives access to over 450+ cloud providers in their portfolio. Equinix IBX data centers offer reliability, power density, security and recovery services, while in secure space that is efficiently operated. Equinix pricing is typically higher priced due to the ecosystems created in Equinix facilities and access to cloud and connectivity services. The company officially became a REIT (real estate investment trust) in Q1 2015.</p>

			<div id="owned-facilities">
			</div>
		</div>
	</div>
	<button id="contactProviderModalToggle" data-toggle="modal" data-target="#contactProviderModal" class="hidden"></button>
	<div class="modal hawk-modal" id="contactProviderModal" tabindex="-1" role="dialog" aria-labelledby="contactProviderModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="contactProviderModalLabel"></h4>
				</div>
				<div class="modal-body contact-provider">
					<h4>
						<span class="icon-bg"><svg>
									<use xlink:href="/img/shared/icons.svg#email"></use></svg></span> EMAIL Equinix <svg id="contact-help" data-trigger="hover" data-placement="bottom" data-content="Submitting this form sends an email directly to the provider. Your information is key confidential and is not shared with any other parties"><use xlink:href="/img/shared/icons.svg#question"></use></svg>
					</h4>
					<br />
					<h5>Fill in your information below and click Send to request more information from Equinix</h5>
					<br />
					<div class="form-wrapper">
						<form id="contact-provider-form">
							<input type="hidden" name="facilityId" />
							<div class="col-md-12">
								<input type="text" id="fullName" placeholder="Your Name" name="fullName" value="" />
								<input type="email" id="emailAddress" placeholder="Your Email" name="emailAddress" value="" />
								<input type="text" id="phoneNumber" placeholder="Your Phone Number" name="phoneNumber" value="" />
							</div>
						<input type="hidden" name="csrfToken" value="ZWNA-PFM4-9V28-6CLZ-COOO-952I-571Y-QWBG" /></form>
					</div>
					<button type="submit" id="sendEmail" data-dismiss="modal">Send</button>
				</div>
			</div>
		</div>
	</div> <!--  Show modal when email is sent -->

	<button data-toggle="modal" class="hidden" data-target="#emailSentModal" id="emailSentModalToggle"></button>
	<div class="modal fade hawk-modal" tabindex="-1" role="dialog" aria-hidden="true" aria-labelledby="emailSentModalLabel" id="emailSentModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="emailSentModalLabel"></h4>
				</div>
				<div class="modal-body">
					<h4>
						<span><svg>
								<use xlink:href="/img/shared/icons.svg#email"></use></svg></span> EMAIL Equinix
					</h4>
					<h3>Your email has been sent</h3>

					<button data-dismiss="modal" id="emailSentModalDismiss">OK</button>
				</div>
			</div>
		</div>
	</div>
 <!--  Show modal when email fails to send -->

	<button data-toggle="modal" class="hidden" data-target="#emailFailModal" id="emailFailModalToggle"></button>
	<div class="modal fade hawk-modal" tabindex="-1" role="dialog" aria-hidden="true" aria-labelledby="emailFailModalLabel" id="emailFailModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="emailFailModalLabel"></h4>
				</div>
				<div class="modal-body">
					<h4>
						<span><svg>
								<use xlink:href="/img/shared/icons.svg#delete-circle"></use></svg></span> EMAIL NOT SENT
					</h4>
					<h3>Something went wrong. Please try again</h3>

					<button data-dismiss="modal" id="emailFailModalDismiss">OK</button>
				</div>
			</div>
		</div>
	</div>

</div>

<script id="provider-card-template" type="text/x-jsrender">
	<div class="col-sm-6 col-md-4">
		<div class="facility-card" data-id="{{>id}}">
			<div class="facility-image" style="background-image:url('{{>image}}');">
			</div>
			<div class="extra right">
				{{if subscriptionLevel == 'Premium'}}
					<label class="premium"><svg><use xlink:href="/img/shared/icons.svg#premium"></use></svg>PREMIUM</label>
				{{/if}}
			</div>
			<h4 class="compare-header-address">{{>name}}</h4>
			<h4 class="facility-classification">{{>classification}}</h4>
			<p>
				<span class="card-address" data-field="address">{{>address}}</span>
			</p>
			<p class="card-market">{{>city}}, {{>state}}</p>

				<a class="facility-link" href="{{>url}}">VIEW DETAILS</a>


		</div>
	</div>
</script>

<script src="js/hawkMapHelper.js"></script>
<script src="https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-zoomslider/v0.7.0/L.Control.Zoomslider.js"></script>
<script src="js/spin.min.js"></script>
<script src="js/jquery.spin.js"></script>
<link rel="stylesheet" href="css/L.Control.Zoomslider-edited.css" />

<script>
	// <![CDATA[
	L.mapbox.accessToken = "pk.eyJ1IjoiZGF0YWNlbnRlcmhhd2siLCJhIjoialFYZEFGMCJ9.rWMIf6AzzR708bI2-rHtEA";
	var map = L.mapbox.map("provider-map", HawkMapHelper.streetsLayer, {
		zoomControl : false,
		attributionControl : false
	});

	if ($(window).height() < 1000) {
		$("#provider-map").height(340);
	}

	map.setView([ 38.47939467327645, -94.9658203125 ], 4);

	var layers = {
		Streets : L.mapbox.tileLayer(HawkMapHelper.streetsLayer, {
			zIndex : 0
		}),
		Satellite : L.mapbox.tileLayer(HawkMapHelper.satelliteLayer, {
			zIndex : 0
		}),
	};

	layers.Streets.addTo(map);
	L.control.layers(layers, {}).addTo(map);

	new L.Control.Zoomslider({
		position : 'topright'
	}).addTo(map);

	map.scrollWheelZoom.disable();

	var facilities = [{'address':'56 Marietta Street NW; 5th Floor','city':'Atlanta','classification':'Colocation','companyCode':'AT2','id':118993,
	'image':'cmsstatic/colo/118993/Screen Shot 2016-04-11 at 8.39.41 AM.png','lat':33.75546700000000299723978969268500804901123046875,'lon':-84.391489000000007081325748004019260406494140625,'market':'Atlanta','name':'Equinix','postalCode':'30303','shortAddress':null,'state':'GA','subscriptionLevel':'Basic','url':'/colo/equinix/56-marietta-street-nw-5th-floor/at2'},{'address':'56 Marietta Street NW; 6th Floor','city':'Atlanta','classification':'Colocation','companyCode':'AT3','id':118995,
	'image':'cmsstatic/colo/118995/Screen Shot 2016-04-11 at 8.39.41 AM.png','lat':33.75546700000000299723978969268500804901123046875,'lon':-84.391489000000007081325748004019260406494140625,'market':'Atlanta','name':'Equinix','postalCode':'30303','shortAddress':null,'state':'GA','subscriptionLevel':'Basic','url':'/colo/equinix/56-marietta-street-nw-6th-floor/at3'},{'address':'180 Peachtree Street NW','city':'Atlanta','classification':'Colocation','companyCode':'AT1','id':118991,
	'image':'cmsstatic/colo/118991/Screen Shot 2016-04-11 at 8.38.41 AM.png','lat':33.758825999999999112333171069622039794921875,'lon':-84.3879869999999954188751871697604656219482421875,'market':'Atlanta','name':'Equinix','postalCode':'30303','shortAddress':null,'state':'GA','subscriptionLevel':'Basic','url':'/colo/equinix/180-peachtree-street-nw/at1'},{'address':'74 West Street; 1st Floor','city':'Waltham','classification':'Colocation','companyCode':'BO1','id':119007,
	'image':'cmsstatic/colo/119007/Screen Shot 2016-04-11 at 8.41.05 AM.png','lat':42.3953709999999972524165059439837932586669921875,'lon':-71.269261000000000194631866179406642913818359375,'market':'Boston','name':'Equinix','postalCode':'02451','shortAddress':null,'state':'MA','subscriptionLevel':'Basic','url':'/colo/equinix/74-west-street-1st-floor/bo1'},{'address':'350 East Cermak Road','city':'Chicago','classification':'Colocation','companyCode':'CH1, CH2, CH4','id':1267,
	'image':'cmsstatic/colo/1267/350 E Cermak II.jpg','lat':41.85323000000000348563844454474747180938720703125,'lon':-87.6184329999999960136847221292555332183837890625,'market':'Chicago','name':'Equinix','postalCode':'60616','shortAddress':null,'state':'IL','subscriptionLevel':'Basic','url':'/colo/equinix/350-east-cermak-road/ch1-ch2-ch4'},{'address':'1905 Lunt Avenue','city':'Elk Grove','classification':'Colocation','companyCode':'CH3','id':115899,
	'image':'cmsstatic/colo/115899/Equinix CH3-pic 1.png','lat':42.0011841999999973040758050046861171722412109375,'lon':-87.9549525000000045338310883380472660064697265625,'market':'Chicago','name':'Equinix','postalCode':'60007','shortAddress':null,'state':'IL','subscriptionLevel':'Basic','url':'/colo/equinix/1905-lunt-avenue/ch3'},{'address':'1950 N Stemmons','city':'Dallas','classification':'Colocation','companyCode':'DA 1-3, 6','id':1685,
	'image':'cmsstatic/colo/1685/us-tx-dallas-infomart-4.jpg','lat':32.80095399999999727924659964628517627716064453125,'lon':-96.8202160000000020545485313050448894500732421875,'market':'Dallas/Fort Worth','name':'Equinix','postalCode':'75207','shortAddress':null,'state':'TX','subscriptionLevel':'Basic','url':'/colo/equinix/1950-n-stemmons/da-1-3-6'},{'address':'2323 Bryan Street Suite 1400','city':'Dallas','classification':'Colocation','companyCode':'DA4','id':119013,
	'image':'cmsstatic/colo/119013/2323 Bryan St. Dallas, TX.png','lat':32.78721900000000033514879760332405567169189453125,'lon':-96.79424099999999953070073388516902923583984375,'market':'Dallas/Fort Worth','name':'Equinix','postalCode':'75201','shortAddress':null,'state':'TX','subscriptionLevel':'Basic','url':'/colo/equinix/2323-bryan-street-suite-1400/da4'},{'address':'6653 Pinecrest Drive','city':'Plano','classification':'Colocation','companyCode':'DA7','id':122828,
	'image':'cmsstatic/colo/122828/Screen Shot 2016-03-17 at 10.44.35 AM.png','lat':33.0648350000000021964297047816216945648193359375,'lon':-96.811871999999993931851349771022796630859375,'market':'Dallas/Fort Worth','name':'Equinix','postalCode':'75024','shortAddress':null,'state':'TX','subscriptionLevel':'Basic','url':'/colo/equinix/6653-pinecrest-drive/da7'},{'address':'9706 E. Easter Avenue','city':'Englewood','classification':'Colocation','companyCode':'DE; Suite 160','id':1225,
	'image':'cmsstatic/colo/1225/Screen Shot 2016-04-11 at 8.43.37 AM.png','lat':39.58738000000000312184056383557617664337158203125,'lon':-104.87655200000000377258402295410633087158203125,'market':'Denver','name':'Equinix','postalCode':'80112','shortAddress':null,'state':'CO','subscriptionLevel':'Basic','url':'/colo/equinix/9706-e-easter-avenue/de-suite-160'},{'address':'445 N Douglas Street','city':'El Segundo','classification':'Colocation','companyCode':'LA4','id':1656,
	'image':'cmsstatic/colo/1656/Equinix-LA4.ElSegundo-Pic1.png','lat':33.9218120000000027403075364418327808380126953125,'lon':-118.383971000000002504748408682644367218017578125,'market':'Los Angeles','name':'Equinix','postalCode':'90245','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/445-n-douglas-street/la4'},{'address':'1920 East Maple Avenue','city':'El Segundo','classification':'Colocation','companyCode':'LA3','id':1680,
	'image':'cmsstatic/colo/1680/Equinix-LA3.ElSegundo-Pic1.png','lat':33.92607699999999937290340312756597995758056640625,'lon':-118.3941229999999933397702989168465137481689453125,'market':'Los Angeles','name':'Equinix','postalCode':'90245','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/1920-east-maple-avenue/la3'},{'address':'818 W 7th Street; 6th Floor','city':'Los Angeles','classification':'Colocation','companyCode':'LA2','id':1276,
	'image':'cmsstatic/colo/1276/Screen Shot 2016-04-11 at 8.51.15 AM.png','lat':34.0488098000000007914422894828021526336669921875,'lon':-118.2594572999999940066118142567574977874755859375,'market':'Los Angeles','name':'Equinix','postalCode':'90017','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/818-w-7th-street-6th-floor/la2'},{'address':'600 West 7th Street; 6th Floor','city':'Los Angeles','classification':'Colocation','companyCode':'LA1','id':1672,
	'image':'cmsstatic/colo/1672/Screen Shot 2016-07-29 at 10.14.22 AM.png','lat':34.0476340000000021746018319390714168548583984375,'lon':-118.2567059999999941055648378096520900726318359375,'market':'Los Angeles','name':'Equinix','postalCode':'90017','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/600-west-7th-street-6th-floor/la1'},{'address':'36 NE Second Street','city':'Miami','classification':'Colocation','companyCode':'MI2; Suites 100, 120 and 550','id':1127,
	'image':'cmsstatic/colo/1127/Screen Shot 2016-04-11 at 8.52.08 AM.png','lat':25.775811000000000916543285711668431758880615234375,'lon':-80.192958000000004403773345984518527984619140625,'market':'Miami','name':'Equinix','postalCode':'33132','shortAddress':null,'state':'FL','subscriptionLevel':'Basic','url':'/colo/equinix/36-ne-second-street/mi2-suites-100-120-and-550'},{'address':'4680 Conference Way South Suite 150','city':'Boca Raton','classification':'Colocation','companyCode':'MI3','id':119159,
	'image':'cmsstatic/colo/119159/Screen Shot 2016-04-11 at 8.53.16 AM.png','lat':26.388047000000000252839527092874050140380859375,'lon':-80.1087930000000056907083489932119846343994140625,'market':'Miami','name':'Equinix','postalCode':'33431','shortAddress':null,'state':'FL','subscriptionLevel':'Basic','url':'/colo/equinix/4680-conference-way-south-suite-150/mi3'},{'address':'60 Hudson Street','city':'New York','classification':'Colocation','companyCode':'NY8; 1602','id':1667,
	'image':'cmsstatic/colo/1667/Screen Shot 2016-04-11 at 8.54.09 AM.png','lat':40.7176240000000007057678885757923126220703125,'lon':-74.0082660000000061017999541945755481719970703125,'market':'New York','name':'Equinix','postalCode':'10013','shortAddress':null,'state':'NY','subscriptionLevel':'Basic','url':'/colo/equinix/60-hudson-street/ny8-1602'},{'address':'111 8th Avenue','city':'New York','classification':'Colocation','companyCode':'NY9','id':1193,
	'image':'cmsstatic/colo/1193/Screen Shot 2016-04-11 at 8.55.02 AM.png','lat':40.74192099999999783221937832422554492950439453125,'lon':-74.0041030000000006339178071357309818267822265625,'market':'New York','name':'Equinix','postalCode':'10011','shortAddress':null,'state':'NY','subscriptionLevel':'Basic','url':'/colo/equinix/111-8th-avenue/ny9'},{'address':'255 Caspian Drive','city':'Sunnyvale','classification':'Colocation','companyCode':'SV4','id':1630,
	'image':'cmsstatic/colo/1630/255 Caspian 1.jpg','lat':37.4146539999999987458068062551319599151611328125,'lon':-122.0145820000000043137333705089986324310302734375,'market':'Northern California','name':'Equinix','postalCode':'94089','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/255-caspian-drive/sv4'},{'address':'11 Great Oaks Boulevard','city':'San Jose','classification':'Colocation','companyCode':'SV1','id':1671,
	'image':'cmsstatic/colo/1671/11 Great Oaks 1.jpg','lat':37.24159999999999826059138285927474498748779296875,'lon':-121.783310000000000172803993336856365203857421875,'market':'Northern California','name':'Equinix','postalCode':'95119','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/11-great-oaks-boulevard/sv1'},{'address':'1735 Lundy Avenue','city':'San Jose','classification':'Colocation','companyCode':'SV3','id':1673,
	'image':'cmsstatic/colo/1673/1735 Lundy 1.jpg','lat':37.3881980000000027075657271780073642730712890625,'lon':-121.888519999999999754436430521309375762939453125,'market':'Northern California','name':'Equinix','postalCode':'95131','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/1735-lundy-avenue/sv3'},{'address':'1350 Duane Avenue','city':'Santa Clara','classification':'Colocation','companyCode':'SV2','id':1679,
	'image':'cmsstatic/colo/1679/1350 Duane 1.jpg','lat':37.37915600000000182490111910738050937652587890625,'lon':-121.955006999999994832251104526221752166748046875,'market':'Northern California','name':'Equinix','postalCode':'95054','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/1350-duane-avenue/sv2'},{'address':'444 Toyama Drive','city':'Sunnyvale','classification':'Colocation','companyCode':'SV6','id':1079,
	'image':'cmsstatic/colo/1079/444 Toyama 1.jpg','lat':37.39960099999999698638930567540228366851806640625,'lon':-122.014555000000001427906681783497333526611328125,'market':'Northern California','name':'Equinix','postalCode':'94089','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/444-toyama-drive/sv6'},{'address':'529 Bryant Street','city':'Palo Alto','classification':'Colocation','companyCode':'SV8','id':1360,
	'image':'cmsstatic/colo/1360/Screen Shot 2016-04-11 at 8.55.59 AM.png','lat':37.4459200000000009822542779147624969482421875,'lon':-122.16077599999999847568687982857227325439453125,'market':'Northern California','name':'Equinix','postalCode':'94301','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/529-bryant-street/sv8'},{'address':'9 Great Oaks Boulevard','city':'San Jose','classification':'Colocation','companyCode':'SV5','id':1178,
	'image':'cmsstatic/colo/1178/9 Great Oaks 1.jpg','lat':37.2419229999999998881321516819298267364501953125,'lon':-121.7817280000000010886651580221951007843017578125,'market':'Northern California','name':'Equinix','postalCode':'95119','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/9-great-oaks-boulevard/sv5'},{'address':'5941 Monterey Road','city':'San Jose','classification':'Colocation','companyCode':'SV10','id':130420,
	'image':'cmsstatic/colo/130420/IMG_1656 (2).JPG','lat':37.24092900000000128102328744716942310333251953125,'lon':-121.785156000000000631189323030412197113037109375,'market':'Northern California','name':'Equinix','postalCode':'95119','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/5941-monterey-road/sv10'},{'address':'5941 Monterey Road','city':'San Jose','classification':'Colocation','companyCode':'SV11','id':130425,
	'image':'cmsstatic/colo/130425/IMG_1656 (2).JPG','lat':37.2427050000000008367351256310939788818359375,'lon':-121.7842260000000038644429878331720829010009765625,'market':'Northern California','name':'Equinix','postalCode':'95119','shortAddress':null,'state':'CA','subscriptionLevel':'Basic','url':'/colo/equinix/5941-monterey-road/sv11'},{'address':'275 Hartz Way','city':'Secaucus','classification':'Colocation','companyCode':'NY2','id':1631,
	'image':'cmsstatic/colo/1631/Screen Shot 2016-04-11 at 8.57.27 AM.png','lat':40.77748100000000164300217875279486179351806640625,'lon':-74.0758799999999979490894475020468235015869140625,'market':'Northern New Jersey','name':'Equinix','postalCode':'07094','shortAddress':null,'state':'NJ','subscriptionLevel':'Basic','url':'/colo/equinix/275-hartz-way/ny2'},{'address':'5851 Westside Avenue','city':'North Bergen','classification':'Colocation','companyCode':'NY7','id':1657,
	'image':'cmsstatic/colo/1657/Screen Shot 2016-04-11 at 8.59.57 AM.png','lat':40.79687969999999808123902766965329647064208984375,'lon':-74.031161400000002004162524826824665069580078125,'market':'Northern New Jersey','name':'Equinix','postalCode':'07047','shortAddress':null,'state':'NJ','subscriptionLevel':'Basic','url':'/colo/equinix/5851-westside-avenue/ny7'},{'address':'755 Secaucus Road','city':'Secaucus','classification':'Colocation','companyCode':'NY4','id':1135,
	'image':'cmsstatic/colo/1135/Screen Shot 2016-04-11 at 8.56.47 AM.png','lat':40.77641200000000054615156841464340686798095703125,'lon':-74.0697200000000037789504858665168285369873046875,'market':'Northern New Jersey','name':'Equinix','postalCode':'07094','shortAddress':null,'state':'NJ','subscriptionLevel':'Basic','url':'/colo/equinix/755-secaucus-road/ny4'},{'address':'105 Enterprise Avenue South','city':'Secaucus','classification':'Colocation','companyCode':'NY6','id':118901,
	'image':'cmsstatic/colo/118901/Screen Shot 2016-04-11 at 9.03.31 AM.png','lat':40.7776020000000016807462088763713836669921875,'lon':-74.072902999999996609403751790523529052734375,'market':'Northern New Jersey','name':'Equinix','postalCode':'07094','shortAddress':null,'state':'NJ','subscriptionLevel':'Basic','url':'/colo/equinix/105-enterprise-avenue-south/ny6'},{'address':'165 Halsey St; 8th Floor','city':'Newark','classification':'Colocation','companyCode':'NY1','id':119277,
	'image':'cmsstatic/colo/119277/Screen Shot 2016-04-11 at 9.04.32 AM.png','lat':40.73685900000000259524313150905072689056396484375,'lon':-74.173464999999993096935213543474674224853515625,'market':'Northern New Jersey','name':'Equinix','postalCode':'07012','shortAddress':null,'state':'NJ','subscriptionLevel':'Basic','url':'/colo/equinix/165-halsey-st-8th-floor/ny1'},{'address':'800 Secaucus Road','city':'Secaucus','classification':'Colocation','companyCode':'NY5','id':114004,
	'image':'cmsstatic/colo/114004/Screen Shot 2016-04-11 at 9.01.53 AM.png','lat':40.77862300000000317368176183663308620452880859375,'lon':-74.0723689999999947985998005606234073638916015625,'market':'Northern New Jersey','name':'Equinix','postalCode':'07094','shortAddress':null,'state':'NJ','subscriptionLevel':'Basic','url':'/colo/equinix/800-secaucus-road/ny5'},{'address':'7990 Science Applications Court','city':'Vienna','classification':'Colocation','companyCode':'DC7','id':1608,
	'image':'cmsstatic/colo/1608/Screen Shot 2016-04-11 at 9.11.25 AM.png','lat':38.9090369999999978745108819566667079925537109375,'lon':-77.2205450000000013233147910796105861663818359375,'market':'Northern Virginia','name':'Equinix','postalCode':'22182','shortAddress':null,'state':'VA','subscriptionLevel':'Basic','url':'/colo/equinix/7990-science-applications-court/dc7'},{'address':'21711 Filigree Court','city':'Ashburn','classification':'Colocation','companyCode':'DC1','id':1609,
	'image':'cmsstatic/colo/1609/Screen Shot 2016-04-11 at 9.15.14 AM.png','lat':39.01558299999999945839590509422123432159423828125,'lon':-77.4603489999999936799213173799216747283935546875,'market':'Northern Virginia','name':'Equinix','postalCode':'20147','shortAddress':null,'state':'VA','subscriptionLevel':'Basic','url':'/colo/equinix/21711-filigree-court/dc1'},{'address':'21721 Filigree Court','city':'Ashburn','classification':'Colocation','companyCode':'DC6','id':1610,
	'image':'cmsstatic/colo/1610/Screen Shot 2016-04-11 at 9.17.53 AM.png','lat':39.01518200000000291538526653312146663665771484375,'lon':-77.459509999999994533936842344701290130615234375,'market':'Northern Virginia','name':'Equinix','postalCode':'20147','shortAddress':null,'state':'VA','subscriptionLevel':'Basic','url':'/colo/equinix/21721-filigree-court/dc6'},{'address':'21701 Filigree Court','city':'Ashburn','classification':'Colocation','companyCode':'DC5','id':1012,
	'image':'cmsstatic/colo/1012/Screen Shot 2016-04-11 at 9.06.09 AM.png','lat':39.0159909999999996443875716067850589752197265625,'lon':-77.46122900000000299769453704357147216796875,'market':'Northern Virginia','name':'Equinix','postalCode':'20147','shortAddress':null,'state':'VA','subscriptionLevel':'Basic','url':'/colo/equinix/21701-filigree-court/dc5'},{'address':'44470 Chilum Place','city':'Ashburn','classification':'Colocation','companyCode':'DC3','id':1036,
	'image':'cmsstatic/colo/1036/Screen Shot 2016-04-11 at 9.07.33 AM.png','lat':39.0223730000000017525962903164327144622802734375,'lon':-77.461128000000002202796167694032192230224609375,'market':'Northern Virginia','name':'Equinix','postalCode':'20147','shortAddress':null,'state':'VA','subscriptionLevel':'Basic','url':'/colo/equinix/44470-chilum-place/dc3'},{'address':'21691 Filigree Court','city':'Ashburn','classification':'Colocation','companyCode':'DC4','id':1054,
	'image':'cmsstatic/colo/1054/Screen Shot 2016-04-11 at 9.08.45 AM.png','lat':39.016357999999996764017851091921329498291015625,'lon':-77.4616350000000011277734301984310150146484375,'market':'Northern Virginia','name':'Equinix','postalCode':'20147','shortAddress':null,'state':'VA','subscriptionLevel':'Basic','url':'/colo/equinix/21691-filigree-court/dc4'},{'address':'8502-A Tyco Road','city':'Vienna','classification':'Colocation','companyCode':'DC8','id':1062,
	'image':'cmsstatic/colo/1062/Screen Shot 2016-04-11 at 9.10.34 AM.png','lat':38.93207000000000306272340822033584117889404296875,'lon':-77.239518000000003894456312991678714752197265625,'market':'Northern Virginia','name':'Equinix','postalCode':'22182','shortAddress':null,'state':'VA','subscriptionLevel':'Basic','url':'/colo/equinix/8502-a-tyco-road/dc8'},{'address':'21721 Filigree Court','city':'Ashburn','classification':'Colocation','companyCode':'DC11','id':1119,
	'image':'cmsstatic/colo/1119/F96953C3-7295-4558-A954-EA95EE3B046F.png','lat':39.014803000000000565705704502761363983154296875,'lon':-77.4589849999999984220266924239695072174072265625,'market':'Northern Virginia','name':'Equinix','postalCode':'20147','shortAddress':null,'state':'VA','subscriptionLevel':'Basic','url':'/colo/equinix/21721-filigree-court/dc11'},{'address':'21715 Filigree Court','city':'Ashburn','classification':'Colocation','companyCode':'DC2','id':1145,
	'image':'cmsstatic/colo/1145/Screen Shot 2016-04-11 at 9.19.16 AM.png','lat':39.01635470000000083246050053276121616363525390625,'lon':-77.459023900000005369292921386659145355224609375,'market':'Northern Virginia','name':'Equinix','postalCode':'20147','shortAddress':null,'state':'VA','subscriptionLevel':'Basic','url':'/colo/equinix/21715-filigree-court/dc2'},{'address':'21551 Beaumeade Circle','city':'Ashburn','classification':'Colocation','companyCode':'DC10','id':1700,
	'image':'cmsstatic/colo/1700/Screen Shot 2016-04-12 at 8.13.40 AM.png','lat':39.0210220000000020945662981830537319183349609375,'lon':-77.451539999999994279278325848281383514404296875,'market':'Northern Virginia','name':'Equinix','postalCode':'20147','shortAddress':null,'state':'VA','subscriptionLevel':'Basic','url':'/colo/equinix/21551-beaumeade-circle/dc10'},{'address':'401 N Broad Street; Suite 990','city':'Philadelphia','classification':'Colocation','companyCode':'PH1','id':1405,
	'image':'cmsstatic/colo/1405/Screen Shot 2016-04-11 at 9.24.50 AM.png','lat':39.95976300000000236423147725872695446014404296875,'lon':-75.16079700000000229920260608196258544921875,'market':'Philadelphia','name':'Equinix','postalCode':'19108','shortAddress':null,'state':'PA','subscriptionLevel':'Basic','url':'/colo/equinix/401-n-broad-street-suite-990/ph1'},{'address':'2001 Sixth Avenue Suite 1202','city':'Seattle','classification':'Colocation','companyCode':'SE2','id':1690,
	'image':'cmsstatic/colo/1690/Screen Shot 2016-04-11 at 9.23.52 AM.png','lat':47.61444399999999887995727476663887500762939453125,'lon':-122.3387599999999935107553028501570224761962890625,'market':'Seattle','name':'Equinix','postalCode':'98121','shortAddress':null,'state':'WA','subscriptionLevel':'Basic','url':'/colo/equinix/2001-sixth-avenue-suite-1202/se2'},{'address':'2020 5th Avenue','city':'Seattle','classification':'Colocation','companyCode':'SE3','id':1695,
	'image':'cmsstatic/colo/1695/Equinix SE3.jpg','lat':47.614283999999997831764630973339080810546875,'lon':-122.33971999999999979991116560995578765869140625,'market':'Seattle','name':'Equinix','postalCode':'98121','shortAddress':null,'state':'WA','subscriptionLevel':'Basic','url':'/colo/equinix/2020-5th-avenue/se3'},{'address':'45 Parliament Street','city':'Toronto','classification':'Colocation','companyCode':'TR2','id':112754,
	'image':'cmsstatic/colo/112754/Screen Shot 2015-04-07 at 11.02.49 AM.png','lat':43.650903999999997040504240430891513824462890625,'lon':-79.3618019999999972924342728219926357269287109375,'market':'Toronto','name':'Equinix','postalCode':'M5A 0B2','shortAddress':null,'state':'ON','subscriptionLevel':'Basic','url':'/colo/equinix/45-parliament-street/tr2'},{'address':'151 Front Street West','city':'Toronto','classification':'Colocation','companyCode':'TR1','id':103888,
	'image':'cmsstatic/colo/103888/Screen Shot 2016-04-12 at 8.34.53 AM.png','lat':43.64471900000000204045136342756450176239013671875,'lon':-79.3838339999999931251295492984354496002197265625,'market':'Toronto','name':'Equinix','postalCode':'M5J 2N1','shortAddress':null,'state':'ON','subscriptionLevel':'Basic','url':'/colo/equinix/151-front-street-west/tr1'}];

	if (facilities && facilities.length > 0) {
		mapResults(map, facilities);
	}

	$('.js-main-img').each(function(idx, element) {
		var $element = $(element);
		var imageUrl = $element.attr('data-bg') || '/img/eye.png';
		dch.media.resolveThumbnail(imageUrl).then(function(resolvedUrl) {
			$element.css('background-image', "url(" + encodeURI(resolvedUrl) + ")");
		});
	});

	$("#contact-help").popover();

	$("#sendEmail").click(function() {
		$("#contact-provider-form").submit();
	});

	$('#contact-provider-form').on('submit', function(event) {
		event.preventDefault();
		$.ajax({
			type : 'POST',
			url : '/listing/contact',
			data : $(this).serialize()
		}).done(function() {
			$('#emailSentModalToggle').click();
		}).fail(function(res, status, err) {
			// Show a modal indicating failure, but print details in console
			console.error(res);
			console.error("Error code: " + res.status + " " + res.statusText);
			$('#emailFailModalToggle').click();
		});
	});

	$("#phoneNumber").on("change", function() {
		var number = $(this).val().replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3").replace(/(\d)(\d{3})(\d{3})(\d{4})/, "$1-($2) $3-$4");
		$(this).val(number)
	});

    $.getJSON("/api/v1/markets/autocomplete/providers", function(data) {
        $("#provider-search").autocomplete({
            source : $.map(data, function(val, i) {
                return {
                    label : val.name,
                    url : val.url
                }
            }),
            minLength : 2,
            select : function(event, ui) {
                $("#provider-search").val(ui.item.label);
                window.location = "/providers" + ui.item.url;
                $("#loader").removeClass("hide");
                $("#loader").spin({ left: "50%", top: "50%" });
        		$(".spinner").css("position", "fixed");
            }
        });
    });

    if (facilities && facilities.length > 0) {
    	$("#owned-facilities").append($("#provider-card-template").render(facilities));
    }

	$(".contact-provider-link").click(function() {
		$("#contact-provider-form input[name='facilityId']").val($(this).parents(".facility-card").data("id"));
		$("#contactProviderModalToggle").click();
	});

	// ]]>
</script>

		</div>
        <!-- Start Footer----->
 		<?php include("includes/footer.php"); ?>
        <!-- End Footer ----->



	</div>
</body>
</html>