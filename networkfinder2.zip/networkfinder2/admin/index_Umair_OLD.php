<?php 
include("../includes/checkSession.php");

// ------------------------------------- server configuration -------------------------------------
$host ='107.180.20.86';
$db = 'fiber_information';
$user = 'FiberIndustry';
$conn  = mysql_connect($host,$user,'pakistan123$$') or die('server information is not correct');
mysql_select_db($db,$conn) or die('database info not correct');
//=====================================End Server Configuration========================================

if (isset($_GET['id_provider'])) {
	$id_company = (int)$_GET['id_provider'];
	$getCompany = mysql_query('select * from ifimt_company where id_company="'.$id_company.'"');
	$getCompany = mysql_fetch_array($getCompany);
	$getCompanyAddress = mysql_query('select * from ifimt_address where id_company="'.$id_company.'"');
	$getCompanyAddress = mysql_fetch_array($getCompanyAddress);
	$getCompanyProducts = mysql_query('select * from ifimt_products where id_company="'.$id_company.'"');
	$getCompanyProducts = mysql_fetch_array($getCompanyProducts);
	$getCompanyContacts = mysql_query('select * from ifimt_contacts where id_company="'.$id_company.'" limit 0,3');
	$getCompanyPops = mysql_query('select * from ifimt_pops where id_company="'.$id_company.'" && latitude!=""');
	$count = 0;
	$cords = '';
	while ($getCompanyPop = mysql_fetch_assoc($getCompanyPops)) {
		$completeAddress = $getCompanyPop['address'].' '.$getCompanyPop['address2'].',+'.$getCompanyPop['city'].',+'.$getCompanyPop['zip'];
		//$coordsVal = getlat_lon($completeAddress);
		$facilities[$count]['address'] = addslashes($getCompanyPop['address']);
		$facilities[$count]['city'] = addslashes($getCompanyPop['city']);
		$facilities[$count]['classification'] = 'Colocation';
		$facilities[$count]['companyCode'] = $getCompanyPop['id_company'];
		$facilities[$count]['id'] = $getCompanyPop['id_pops'];
		$facilities[$count]['image'] = 'https://maps.googleapis.com/maps/api/streetview?size=243x145&location='.$getCompanyPop['latitude'].','.$getCompanyPop['longitude'].'&fov=90&heading=235&pitch=10&key=AIzaSyCBzUFUhEkI_lZIQnPz5PeDhrhWCtGuLKA';
		$facilities[$count]['lat'] = $getCompanyPop['latitude'];
		$facilities[$count]['lon'] = $getCompanyPop['longitude'];
		$facilities[$count]['market'] = 'Atlanta';
		$facilities[$count]['name'] = addslashes($getCompanyPop['name']);
		$facilities[$count]['postalCode'] = $getCompanyPop['zip'];
		$facilities[$count]['shortAddress'] = '';
		$facilities[$count]['state'] = '';
		$facilities[$count]['subscriptionLevel'] = 'Basic';
		$facilities[$count]['url'] = '/admin/provider-detail.php?id_provider='.$id_company.'&id_pop='.$getCompanyPop['id_pops'];
		$cords.="
		  ['".addslashes($getCompanyPop['name'])."',".$getCompanyPop['latitude'].",".$getCompanyPop['longitude'].",".$count.",'".$facilities[$count]['image']."','".addslashes($facilities[$count]['address'])."','".$facilities[$count]['url']."'],";  
		$count++;
	}
	$facilities = json_encode($facilities);
	//$facilities = '';
}

function getlat_lon($addressVal) {
	$geocode = file_get_contents('http://maps.google.com/maps/api/geocode/json?address='.urlencode($addressVal).'&sensor=false');
	$output		= json_decode($geocode); //Store values in variable
    if ($output->status == 'OK') { // Check if address is available or not
		$latitude = $output->results[0]->geometry->location->lat; //Returns Latitude
		$longitude = $output->results[0]->geometry->location->lng; // Returns Longitude
	}
	$coords['latitude'] = $latitude;
	$coords['longitude'] = $longitude;
	return $coords;
}

?>

<!DOCTYPE HTML>

<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if IE 9]>    <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js" lang="en" prefix="og: http://ogp.me/ns#">
<!--<![endif]-->

<head><meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />




	<title>Providers -Connected2Fiber</title>


<meta name="description" content="Search for data center providers on Connected2Fiber " />


<meta name="author" content="Connected2Fiber" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
<meta name="viewport" content="width=device-width" />


	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:site" content="@Connected2Fiber" />
	<meta property="og:title" content="Search Data Center Providers" />
	<meta property="og:description" content="Search Connected2Fiber
    to find information on industry leading data center providers." />
	

<link rel="stylesheet" href="css/jquery.rating.css" />
<link rel="icon" type="image/png" href="img/shared/favicon.png" />



<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap-edited.min.css" />

<!-- Optional theme -->
<link rel="stylesheet" href="css/bootstrap-theme.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="css/dataTables.fixedColumns.min.css" />

<link rel="stylesheet" href="css/main-1091214527.css" />

<!-- Latest compiled and minified JavaScript -->
<script src="js/jquery-2.1.1.min.js"></script>

<script src="js/jquery-ui.min.js"></script>
<script src="js/jquery.ui.touch-punch.min.js"></script>

<script src="js/bootstrap.min.js"></script>

<script src="js/libs/jquery.dataTables.min.js"></script>
<script src="js/libs/dataTables.fixedColumns.min.js"></script>

<script src="js/libs/modernizr-2.5.3.min.js"></script>

<script src="js/heap-analytics.js"></script>

<script src="js/hawk.js"></script>
<script src="js/util.js"></script>
<script src="js/media.js"></script>
<script src="js/mapbox.utils.js"></script>

<script src="js/mapbox.js"></script>
<link href="css/mapbox.css" rel="stylesheet" />
<script src="js/NonTiledLayer.js"></script>
<script src="js/NonTiledLayer.WMS.js"></script>

<script src="js/svg4everybody.js"></script>
<script src="js/jquery.placeholder.js"></script>

<script type="text/javascript" src="js/lib-1305157643.js"></script>

<script type="text/javascript" src="js/heatclinic-119894065.js"></script>

<!-- Start of zentechnologies Zendesk Widget script -->
<script>/*<![CDATA[*/window.zEmbed||function(e,t){var n,o,d,i,s,a=[],r=document.createElement("iframe");window.zEmbed=function(){a.push(arguments)},window.zE=window.zE||window.zEmbed,r.src="javascript:false",r.title="",r.role="presentation",(r.frameElement||r).style.cssText="display: none",d=document.getElementsByTagName("script"),d=d[d.length-1],d.parentNode.insertBefore(r,d),i=r.contentWindow,s=i.document;try{o=s}catch(e){n=document.domain,r.src='javascript:var d=document.open();d.domain="'+n+'";void(0);',o=s}o.open()._l=function(){var o=this.createElement("script");n&&(this.domain=n),o.id="js-iframe-async",o.src=e,this.t=+new Date,this.zendeskHost=t,this.zEQueue=a,this.body.appendChild(o)},o.write('<body onload="document._l();">'),o.close()}("https://assets.zendesk.com/embeddable_framework/main.js","zentechnologies.zendesk.com");
/*]]>*/</script>
<!-- End of zentechnologies Zendesk Widget script -->

<script src="js/jquery.unveil.js"></script>
<script>
    $(function() {
        $(".facility-image img").unveil(300);
    });
    </script>

</head>

<body id="-catalog-provider">
	<div class="hawk-content-wrapper texture-bg">
       <!-- Start Header----->
        <?php  include("includes/header.php");?>
       <!-- End Header----->

<div><button id="noAccessModalToggle" data-toggle="modal" data-target="#noAccessModal" class="hidden"></button>
<div class="modal hawk-modal" id="noAccessModal" tabindex="-1" role="dialog" aria-labelledby="noAccessModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title" id="noAccessModalLabel"></h4>
			</div>
			<div class="modal-body">
				<h4 class="message ur">Upgrade now for access</h4>
				<h4 class="message sr">Subscribe now for access</h4>
				<h4 class="message sm">Select a market to begin using Hawk Products</h4>
				<span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#search"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#zoom"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#scope"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#compare"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#finance"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#research"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#swap"></use></svg></span>
				<form action="/support" class="message ur">
					<button>CONTACT US</button>
				</form>
				<form action="/plans" class="message sr">
					<button>SIGN UP</button>
				</form>
				<form action="/account/select-market" class="message sm">
					<button>SELECT MARKET</button>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	// <![CDATA[

	var isIE = /* @cc_on!@ */false || !!document.documentMode;

	var param = null;

	var HawkModal = {
		toggle : function(type) {
			$(".message", $("#noAccessModal")).hide();
			$("." + type, $("#noAccessModal")).show();
			$('#noAccessModalToggle').click();
		}
	};

	$('#noAccessModal').on('hidden.bs.modal', function () {
		if (window.location.search.indexOf("?r=") == 0) {
			window.location.search = "";
		}
	});

	$(function() {
		if (param && param.length > 0) {
			param = param[0];
			if (param == "sr" || param == "ur") {
				HawkModal.toggle(param);

			}
		}
	});
	//]]>
</script></div>
<div><button id="registerModalToggle" data-toggle="modal" data-target="#register-modal" class="hidden"></button>
<div class="modal hawk-modal" id="register-modal" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<h4>Register below to join now!</h4>
				<div class="form-wrapper">
					<form id="registration-form" method="POST" action="/register">
						<div class="col-md-12">
							<label>Company Email</label>
							<input type="email" id="customer.emailAddress" name="customer.emailAddress" />
							<div class="col-md-6">
								<label>First Name</label>
								<input type="text" id="customer.firstName" name="customer.firstName" />
							</div>
							<div class="col-md-6">
								<label>Last Name</label>
								<input type="text" id="customer.lastName" name="customer.lastName" />
							</div>
							<label>Password</label>
							<input type="password" id="password" name="password" />
							<label>Confirm Password</label>
							<input type="password" id="passwordConfirm" name="passwordConfirm" />
							<label class="tos-label"><input id="modal-confirm-tos" type="checkbox" /><span>
							I agree to Connected2Fiber's <a href="/terms-of-service" target="_blank">Terms of Service and Privacy Policy</a></span></label>
							<button type="submit" id="modal-register-button" class="register-button" data-dismiss="modal" disabled="disabled">Register</button>
						</div>
					<input type="hidden" name="csrfToken" value="6WWP-1GVX-78SP-BWII-M8JE-5INU-PCJU-HL2Q" /></form>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	//<![CDATA[

	$(".register-link, .register-text").click(function() {
		$("#registerModalToggle").click();
	});

	$("#modal-register-button").click(function() {
		$("#registration-form").submit();
	})

	$("#modal-confirm-tos").click(function() {
		$("#modal-register-button").attr("disabled", !this.checked);
	});



	//]]>
</script></div>
	<div class="xs-menu">
		<ul>
			<li>
				<a href="/products">Products</a>
			</li>
			<li>
				<a href="/register">Register</a>
			</li>
			<li>
				<a href="/blog">Blog</a>
			</li>
			<li>
				<a href="/about">About Us</a>
			</li>
			<li>
				<a href="/support">Contact Us</a>
			</li>
			<li>
				<hr />
			</li>
			<li>
				<p>sales@connected2fiber.com</p>
			</li>
			<li>
				<p>508-202-1807</p>
			</li>
			<li class="address">
				<p>105b South Street</p>
				<p>Hopkinton, MA 01748</p>
			</li>
		</ul>
	</div>


		<div class="hawk-content" role="main">




<div id="provider-content">
	<div id="loader" class="hide"></div>
	<div id="map"></div>
	<div class="container">
		<div class="row">
			<div class="provider-search-bar">
				<div class="input-group search-bar">
					<input id="provider-search" type="text" name="provider-search" class="form-control" placeholder="Search by Provider" value="<?php echo $getCompany['company_name']; ?>" onkeyup="getProviderData(event, this.value);" />
					<span class="input-group-addon search-magnifier"><svg><use xlink:href="/img/shared/icons.svg#search"></use></svg></span>
				</div>
			</div>
		</div>
	</div>
	
	<div class="search-padding search-box" style="display:none;"></div>
	<?php 
	if (isset($id_company)) {
		
		echo '
	<div class="container content-padding">
		<div class="col-sm-3 provider-info">
			<h4>'.$getCompany['company_name'].'</h4>
			<p>'.$getCompanyAddress['address'].' '.$getCompanyAddress['address2'].'</p>
			<p>'.$getCompanyAddress['city'].','.$getCompanyAddress['state'].' '.$getCompanyAddress['zip'].'</p>
			'.(!empty($getCompany['webiste']) ? '<a target="_blank" href="http://'.$getCompany['webiste'].'">'.$getCompany['webiste'].'</a>': '' ).'
			<ul class="details">
				<li><p>Type: '.$getCompany['company_type'].'</p></li>
				<li><p>Ticker: '.$getCompany['ticker'].'</p></li>
				<!--<li><p>Number of Employees: 1001-5000</p></li>
				<li><p>Year Founded: 1998</p></li>-->
			</ul>
			<!--<img src="cmsstatic/dcproviders/219/Equinix_Logo_000001.jpg" />-->
			<h2>Services Available</h2>
			<ul class="checklist">
				<li '.($getCompanyProducts['dark_fiber'] == 1 ? '': 'class="disabled"' ).' >Dark Fiber</li>
				<li '.($getCompanyProducts['wavelengths'] == 1 ? '': 'class="disabled"' ).'>Wavelengths</li>
				<li '.($getCompanyProducts['sonet'] == 1 ? '': 'class="disabled"' ).'>SONET</li>
				<li '.($getCompanyProducts['ethernet'] == 1 ? '': 'class="disabled"' ).'>Ethernet</li>
				<li '.($getCompanyProducts['mpls'] == 1 ? '': 'class="disabled"' ).'>MPLS</li>
				<li '.($getCompanyProducts['ip_transit'] == 1 ? '': 'class="disabled"' ).'>IP Transit</li>
				<li '.($getCompanyProducts['ip_broadband'] == 1 ? '': 'class="disabled"' ).'>IP Broadband</li>
				<li '.($getCompanyProducts['ip_dedicated'] == 1 ? '': 'class="disabled"' ).'>IP Dedicated</li>
				<li '.($getCompanyProducts['ip_vpn'] == 1 ? '': 'class="disabled"' ).'>IP VPN</li>
				<li '.($getCompanyProducts['voip'] == 1 ? '': 'class="disabled"' ).'>VoIP</li>
				<li '.($getCompanyProducts['uc'] == 1 ? '': 'class="disabled"' ).'>UC</li>
				<li '.($getCompanyProducts['managed_services'] == 1 ? '': 'class="disabled"' ).'>Managed Services</li>
			</ul>
		</div>
		<div class="col-sm-9 facilities">

				<h4>Company Information</h4>
				<p>'.$getCompany['description'].'</p>';
				$contacts = mysql_num_rows($getCompanyContacts);
				if ($contacts > 0) {
					echo '<h4>Contact Information</h4>
					<table class="table">
					<tr>
					<th>Name</th>
					<th>Title</th>
					<th>Phone</th>
					<th>Email</th>
					</tr>
					';
					while ($getCompanyContact = mysql_fetch_assoc($getCompanyContacts)) {
						echo '<tr><td>'.$getCompanyContact['name'].'</td><td>'.$getCompanyContact['title'].'</td><td>'.$getCompanyContact['phone'].'</td><td>'.$getCompanyContact['email'].'</td></tr>';	
					}
					echo '
					</table>';
				}
			echo '<div id="owned-facilities">
			</div>
		</div>
	</div>';
	}
	?>

	<button id="contactProviderModalToggle" data-toggle="modal" data-target="#contactProviderModal" class="hidden"></button>
	<div class="modal hawk-modal" id="contactProviderModal" tabindex="-1" role="dialog" aria-labelledby="contactProviderModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="contactProviderModalLabel"></h4>
				</div>
				<div class="modal-body contact-provider">
					<h4>
						<span class="icon-bg"><svg>
									<use xlink:href="/img/shared/icons.svg#email"></use></svg></span> EMAIL [[*{name}]] <svg id="contact-help" data-trigger="hover" data-placement="bottom" data-content="Submitting this form sends an email directly to the provider. Your information is key confidential and is not shared with any other parties"><use xlink:href="/img/shared/icons.svg#question"></use></svg>
					</h4>
					<br />
					<h5>Fill in your information below and click Send to request more information from [[*{name}]]</h5>
					<br />
					<div class="form-wrapper">
						<form id="contact-provider-form">
							<input type="hidden" name="facilityId" />
							<div class="col-md-12">
								<input type="text" id="fullName" placeholder="Your Name" name="fullName" value="" />
								<input type="email" id="emailAddress" placeholder="Your Email" name="emailAddress" value="" />
								<input type="text" id="phoneNumber" placeholder="Your Phone Number" name="phoneNumber" value="" />
							</div>
						<input type="hidden" name="csrfToken" value="6WWP-1GVX-78SP-BWII-M8JE-5INU-PCJU-HL2Q" /></form>
					</div>
					<button type="submit" id="sendEmail" data-dismiss="modal">Send</button>
				</div>
			</div>
		</div>
	</div> <!--  Show modal when email is sent -->

	<button data-toggle="modal" class="hidden" data-target="#emailSentModal" id="emailSentModalToggle"></button>
	<div class="modal fade hawk-modal" tabindex="-1" role="dialog" aria-hidden="true" aria-labelledby="emailSentModalLabel" id="emailSentModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="emailSentModalLabel"></h4>
				</div>
				<div class="modal-body">
					<h4>
						<span><svg>
								<use xlink:href="/img/shared/icons.svg#email"></use></svg></span> EMAIL null
					</h4>
					<h3>Your email has been sent</h3>

					<button data-dismiss="modal" id="emailSentModalDismiss">OK</button>
				</div>
			</div>
		</div>
	</div>
 <!--  Show modal when email fails to send -->

	<button data-toggle="modal" class="hidden" data-target="#emailFailModal" id="emailFailModalToggle"></button>
	<div class="modal fade hawk-modal" tabindex="-1" role="dialog" aria-hidden="true" aria-labelledby="emailFailModalLabel" id="emailFailModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="emailFailModalLabel"></h4>
				</div>
				<div class="modal-body">
					<h4>
						<span><svg>
								<use xlink:href="img/shared/icons.svg#delete-circle"></use></svg></span> EMAIL NOT SENT
					</h4>
					<h3>Something went wrong. Please try again</h3>

					<button data-dismiss="modal" id="emailFailModalDismiss">OK</button>
				</div>
			</div>
		</div>
	</div>

</div>

<script id="provider-card-template" type="text/x-jsrender">

	<div class="col-sm-6 col-md-4">
		<div class="facility-card" data-id="{{>id}}">
			<div class="facility-image">
				<img data-src="{{>image}}" data-src-retina="{{>image}}" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" />
			</div>
			<div class="extra right">
				{{if subscriptionLevel == 'Premium'}}
					<label class="premium"><svg><use xlink:href="/img/shared/icons.svg#premium"></use></svg>PREMIUM</label>
				{{/if}}
			</div>
			<h4 class="compare-header-address">{{>name}}</h4>
			<h4 class="facility-classification">{{>classification}}</h4>
			<p>
				<span class="card-address" data-field="address">{{>address}}</span>
			</p>
			<p class="card-market">{{>city}}, {{>state}}</p>

				<!--<a class="facility-link" href="{{>url}}">VIEW DETAILS</a>-->
				<a class="facility-link" href="{{>url}}">VIEW DETAILS</a>


		</div>
	</div>
</script>

<!--<script src="js/hawkMapHelper.js"></script>
<script src="https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-zoomslider/v0.7.0/L.Control.Zoomslider.js"></script>-->
<script src="js/spin.min.js"></script>
<script src="js/jquery.spin.js"></script>
<link rel="stylesheet" href="css/L.Control.Zoomslider-edited.css" />

<script>
	var facilities = <?php echo $facilities; ?>;
	if (facilities && facilities.length > 0) {
    	$("#owned-facilities").append($("#provider-card-template").render(facilities));
    }
</script>

<!--<script>
	// <![CDATA[
	L.mapbox.accessToken = "pk.eyJ1IjoiZGF0YWNlbnRlcmhhd2siLCJhIjoialFYZEFGMCJ9.rWMIf6AzzR708bI2-rHtEA";
	var map = L.mapbox.map("provider-map", HawkMapHelper.streetsLayer, {
		zoomControl : false,
		attributionControl : false
	});

	if ($(window).height() < 1000) {
		$("#provider-map").height(340);
	}

	map.setView([ 38.47939467327645, -94.9658203125 ], 4);

	var layers = {
		Streets : L.mapbox.tileLayer(HawkMapHelper.streetsLayer, {
			zIndex : 0
		}),
		Satellite : L.mapbox.tileLayer(HawkMapHelper.satelliteLayer, {
			zIndex : 0
		}),
	};

	layers.Streets.addTo(map);
	L.control.layers(layers, {}).addTo(map);

	new L.Control.Zoomslider({
		position : 'topright'
	}).addTo(map);

	map.scrollWheelZoom.disable();
    
    <?php
    if (!empty($facilities))
		echo 'var facilities = '.$facilities.';';
	else
		echo  'var facilities = null';
    ?>
    var facilities = <?php echo $facilities; ?>;

	if (facilities && facilities.length > 0) {
		mapResults(map, facilities);
	}
	

	$('.js-main-img').each(function(idx, element) {
		var $element = $(element);
		var imageUrl = $element.attr('data-bg') || 'img/eye.png';
		dch.media.resolveThumbnail(imageUrl).then(function(resolvedUrl) {
			$element.css('background-image', "url(" + encodeURI(resolvedUrl) + ")");
		});
	});

	$("#contact-help").popover();

	$("#sendEmail").click(function() {
		$("#contact-provider-form").submit();
	});

	$('#contact-provider-form').on('submit', function(event) {
		event.preventDefault();
		$.ajax({
			type : 'POST',
			url : '/listing/contact',
			data : $(this).serialize()
		}).done(function() {
			$('#emailSentModalToggle').click();
		}).fail(function(res, status, err) {
			// Show a modal indicating failure, but print details in console
			console.error(res);
			console.error("Error code: " + res.status + " " + res.statusText);
			$('#emailFailModalToggle').click();
		});
	});

	$("#phoneNumber").on("change", function() {
		var number = $(this).val().replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3").replace(/(\d)(\d{3})(\d{3})(\d{4})/, "$1-($2) $3-$4");
		$(this).val(number)
	});

    $.getJSON("/api/v1/markets/autocomplete/providers", function(data) {
        $("#provider-search").autocomplete({
            source : $.map(data, function(val, i) {
                return {
                    label : val.name,
                    url : val.url
                }
            }),
            minLength : 2,
            select : function(event, ui) {
                $("#provider-search").val(ui.item.label);
                window.location = "/providers" + ui.item.url;
                $("#loader").removeClass("hide");
                $("#loader").spin({ left: "50%", top: "50%" });
        		$(".spinner").css("position", "fixed");
            }
        });
    });

    if (facilities && facilities.length > 0) {
    	$("#owned-facilities").append($("#provider-card-template").render(facilities));
    }

	$(".contact-provider-link").click(function() {
		$("#contact-provider-form input[name='facilityId']").val($(this).parents(".facility-card").data("id"));
		$("#contactProviderModalToggle").click();
	});

	// ]]>
</script>-->

<script>
function initMap() {
  
  var locations = [
	<?php
	$cords=substr($cords,0,-1);
	echo $cords;
	?>
	];

  var map = new google.maps.Map(document.getElementById('map'), {
    center: {lat: 38.47939467327645, lng: -94.9658203125},
	zoom: 4,
	scrollwheel: false,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  });
 
  var infowindow = new google.maps.InfoWindow();

  var marker, i;
 
  for (i = 0; i < locations.length; i++) {  
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map
      });

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
		var contHtml = '<div class="leaflet-popup-content-wrapper"><div class="leaflet-popup-content" style="width: 361px;"><div class="marker-popup"><img style="width:60px;" src="'+locations[i][4]+'" class="facility-image-container"></div><div class="marker-content"><h4 class="ellipsize">'+locations[i][0]+'</h4><p class="ellipsize">'+locations[i][5]+'</p><a href="'+locations[i][6]+'" class="popup-profile-link">View Details »</a></div></div></div></div>';	
          infowindow.setContent(contHtml);
          infowindow.open(map, marker);
        }
      })(marker, i));
  }
  
  /*google.maps.event.addListener(layer, 'defaultviewport_changed', function() {
    var bounds = layer.getDefaultViewport();
	var ll = new google.maps.LatLng(<?php echo $latitude; ?>,<?php echo $longitude; ?>);
	
    bounds.extend(ll);
    map.fitBounds(bounds);
  });*/

  
}

    </script>
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCBzUFUhEkI_lZIQnPz5PeDhrhWCtGuLKA&signed_in=true&callback=initMap">
    </script>
       <style> 
	.search-magnifier {
		cursor: pointer;
	}
	#map {
        float: left;
        width: 100%;
        height: 400px;
        margin-bottom: 20px;
		z-index:1;
      }</style>	

<script>
function getProviderData(e, company_name) {
	var code = (e.keyCode ? e.keyCode : e.which);
	if (code == 13) {
		$('.search-box').show();
		$('.search-box').html('<div id="loadImg" style="position:absolute;left:41%;margin-top:35px;"><div><img src="ajax-loader.gif" /></div></div>');
		var company_name = encodeURI(company_name).replace('&', '%26');
		$.getJSON( "/networkfinder2/admin/getCompany.php?seacrh="+company_name, function( id_company ) {
				if (id_company) {
					document.location.href = '/networkfinder2/admin/index.php?id_provider='+id_company;
				} else {
					$('.search-box').html('No Provider Found!');
				}
		});
    }
}
</script>


		</div>
       <!-- Start Footer----->
		<?php include("includes/footer.php"); ?>
       <!-- End Footer ----->

	</div>
</body>
</html>
