<?php
// ------------------------------------- server configuration -------------------------------------
$host ='107.180.54.175';
$db = 'availabilityengine';
$user = 'c2fdb';
$password='pakistan';
$conn_sonar  = mysql_connect($host,$user,$password) or die('server information is not correct');
mysql_select_db($db,$conn_sonar) or die('database info not correct');
//=====================================End Server Configuration========================================

?>