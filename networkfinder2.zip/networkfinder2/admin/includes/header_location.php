<?php
include("../../includes/checkSession.php");

?>
<style>
.input-group-addon, .input-group-btn {
     width: 1%; 
     white-space: nowrap; 
    vertical-align: middle; 
	
}
#provider-content .provider-search-bar .search-bar svg {
    height: 18px;
    width: 21px;
}
svg:not(:root) {
    overflow: hidden;
}
.search-magnifier{
 cursor:pointer;
}
input[type="radio"]:checked:after {
    content: '\2022';
    font-size: 62px;
    position: relative;
    top: -28px;
    left: -3px;
    color: #108dcb;
    pointer-events: none;
}
</style>

<header class="container-fluid navbar navbar-default navbar-fixed-top hidden-print hawk-header" role="navigation">
	 
        <div class="container header-content hidden-print">
         
     
		<div class="navbar-header hidden-print">
			<button type="button" class="navbar-toggle collapsed hidden-xs" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span>
			</button>
			<div class="header-logo" style="float:left">
				<a class="navbar-brand" href="/"></a>
				<a class="xs-logo" href="">
					<img class="split-logo-eye" src="img/shared/dch-eye.png" />
					
				</a>
			</div>
            <div  style="float:right;width:450px;height:60px;margin-top:3%">
				
                    <div class="provider-search-bar">
                        <div class="input-group search-bar">
                          
                           <input id="provider-search" type="text" name="provider-search" class="form-control" placeholder=		
                            "Search by Location" style="height: 60px;
   							 font-size: 18px;color: #231f20;background-color: #EEEEEE;"/>
                            <span class="input-group-addon search-magnifier" style="background-color: #EEEEEE;border:none" ><svg style="					
							height: 18px;width: 21px;"><use xlink:href="/img/shared/icons.svg#search">
							</use></svg></span>
                        </div>
                    </div>
                </div>
        
			</div>

        
        
               
		<div class="collapse navbar-collapse hidden-print" id="bs-example-navbar-collapse-1">
			
            <ul class="nav navbar-nav navbar-right">
			   
                 <li class="secondary-item">
					<a href="#"> <input type="radio" name="selection" id="providers" value="providers" 
                    onclick="checkRadio()"/> 
                    PROVIDERS</a>
				</li>
				<li class="secondary-item">
               
					<a href="#"> <input type="radio" name="selection" id="locations" value="locations" checked="checked" 
                     onclick="checkRadio()"/> 
                    LOCATIONS</a>
				</li>
				<!--<li class="secondary-item">
					<a class="register-link"> GET STARTED </a>
				</li>-->
				<li class="secondary-menu dropdown">
					<a href="#" class="secondary-toggle dropdown-toggle" data-toggle="dropdown">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
					<ul class="dropdown-menu" role="menu">
						<li>
							<a href="/blog">BLOG</a>
						</li>
						<li>
							<a href="/index.php">PROVIDERS</a>
						</li>
						<li>

								<a class="register-link"> GET STARTED </a>


						</li>
					</ul>
				</li>

				<li>

						<a id="login-toggle" class="boxed-link" onclick="showLoginView(event, this);">
							Hi, <?php echo $_SESSION['uname']; ?>
						</a>

				</li>
			</ul>
		</div>
		<!-- /.navbar-collapse -->
		<div id="login-view" class="hidden-print">
			<a href="../includes/logout.php"> <span>LOGOUT</span></a>
				<div>
				
		</div>
		<div class="xs-burger">
			<a href="#">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
		</div>
	</div>
	<!-- /.container-fluid -->
	<div id="product-container" class="inactive">
		<ul class="product-dropdown" role="menu">
			<li>
				<a href="/admin/index.php">
					<svg><use xlink:href="/img/shared/icons.svg#search"></use></svg>
					<span class="product-name">Provider Search</span>
				</a>
			</li>
			<li>
				<a href="/admin/locations.php">
					<svg><use xlink:href="/img/shared/icons.svg#swap"></use></svg>
					<span class="product-name">Location Search</span>
				</a>
			</li>
			<li>
				<a href="#">
					<svg><use xlink:href="/img/shared/icons.svg#zoom"></use></svg>
					<span class="product-name">Financials</span>
				</a>
			</li>
			<li>
				<a href="#">
					<svg><use xlink:href="/img/shared/icons.svg#scope"></use></svg>
					<span class="product-name">Insights</span>
				</a>
			</li>
		<!----	
            <li>
				<a href="/compare" data-redirect="redirect:/?r=sr">
					<svg><use xlink:href="/img/shared/icons.svg#compare"></use></svg>
					<span class="product-name">Compare</span>
				</a>
			</li>
			<li>
				<a href="/financials" data-redirect="redirect:/?r=sr">
					<svg><use xlink:href="/img/shared/icons.svg#finance"></use></svg>
					<span class="product-name">Financials</span>
				</a>
			</li>
			<li>
				<a href="/insight">
					<svg><use xlink:href="/img/shared/icons.svg#research"></use></svg>
					<span class="product-name">Insight</span>
				</a>
			</li>
            ---->
		</ul>
	</div>
	<script>
		// <![CDATA[
		$(document).on("click", function (evt) {
			if ($("#login-view").is(':visible')) {
				if(evt.target.id == "login-toggle" || evt.target.offsetParent !== null && evt.target.offsetParent.id == "login-view") {
					return;
				} else {
					$("#login-view").toggle();
				}
			} else {
				return;
			}
		});

		$("#login-view").click(function() {
			event.stopPropagation();
		});

		function showLoginView(vent, element) {
			$("#login-view").toggle();
			if ($("#login-view").is(":visible")) {
				$("#login-view input[name='j_username']").focus();
			}
			if (event.stopPropagation) {
			    event.stopPropagation();   // W3C model
			} else {
			    event.cancelBubble = true; // IE model
			}
		}

		$(".product-dropdown li").click(function(event) {
			var redirect = $(this).children("a").attr("data-redirect");
			if (redirect) {
				var query;

				if (redirect.indexOf("select-market") > 0) {
					query = "sm";
				} else {
					query = redirect.split("=")[1]
				}

				event.preventDefault();
				event.stopPropagation();
				HawkModal.toggle(query);
			} else {
				window.location = $(this).children("a").attr("href");
			}
		});

		$(document).on(
				'touchstart',
				function(e) {
					if (!$(e.target).parent().parent()
							.hasClass("product-dropdown")) {
						$('header [data-toggle="dropdown"]').parent()
								.removeClass('open');
					}
				});

		$("#product-toggle").click(function() {
			if (!$(this).children(".dropdown-toggle").hasClass("menu-on")) {
				$(this).children(".dropdown-toggle").addClass("menu-on");
				$("#product-toggle").children(".dropdown-toggle").find("svg use").attr("xlink:href", "/img/shared/icons.svg#caret-up")
				$("#product-container").removeClass("inactive");
			} else {
				$(this).children(".dropdown-toggle").removeClass("menu-on");
				$("#product-container").addClass("inactive");
				$("#product-toggle").children(".dropdown-toggle").find("svg use").attr("xlink:href", "/img/shared/icons.svg#caret-down")
			}
		});

		$(".xs-burger").click(function() {
			if ($(".xs-menu").hasClass("open")) {
				$(".xs-menu").removeClass("open");
				$(".hawk-content").show();
			} else {
				$(".xs-menu").addClass("open");
				$(".hawk-content").hide();
			}
		});
		
		//]]>
	</script>
       <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCBzUFUhEkI_lZIQnPz5PeDhrhWCtGuLKA&signed_in=true&libraries=places&callback=locationSuggestion">
    </script>

    <script>
function locationSuggestion(){
    
	var input = document.getElementById('provider-search');
    var searchBox = new google.maps.places.SearchBox(input);
    map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
}
</script>
   
</header>

