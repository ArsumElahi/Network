<?php

// ------------------------------------- server configuration -------------------------------------
$host ='107.180.20.86';
$db = 'fiber_information';
$user = 'FiberIndustry';
$password='pakistan123$$';
$conn_edison  = mysql_connect($host,$user,$password) or die('server information is not correct');
mysql_select_db($db,$conn_edison) or die('database info not correct');
//=====================================End Server Configuration========================================
echo 'here';
exit;
?>
