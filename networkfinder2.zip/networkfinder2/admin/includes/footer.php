<footer class="group hidden-print" style="position:relative">
<script src="js/jquery.validate.min.js"></script>
	<div class="container hidden-print">
		<div class="col-sm-3">
			<img src="//p6.zdassets.com/hc/settings_assets/1086441/200323487/t1xK5wLNxfHtRXum4xBEUA-SmallLogo.png" class="dch-text" />
			<h5>105b South Street</h5>
			<h5>Hopkinton, MA 01748</h5>
			<h5>508-202-1807</h5>
		</div>
		<div class="col-sm-3 hidden-xs">
			<h3>PRODUCTS</h3>
			<ul id="product-links">
				<li><a href="/admin/index.php"><svg><use xlink:href="/img/shared/icons.svg#search"></use></svg> Provider Search</a></li>
				<li><a href="/admin/locations.php"><svg><use xlink:href="/img/shared/icons.svg#swap"></use></svg> Location Search</a></li>
				<li><a href="#"><svg><use xlink:href="/img/shared/icons.svg#zoom"></use></svg> Financials</a></li>
				<li><a href="#"><svg><use xlink:href="/img/shared/icons.svg#scope"></use></svg> Insights</a></li>
			<!---	<li><a href="/compare" data-redirect="redirect:/?r=sr"><svg><use xlink:href="/img/shared/icons.svg#compare"></use></svg> Compare</a></li>
				<li><a href="/financials" data-redirect="redirect:/?r=sr"><svg><use xlink:href="/img/shared/icons.svg#finance"></use></svg> Financials</a></li>
				<li><a href="/insight"><svg><use xlink:href="/img/shared/icons.svg#research"></use></svg> Insight</a></li>
		--->
        	</ul>
		</div>
		<div class="col-sm-3">
			<h3>COMPANY</h3>
			<ul>
				<li><a href="#">About Us</a></li>
				<li><a href="#">Contact &amp; Support</a></li>
				<li><a href="#">Terms Of Service</a></li>
				<li><a href="#">Privacy Policy</a></li>
			</ul>
		</div>
		<div class="col-sm-3">
			<h3>JOIN OUR MAILING LIST</h3>
			<div class="input-group">
				<!-- Begin MailChimp Signup Form -->
				<form action="" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" novalidate>
					<input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL" placeholder="Email Address" />
					<!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
					<div style="position: absolute; left: -5000px;"><input type="text" name="b_e29554836bc3f28aeb3231def_8adad796fd" tabindex="-1" value="" /></div>
					<span class="input-group-addon button" type="submit" name="subscribe" id="mc-embedded-subscribe"><svg id="email-icon-button"><use xlink:href="/img/shared/icons.svg#email"></use></svg></span>
				</form>
				<script>$("#mc-embedded-subscribe-form").validate();</script>
			</div>
			<div id="mce-responses" class="clear">
				<div class="response" id="mce-success-response">Email address added! You should receive a confirmation email shortly.</div>
				<div class="response" id="mce-error-response">Error, please try again later.</div>
			</div>
			<a href="/listingLinks"><h3>SEARCH BY STATES</h3></a>
		</div>
	</div>
	<div class="bottom-bar hidden-print">
		<div class="container">
			<span>&copy; 2015 Connected2Fiber  All Rights Reserved</span>

				<span>, Maps &copy;</span>
				<a class="map-attribution" target="_blank" href="https://www.mapbox.com/about/maps/">Mapbox &amp; OpenStreetMap</a>

			<ul>

				<li><a href="https://www.linkedin.com/company/connected2fiber" target="_blank"><svg><use xlink:href="/img/shared/icons.svg#linkedin-circle"></use></svg></a></li>
				<li><a href="https://twitter.com/connected2fiber" target="_blank"><svg><use xlink:href="/img/shared/icons.svg#twitter-circle"></use></svg></a></li>
				<li><a href="https://plus.google.com/112831127646763053299" target="_blank"><svg><use xlink:href="/img/shared/icons.svg#google-plus-circle"></use></svg></a></li>
			</ul>
		</div>
	</div>
	<script>
		//<![CDATA[
		    $("#mce-EMAIL").keyup(function(event){
			    if(event.keyCode == 13){
			        $("#mc-embedded-subscribe").click();
			    }
			});

			$("#mc-embedded-subscribe").click(function() {
				$("#mce-success-response").hide();
				$("#mce-error-response").hide();

				if ($("#mc-embedded-subscribe-form").valid()) {
					$.ajax({
						type: 'POST',
						contentType: "application/json",
						url: 'api/v1/maintenance/listSubscribe',
						data: JSON.stringify({
							emailAddress: $("#mce-EMAIL").val()
						})
					}).done(function() {
						$("#mce-EMAIL").val("");
						$("#mce-success-response").show();
					}).fail(function(jqXHR, textStatus, errorThrown) {
						$("#mce-error-response").show();
					});
				}
			});

			$("footer #product-links a").click(function() {
				var redirect = $(this).attr("data-redirect");
				if (redirect) {
					HawkModal.toggle(redirect.split("=")[1]);
					return false;
				}

				return true;
			});

			$("input").placeholder();
		//]]>
	</script>
	<!--VISISTAT SNIPPET//-->
	<script>
		//<![CDATA[
		var DID=245630;
        var MyID=''
        var pssl=(window.location.protocol == "https:") ? "https://stats.sa-as.com/lib.js":"http://stats.sa-as.com/lib.js";
        document.writeln('<scr'+'ipt async src="'+pssl+'" type="text\/javascript"><\/scr'+'ipt>');
		//]]>
	</script>
	<!--VISISTAT SNIPPET//-->
</footer>
