<?php
$host ='107.180.20.86';
$db = 'fiber_information';
$user = 'FiberIndustry';
$conn  = mysql_connect($host,$user,'pakistan123$$') or die('server information is not correct');
mysql_select_db($db,$conn) or die('database info not correct');

$query = array();
$data = array();
    $getCompany = mysql_query('select company_name,id_company from ifimt_company where company_name like "%'.$_GET['provider_search'].'%"');
	$id_company = mysql_result($getCompany, 0, 'id_company');
	if (empty($id_company)) {
		$id_company = mysql_query('select name,id_company from ifimt_company_names where name like "'.$_GET['provider_search'].'"');
	 while($row = mysql_fetch_array($id_company)){
           
		    $data['label'] = $row['name'];
		    $data['id'] = $row['id_company'];
		   
		    $query[] = $data;
     }
	}
	else{
	while($row = mysql_fetch_array($getCompany)){
           $data['label'] = $row['company_name'];
		   $data['id'] = $row['id_company'];
		   
		   $query[] = $data;
     }
	
	}
  
 	
      echo json_encode($query);      
	  //echo 'select id_company from ifimt_company where company_name like "'.$_GET['provider_search'].'%"';
?>