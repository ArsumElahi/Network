// JavaScript Document
$(function() {
	// Make click events pass through our svg icons
	$('svg > use:only-child').parent().css('pointer-events', 'none');
});

function ColorLuminance(hex, lum) {
	// validate hex string
	hex = String(hex).replace(/[^0-9a-f]/gi, '');
	if (hex.length < 6) {
		hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
	}
	lum = lum || 0;
	// convert to decimal and change luminosity
	var rgb = "#", c, i;
	for (i = 0; i < 3; i++) {
		c = parseInt(hex.substr(i * 2, 2), 16);
		c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
		rgb += ("00" + c).substr(c.length);
	}
	return rgb;
}

function getUrlVars() {
	var vars = [], hash;
	var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
	for (var i = 0; i < hashes.length; i++) {
		hash = hashes[i].split('=');
		vars.push(hash[0]);
		vars[hash[0]] = hash[1];
	}
	return vars;
}

function getInternetExplorerVersion()
// Returns the version of Internet Explorer or a -1
// (indicating the use of another browser).
{
	var rv = -1; // Return value assumes failure.
	if (navigator.appName == 'Microsoft Internet Explorer') {
		var ua = navigator.userAgent;
		var re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
		if (re.exec(ua) != null)
			rv = parseFloat(RegExp.$1);
	}
	return rv;
}

var HawkSlider = {
	units : {
		kW : {
			prefix : "",
			suffix : " kW"
		},
		SF : {
			prefix : "",
			suffix : " SF"
		},
		money : {
			prefix : "$",
			suffix : ""
		},
		pennies : {
			prefix : "$0.",
			suffix : ""
		},
		percent : {
			prefix : "",
			suffix : "%"
		},
		comma : {
			prefix : "",
			suffix : ""
		},
		construct : function(value, unit) {
			if (!unit) {
				return value;
			}
			return unit.prefix + value + unit.suffix;
		}
	},
	makeTooltip : function(value, sliderX, width) {
		var tooltip = $('<div class="tooltip top slider-tip"><div class="tooltip-arrow"></div><div class="tooltip-inner">' + value + '</div></div>');
		var left = -45;
		var halfWidth = 45;
		if (width === undefined) width = 220;

		if (sliderX - halfWidth < 0) {
			$(tooltip).find(".tooltip-inner").css("left", left + 0 - sliderX + halfWidth - 10);
		}
		if (sliderX + halfWidth > width) {
			$(tooltip).find(".tooltip-inner").css("left", left - (sliderX + halfWidth - width) + 10);
		}
		return tooltip;
	},
	formatSliderValue : function(slider, value) {
		if ($(slider).hasClass("units-kw")) {
			return HawkSlider.units.construct(value.toLocaleString(), HawkSlider.units.kW);
		} else if ($(slider).hasClass("units-sf")) {
			return HawkSlider.units.construct(value.toLocaleString(), HawkSlider.units.SF);
		} else if ($(slider).hasClass("units-money")) {
			return HawkSlider.units.construct(value.toLocaleString(), HawkSlider.units.money);
		} else if ($(slider).hasClass("units-pennies")) {
			value = value * 10;
			if (value < 100) {
				value = "0" + value
			}
			return HawkSlider.units.construct(value, HawkSlider.units.pennies);
		} else if ($(slider).hasClass("units-percent")) {
			return HawkSlider.units.construct(value, HawkSlider.units.percent);
		} else if ($(slider).hasClass("units-comma")) {
			if (value >= 1000000) {
				value = (value / 1000000) + "M";
			} else if (value >= 1000) {
				value = (value / 1000) + "k";
			} 
		}
		return value;
	}
}

function capitalize(string) {
	return string.charAt(0).toUpperCase() + string.slice(1);
}

var $headerPadding = 0;

$(document).ready(function() {
	$headerPadding = $("header").css("padding-right");

	$(".modal").on("show.bs.modal", function(e) {
		var $newPadding = parseFloat($headerPadding.replace(/px/, "")) + parseFloat(getScrollbarWidth());
		$("header").css("padding-right", $newPadding + "px");
		
		$(this).on("hide.bs.modal", function(e) {
			$("header").css("padding-right", $headerPadding);
		});
	});
});

// borrowed from http://davidwalsh.name/detect-scrollbar-width ; bootstrap uses the same technique
function getScrollbarWidth() {
	var scrollDiv = document.createElement("div");
	scrollDiv.className = "modal-scrollbar-measure"; // just cheat and use the bootstrap class
	document.body.appendChild(scrollDiv);
	var scrollbarWidth = scrollDiv.offsetWidth - scrollDiv.clientWidth;
	document.body.removeChild(scrollDiv);
	
	return scrollbarWidth;
}