// JavaScript Document

var mapboxUtils = (function(){
    var accessToken = "pk.eyJ1IjoiZGF0YWNlbnRlcmhhd2siLCJhIjoialFYZEFGMCJ9.rWMIf6AzzR708bI2-rHtEA";
    
    return {
        getStaticMap: function(lat, lon, zoom, width, height, mapId, geoJson) {
            var mapIds = "";
            if(mapId && mapId.constructor === Array) {
                for(var i=0;i<mapId.length;i++) {
                    mapIds += mapId[i];
                    if(i!=mapId.length-1) {
                        mapIds += ',';
                    }
                }
            } else {
                mapIds = mapId;
            }
            if(!geoJson) {
                return 'https://api.tiles.mapbox.com/v4/'+mapIds+'/'+lon+','+lat+','+zoom+'/'+width+'x'+height+'.png?access_token='+accessToken+'';
            } else {
                
            }
            return 'https://api.tiles.mapbox.com/v4/'+mapIds+'/geojson('+encodeURIComponent(JSON.stringify(geoJson))+')/'+lon+','+lat+','+zoom+'/'+width+'x'+height+'.png?access_token='+accessToken+'';
        }
    }
})();