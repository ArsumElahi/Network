// JavaScript Document

window.dch = window.dch || {};
window.dch.util = (function($) {
	return {
		allResolved: function(promiseArray) {
			return $.when.apply($, promiseArray).then(function() {
				//NOTE: bad performance according to: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/arguments
				return Array.prototype.slice.call(arguments);
			});
		}
	};
})(jQuery);
