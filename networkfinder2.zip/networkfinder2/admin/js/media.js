// JavaScript Document
window.dch = window.dch || {};
window.dch.media = (function($) {

	function isVideoLink(theSrc) {
		if (theSrc == null) {
			return null;
		}
		if (theSrc.indexOf("youtube") > -1 || theSrc.indexOf("youtu.be") > -1 || theSrc.indexOf("vimeo") > -1) {
			return true;
		}
		else {
			return false;
		}
	}

	//Returns a promise with the thumbnail url, whether the originalUrl
	//is to an image, a youtube video, or a vimeo video
	function resolveThumbnail(originalUrl) {	
		var thumbnailUrl = originalUrl || '';
		
		if (isVideoLink(originalUrl)) {
			if (originalUrl.indexOf("youtube") > -1) {
				thumbnailUrl = originalUrl.replace("youtube.com/watch?v=", "img.youtube.com/vi/");
				thumbnailUrl = thumbnailUrl.replace("www.", "") + '/hqdefault.jpg';
			}
			else if (originalUrl.indexOf("youtu.be") > -1) {
				thumbnailUrl = originalUrl.replace("youtu.be", "img.youtube.com/vi/") + '/hqdefault.jpg';
			}
			else if (originalUrl.indexOf("vimeo") > -1 ) {
				var vimeoVideoID = originalUrl.replace(/\D/g,'');
				//If it's a vimeo video, return a promise wrapping the thumbnail returned from calling their API
				return $.getJSON('https://www.vimeo.com/api/v2/video/' + vimeoVideoID + '.json?callback=?', {format: "json"}).then(function(data) {
					return data[0].thumbnail_large;
				});
			}
		}

		//Wrap the result in a promise & return if we haven't returned yet
		var deferred = $.Deferred();
		deferred.resolve(thumbnailUrl);
		return deferred.promise();
	}

	return {
		isVideoLink: isVideoLink,
		resolveThumbnail: resolveThumbnail
	};

})(jQuery);

