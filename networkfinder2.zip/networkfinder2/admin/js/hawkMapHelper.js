// JavaScript Document

var HawkMapHelper = {
    hawkDataLayer: null,
    hawkNuclearLayer: null,
    forPDF: false,
    streetsLayer: 'datacenterhawk.8fdaf572',
    searchStreetsLayer: 'datacenterhawk.a5611407',
    satelliteLayer: 'datacenterhawk.2e6f4d51',
    riversLayer: 'datacenterhawk.7ba68784',
    highwaysLayer: 'datacenterhawk.647ec618',
    airportsLayer: 'datacenterhawk.99d54d2b'
};

function getIconSVG(classification) {
    var icon;

    if (classification === 'Colocation') {
        icon = 'colo';
    } else if (classification === 'Cloud') {
        icon = 'cloud';
    } else if (classification === 'Site') {
        icon = 'site';
    } else if (classification === 'Shell') {
        icon = 'shell';
    } else if (classification === 'InternetExchange') {
        icon = 'internetExchange';
    } else {
        icon = 'enterprise';
    }

    return '<svg class="' + getIconColor(classification) + '"><use xlink:href="/img/shared/icons.svg#' + icon + '"/></svg>';
}

function getIconColor(classification) {
    if (classification === 'Colocation') {
        return 'bg-secondary-orange';
    } else if (classification === 'Cloud') {
        return 'bg-primary-blue';
    } else if (classification === 'Site') {
        return 'bg-secondary-blue';
    } else if (classification === 'Shell') {
        return 'bg-secondary-gray';
    } else if (classification === 'InternetExchange') {
        return 'bg-primary-dark-blue';
    } else {
        return 'bg-crimson';
    }
}

function createIconForFacility(facility, orderNumber) {
	if (HawkMapHelper.forPDF){
		return L.divIcon({
	        className: 'location-icon ' + getIconColor(facility.classification),
	        html: '<div class="search-order-number">' + orderNumber + '</div>',
	        iconSize: [30, 30]
	    });
	} else {
		return L.divIcon({
	        className: 'location-icon ' + getIconColor(facility.classification),
	        html: getIconSVG(facility.classification),
	        iconSize: [18, 18]
	    });
	}
}

function createIconForNucleurHazard(facility) {
	if (HawkMapHelper.forPDF){
		return L.divIcon({
	        className: 'radioactive-icon $secondary-yellow',
	        html: '<svg><use xlink:href="/img/Radioactive_Symbol_1946.svg#radioactive"/></svg>',
	        iconSize: [30, 30]
	    });
	} else {
		return L.divIcon({
	        className: 'radioactive-icon $secondary-yellow',
	        html: '<svg><use xlink:href="/img/Radioactive_Symbol_1946.svg#radioactive"/></svg>',
	        iconSize: [18, 18]
	    });
	}
}

function createPopupContentForFacility(facility) {
    var popupContent = '<div class="marker-popup">';

    if (facility.image) {
        popupContent += '<div class="facility-image-container" style="background-image: url(\'' + facility.image + '\');"></div>';
    }

    var minWidth = (facility.image ? 360 : 240);

    popupContent += '<div class="marker-content' + (facility.image ? '' : ' no-image') + '"><h4 class="ellipsize">' + facility.name + '</h4>';

    if (facility.classification !== 'edc') {
        if (facility.address) {
            popupContent += '<p class="ellipsize">' + facility.address;
            if (facility.companyCode) {
                popupContent += ' / ' + facility.companyCode;
            }
            popupContent += '</p>';
        }

        if (facility.city) {
            popupContent += '<p class="ellipsize">' + facility.city;
            if (facility.state) {
                popupContent += ', ' + facility.state;
            }
            popupContent += '</p>';
        }
        if (facility.classification !== 'InternetExchange') {
        	popupContent += '<a class="popup-profile-link" href="javascript:goToFacility(\'' + facility.url + '\');">View Profile &raquo;</a>';
        }
        
    } else {
        minWidth = 250;
    }

    popupContent += '</div></div>';

    return {
        content: popupContent,
        options: {
            minWidth: minWidth,
            className: 'search-popup-container'
        }
    };

}

function goToFacility(url) {
	var stringUrl = url;
	var zoomLevel = map.getZoom();
	var center = map.getCenter();
	$.cookie("facility_map_position", {
		zoom : zoomLevel,
		center : center
	});
	window.location.href = stringUrl;
}

function addDataLayer(e) {
    var marker = e.layer;
    var feature = marker.feature;
    var facility = feature.properties.facility || {};
    var orderNumber = parseInt(feature.properties.orderNumber || {}); 
    if (orderNumber != null){
    	if (isNaN(orderNumber)){
    		orderNumber = 1;
    	}else{
    		orderNumber = orderNumber + 1;
    	}
    }
    marker.setIcon(createIconForFacility(facility, orderNumber));
    var popup = createPopupContentForFacility(facility);
    marker.bindPopup(popup.content, popup.options);
}

function addNuclearDataLayer(e) {
    var marker = e.layer;
    var feature = marker.feature;
    marker.setIcon(createIconForNucleurHazard());
}

function mapResults(map, data, market, forPDF) {
    var geojson = {
        type: 'FeatureCollection',
        features: []
    };
    
    if (forPDF){
    	HawkMapHelper.forPDF = forPDF;
    }

    if (HawkMapHelper.hawkDataLayer) {
        map.removeLayer(HawkMapHelper.hawkDataLayer);
    }

    HawkMapHelper.hawkDataLayer = L.mapbox.featureLayer().addTo(map);

    if (data.length > 0) {

        $.each(data, function (i, facility) {
            if (facility.lon && facility.lat) {
                geojson.features.push({
                    type: 'Feature',
                    geometry: {
                        type: 'Point',
                        coordinates: [facility.lon, facility.lat]
                    },
                    properties: {
                        'facilityData': facility,
                        'marker-size': 'small',
                        'title': facility.name,
                        'facility': facility,
                        'orderNumber': i
                    }
                });
            }
        });

        HawkMapHelper.hawkDataLayer.on('layeradd', addDataLayer);
        	HawkMapHelper.hawkDataLayer.setGeoJSON(geojson);

        if (market && market.lat && market.lon) {
            var zoomLevel = market.zoomLevel;
            if (!zoomLevel) {
                zoomLevel = 10;
            }

            map.setView([market.lat, market.lon], zoomLevel);
        }

    } else {
        HawkMapHelper.hawkDataLayer.setGeoJSON({
            type: 'FeatureCollection',
            features: []
        });
    }
}

function mapNuclearPlants(map, data) {
    var geojson = {
        type: 'FeatureCollection',
        features: []
    };

    if (HawkMapHelper.hawkNuclearLayer) {
        map.removeLayer(HawkMapHelper.hawkNuclearLayer);
    }

    HawkMapHelper.hawkNuclearLayer = L.mapbox.featureLayer().addTo(map);

    if (data != null && data.length > 0) {

        $.each(data, function (i, plant) {
            if (plant.lon && plant.lat) {
                geojson.features.push({
                    type: 'Feature',
                    geometry: {
                        type: 'Point',
                        coordinates: [plant.lon, plant.lat]
                    },
                    properties: {
                        'marker-size': 'small',
                        'title': name
                    }
                });
            }
        });

        HawkMapHelper.hawkNuclearLayer.on('layeradd', addNuclearDataLayer);
        HawkMapHelper.hawkNuclearLayer.setGeoJSON(geojson);

    } else {
        HawkMapHelper.hawkNuclearLayer.setGeoJSON({
            type: 'FeatureCollection',
            features: []
        });
    }
}

function setMapBounds(map, radius) {
    var bounds = getBoundsFromRadius(map.getCenter(), radius);

    map.setMaxBounds(bounds);
    //map.fitBounds(bounds);
}

function setMapPlusUserBounds(center, radius) {
    var bounds = getBoundsFromRadius(center, radius);

    map.setMaxBounds(bounds);
    //map.fitBounds(bounds);
}

function getBoundsFromRadius(center, radius) {
    var x = Math.cos(Math.PI / 4) * radius;
    var y = Math.sin(Math.PI / 4) * radius;
    var latDelta = milesToLatitude(x);
    var lngDelta = milesToLongitude(latDelta, y);
    //console.log('Distance in m: ' + (center.distanceTo(L.latLng(center.lat - latDelta, center.lng + lngDelta))));
    var bounds = L.latLngBounds(
        L.latLng(center.lat - latDelta, center.lng + lngDelta),
        L.latLng(center.lat + latDelta, center.lng - lngDelta));

    return bounds;
}

function milesToLatitude(miles) {
    var earthRadius = 3960.0;
    var radToDeg = 180 / Math.PI;
    return (miles / earthRadius) * radToDeg;
}

function milesToLongitude(lat, miles) {
    var earthRadius = 3960.0;
    var degToRad = Math.PI / 180;
    var radToDeg = 180 / Math.PI;
    var r = earthRadius * Math.cos(lat * degToRad);
    return (miles / r) * radToDeg;
}