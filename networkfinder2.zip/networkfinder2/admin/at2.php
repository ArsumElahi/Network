<?php include("../includes/checkSession.php"); ?>

<!DOCTYPE HTML>

<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if IE 9]>    <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js" lang="en" prefix="og: http://ogp.me/ns#">
<!--<![endif]-->

<head><meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />




	<title>Equinix Data Center -Connected2Fiber</title>


<meta name="description" content="Learn about the Equinix data center at 56 Marietta Street NW; 5th Floor from Connected2Fiber" />


<meta name="author" content="Connected2Fiber" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
<meta name="viewport" content="width=device-width" />


	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:site" content="@Connected2Fiber" />
	<meta property="og:title" content="Equinix" />
	<meta property="og:description" content="Equinix is a global data center company providing colocation, interconnection, and connectivity services to users. The California-based company has over 100 data centers in 32 markets throughout the world, and gives access to over 450+ cloud providers in their portfolio. Equinix IBX data centers offer reliability, power density, security and recovery services, while in secure space that is efficiently operated. Equinix pricing is typically higher priced due to the ecosystems created in Equinix facilities and access to cloud and connectivity services. The company officially became a REIT (real estate investment trust) in Q1 2015." />
	<meta property="og:image" content="https://www.datacenterhawk.com/cmsstatic/colo/118993/Screen Shot 2016-04-11 at 8.39.41 AM.png" />
	<meta property="og:url" content="https://www.datacenterhawk.com/colo/equinix/56-marietta-street-nw-5th-floor/at2" />


<link rel="stylesheet" href="css/jquery.rating.css" />
<link rel="icon" type="image/png" href="img/shared/favicon.png" />



<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap-edited.min.css" />

<!-- Optional theme -->
<link rel="stylesheet" href="css/bootstrap-theme.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="css/dataTables.fixedColumns.min.css" />

<link rel="stylesheet" href="css/main-1091214527.css" />

<!-- Latest compiled and minified JavaScript -->
<script src="js/jquery-2.1.1.min.js"></script>

<script src="js/jquery-ui.min.js"></script>
<script src="js/jquery.ui.touch-punch.min.js"></script>

<script src="js/bootstrap.min.js"></script>

<script src="js/libs/jquery.dataTables.min.js"></script>
<script src="js/libs/dataTables.fixedColumns.min.js"></script>

<script src="js/libs/modernizr-2.5.3.min.js"></script>

<script src="js/heap-analytics.js"></script>

<script src="js/hawk.js"></script>
<script src="js/util.js"></script>
<script src="js/media.js"></script>
<script src="js/mapbox.utils.js"></script>

<script src="js/mapbox.js"></script>
<link href="css/mapbox.css" rel="stylesheet" />
<script src="js/NonTiledLayer.js"></script>
<script src="js/NonTiledLayer.WMS.js"></script>

<script src="js/svg4everybody.js"></script>
<script src="js/jquery.placeholder.js"></script>
<!-- Google Tag Manager -->
<noscript>
	<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KRVGLX" height="0" width="0" style="display: none; visibility: hidden"></iframe>
</noscript>
<script>/*<![CDATA[*/(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NTMD2G');/*]]>*/</script>
<!-- End Google Tag Manager -->

<!-- TypeKit for ProximaNova font -->
<script src="https://use.typekit.net/aan4rbc.js"></script>
<script>
	try {
		Typekit.load();
	} catch (e) {
	}
	svg4everybody();
</script>

<script type="text/javascript" src="js/lib-1305157643.js"></script>

<script type="text/javascript" src="js/heatclinic-119894065.js"></script>
</head>

<body id="catalog-product">
	<div class="hawk-content-wrapper texture-bg">
       <!-- Start Header----->
	  	   <?php  include("includes/header.php");?>
       <!-- End Header----->

<div><button id="noAccessModalToggle" data-toggle="modal" data-target="#noAccessModal" class="hidden"></button>
<div class="modal hawk-modal" id="noAccessModal" tabindex="-1" role="dialog" aria-labelledby="noAccessModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title" id="noAccessModalLabel"></h4>
			</div>
			<div class="modal-body">
				<h4 class="message ur">Upgrade now for access</h4>
				<h4 class="message sr">Subscribe now for access</h4>
				<h4 class="message sm">Select a market to begin using Fiber Products</h4>
				<span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#search"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#zoom"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#scope"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#compare"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#finance"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#research"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#swap"></use></svg></span>
				<form action="/support" class="message ur">
					<button>CONTACT US</button>
				</form>
				<form action="/plans" class="message sr">
					<button>SIGN UP</button>
				</form>
				<form action="/account/select-market" class="message sm">
					<button>SELECT MARKET</button>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	// <![CDATA[

	var isIE = /* @cc_on!@ */false || !!document.documentMode;

	var param = null;

	var HawkModal = {
		toggle : function(type) {
			$(".message", $("#noAccessModal")).hide();
			$("." + type, $("#noAccessModal")).show();
			$('#noAccessModalToggle').click();
		}
	};

	$('#noAccessModal').on('hidden.bs.modal', function () {
		if (window.location.search.indexOf("?r=") == 0) {
			window.location.search = "";
		}
	});

	$(function() {
		if (param && param.length > 0) {
			param = param[0];
			if (param == "sr" || param == "ur") {
				HawkModal.toggle(param);

			}
		}
	});
	//]]>
</script></div>
<div><button id="registerModalToggle" data-toggle="modal" data-target="#register-modal" class="hidden"></button>
<div class="modal hawk-modal" id="register-modal" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<h4>Register below to join now!</h4>
				<div class="form-wrapper">
					<form id="registration-form" method="POST" action="/register">
						<div class="col-md-12">
							<label>Company Email</label>
							<input type="email" id="customer.emailAddress" name="customer.emailAddress" />
							<div class="col-md-6">
								<label>First Name</label>
								<input type="text" id="customer.firstName" name="customer.firstName" />
							</div>
							<div class="col-md-6">
								<label>Last Name</label>
								<input type="text" id="customer.lastName" name="customer.lastName" />
							</div>
							<label>Password</label>
							<input type="password" id="password" name="password" />
							<label>Confirm Password</label>
							<input type="password" id="passwordConfirm" name="passwordConfirm" />
							<label class="tos-label"><input id="modal-confirm-tos" type="checkbox" /><span>
							I agree to Connected2Fiber's <a href="/terms-of-service" target="_blank">Terms of Service and Privacy Policy</a></span></label>
							<button type="submit" id="modal-register-button" class="register-button" data-dismiss="modal" disabled="disabled">Register</button>
						</div>
					<input type="hidden" name="csrfToken" value="ZWNA-PFM4-9V28-6CLZ-COOO-952I-571Y-QWBG" /></form>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	//<![CDATA[

	$(".register-link, .register-text").click(function() {
		$("#registerModalToggle").click();
	});

	$("#modal-register-button").click(function() {
		$("#registration-form").submit();
	})

	$("#modal-confirm-tos").click(function() {
		$("#modal-register-button").attr("disabled", !this.checked);
	});



	//]]>
</script></div>
	<div class="xs-menu">
		<ul>
			<li>
				<a href="/products">Products</a>
			</li>
			<li>
				<a href="/register">Register</a>
			</li>
			<li>
				<a href="/blog">Blog</a>
			</li>
			<li>
				<a href="/about">About Us</a>
			</li>
			<li>
				<a href="/support">Contact Us</a>
			</li>
			<li>
				<hr />
			</li>
			<li>
				<p>sales@connected2fiber.com</p>
			</li>
			<li>
				<p>508-202-1807</p>
			</li>
			<li class="address">
				<p>105b South Street</p>
				<p>Hopkinton, MA 01748</p>
			</li>
		</ul>
	</div>


		<div class="hawk-content" role="main">




<div>
	<input type="hidden" id="classification" value="Colocation" />
	<div class="listing-overview content-padding">
		<div class="container">
			<h3 class="visible-print listing-header-print">Equinix</h3>
			<div class="row">
				<div class="col-sm-6">
					<div class="product-card locked">
						<div class="row">
							<div class="product-title col-sm-12 col-md-9">
								<p class="not-premium"></p>
								<h3>Equinix</h3>
								<h4>Atlanta | Colocation</h4>
								<p class="product-address">
									<span>56 Marietta Street NW; 5th Floor</span> <span> / AT2</span>
								</p>
								<p class="product-address">Atlanta, Georgia 30303</p>
							</div>
							<div class="col-sm-3">
								<div class="product-downloads hidden-xs hidden-sm hidden-print">
									<div class="downloads-title">
										<span>DOWNLOADS</span><svg class="hidden-md"><use xlink:href="/img/shared/icons.svg#download"></use></svg>
									</div>
									<p>


										<a id="marketing-flyer" class="card-link-locked"><span class="hidden-md">Marketing </span>Flyer</a>
									</p>
									<p>

										<a id="profile-export-locked" class="card-link-locked">Profile PDF</a>
										<span><img class="ajax-loader" src="/admin/img/admin/ajax-loader.gif" style="padding-left: 5px; display: none;" /></span>
									</p>
								</div>
							</div>
						</div>
						<div class="product-actions hidden-xs hidden-print">
							<div class="row">
								<div class="action">
									<a href="#">
										<i class="fa fa-undo" aria-hidden="true"></i>
										<span class="return-search">RETURN TO SEARCH</span>
									</a>
									<img data-toggle="false" data-trigger="hover" data-placement="right" data-content="Add this facility to your favorites!" data-container="body" alt-src="img/star-30c80f991fa7de297cc3ef185ce5bb86.png" src="../img/star-empty-6b89bb871a323605172c2078ec570e6f.png" class="hidden-print" />
									<span class="favorites disabled">ADD TO FAVORITES</span>
								</div>
							</div>
							<form id="add-favorite-form" type="hidden" action="/account/favorites/add" method="POST">
								<input name="productId" id="productId" type="hidden" value="118993" />
								<input name="quantity" id="quantity" type="hidden" value="1" />
							<input type="hidden" name="csrfToken" value="ZWNA-PFM4-9V28-6CLZ-COOO-952I-571Y-QWBG" /></form>
							<form id="remove-favorite-form" type="hidden" method="POST" action="/account/favorites/remove">
								<input name="orderItemId" id="orderItemId" type="hidden" value="118993" />
							<input type="hidden" name="csrfToken" value="ZWNA-PFM4-9V28-6CLZ-COOO-952I-571Y-QWBG" /></form>
						</div>
						<div class="product-description hidden-xs">
							<p class="description-body">Equinix is a global data center company providing colocation, interconnection, and connectivity services to users. The California-based company has over 100 data centers in 33 markets throughout the world, and gives access to over 450+ cloud providers in their portfolio. Equinix operates their data centers under the International Business Exchange™ (IBX®) product name. The IBX system enables Equinix&#39;s partners and users to leverage a scalable, globally-connected technology platform for application, managed service, and information delivery.

Equinix pricing is typically higher due to the ecosystems created in Equinix facilities and access to cloud and connectivity services. In North America, Equinix revenues come from colocation and telecom interconnections while a mix of colocation and managed infrastructure services bring in more revenues for the rest of the world. For tax purposes, the company transitioned from a C-corporation to a real estate investment trust (REIT) in May 2015 effective for its taxable year commencing January 1, 2015.</p>
							<p class="more hidden-print">MORE</p>
						</div>
					</div>
				</div>
				<div class="col-sm-6 image-panel">


					<div id="image-carousel" class="carousel slide">
						<div class="carousel-inner">
							<div class="item active">
								<div class="bg-image"
								style="background-image: url(cmsstatic/colo/118993/Screen Shot 2016-04-11 at 8.39.41 AM.png)">
									<img class="" src="cmsstatic/colo/118993/Screen Shot 2016-04-11 at 8.39.41 AM.png" />
								</div>

								<div class="media-attribution">Media by: Equinix</div>
							</div>
							<a class="provider-logo" href="/providers/equinix"><img src="cmsstatic/dcproviders/219/Equinix_Logo_000001.jpg" />
							</a>
						</div>
						<div class="carousel-controls hidden-print">
							<ol class="carousel-indicators">
								<li data-target="#image-carousel" data-slide-to="0" class="active"></li>
								<li data-target="#image-carousel" data-slide-to="1"></li>
								<li data-target="#image-carousel" data-slide-to="2"></li>
								<li data-target="#image-carousel" data-slide-to="3"></li>
								<li data-target="#image-carousel" data-slide-to="4"></li>
							</ol>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6">
					<div class="contact-buttons row hidden-print">
						<div class="col-sm-6">
							<div class="button-holder contact">
								<svg><use xlink:href="/img/shared/icons.svg#email"></use></svg>
								<span>CONTACT PROVIDER</span>

							</div>
						</div>
						<div class="col-sm-6">
							<div class="button-holder provider-profile">
								<a href="/providers/equinix">
									<svg><use xlink:href="/img/shared/icons.svg#list"></use></svg>
									<span>PROVIDER PROFILE</span>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
	<div class="register-section hidden-print">
		<div class="register-band dark-band">
			<h4>Sign up now to see more about 56 Marietta Street NW; 5th Floor</h4>

		</div>
		<h3>Discover infrastructure, capacity, connectivity and compliance information.</h3>


		<h3>Find this and more with the datacenterHawk Tool Suite.</h3>
		<div class="container">
			<div class="tool-links row hidden-xs">
				<div class="col-sm-4">
					<div class="icon-holder">
						<svg><use xlink:href="/img/shared/icons.svg#search"></use></svg>
					</div>
					<h4 class="tool-title">Search</h4>
					<p class="tool-description">Search data centers by market, provider and capacity</p>
				</div>
				<div class="col-sm-4">
					<div class="icon-holder">
						<svg><use xlink:href="/img/shared/icons.svg#compare"></use></svg>
					</div>
					<h4 class="tool-title">Compare</h4>
					<p class="tool-description">Take search a step further with seamless and smooth comparisons</p>
				</div>
				<div class="col-sm-4">
					<div class="icon-holder">
						<svg><use xlink:href="/img/shared/icons.svg#scope"></use></svg>
					</div>
					<h4 class="tool-title">Scope</h4>
					<p class="tool-description">View powerful mapping technology evaluating power/fiber infrastructure</p>
				</div>
			</div>
			<hr class="hidden-xs" />
			<form id="product-register-form" method="POST" action="/register">
				<div class="row">
					<div class="col-sm-8 col-sm-offset-2">
						<div class="row">
							<div class="col-sm-12">
								<input type="email" placeholder="Company Email" id="customer.emailAddress" name="customer.emailAddress" />
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6">
								<input type="text" placeholder="First Name" id="customer.firstName" name="customer.firstName" />
							</div>
							<div class="col-sm-6">
								<input type="text" placeholder="Last Name" id="customer.lastName" name="customer.lastName" />
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6">
								<input type="password" placeholder="Password" id="password" name="password" />
							</div>
							<div class="col-sm-6">
								<input type="password" placeholder="Confirm Password" id="passwordConfirm" name="passwordConfirm" />
							</div>
						</div>
						<button type="submit" id="register-button" class="register-button">GET STARTED</button>
					</div>
				</div>
			<input type="hidden" name="csrfToken" value="ZWNA-PFM4-9V28-6CLZ-COOO-952I-571Y-QWBG" /></form>
		</div>
	</div>








	<div class="similar-facilities hidden-print">
		<div class="similar-band dark-band">
			<h4>OTHER SIMILAR DATA CENTERS</h4>
		</div>
		<div class="container">
			<div id="facility-carousel" class="carousel slide" data-ride="carousel" data-interval="false">
				<div class="carousel-inner">
					<div class="item active">
					</div>
					<div class="item hidden-xs">
					</div>
					<div class="item hidden-xs">
					</div>
				</div>
				<a class="left carousel-control hidden-xs" href="#facility-carousel" role="button" data-slide="prev">
					<svg><use xlink:href="/img/shared/icons.svg#caret-left"></use></svg>
				</a>
				<a class="right carousel-control hidden-xs" href="#facility-carousel" role="button" data-slide="next">
					<svg><use xlink:href="/img/shared/icons.svg#caret-right"></use></svg>
				</a>
				<div class="carousel-controls hidden-xs">
					<ol class="carousel-indicators">
						<li data-target="#facility-carousel" data-slide-to="0" class="active"></li>
						<li data-target="#facility-carousel" data-slide-to="1"></li>
						<li data-target="#facility-carousel" data-slide-to="2"></li>
					</ol>
				</div>
			</div>
		</div>
	</div>
	<div class="blog-section hidden-print">
		<h3>Get tips from our featured insights on the data center industry</h3>
		<hr />
		<div class="container">
			<div class="row">
				<div class="blog-card-outer col-sm-6">
					<div class="blog-card">
						<div class="blog-img-holder col-sm-4"
												style="background-image:url(cmsstatic/blog/3380/microcloud.jpg?blogThumbnail);"></div>
												<div class="blog-title col-sm-8">
													<h4>Data Center Market Movers: Atlanta</h4>
													<a href="/blog/data-center-market-movers-atlanta">READ FULL ARTICLE</a>
						</div>
					</div>
				</div>
				<div class="blog-card-outer col-sm-6">
					<div class="blog-card">
						<div class="blog-img-holder col-sm-4"
						style="background-image:url(cmsstatic/blog/15279/Screen_Shot_2016-08-09_at_12.38.29_PM.png?blogThumbnail);"></div>
						<div class="blog-title col-sm-8">
							<h4>The US Colocation Market &amp; The Impact of Large Cloud Transactions</h4>
							<a href="/blog/the-us-colocation-market-the-impact-of-large-cloud-transactions">READ FULL ARTICLE</a>
						</div>
					</div>
				</div>
				<div class="blog-card-outer col-sm-6">
					<div class="blog-card">
						<div class="blog-img-holder col-sm-4"
						style="background-image:url(cmsstatic/blog/3925/Colocation_Search_Graphic.jpg?blogThumbnail);"></div>
						<div class="blog-title col-sm-8">
							<h4>Where Data Center Professionals Searched for Colocation in 2015</h4>
							<a href="/blog/where-data-center-professionals-searched-for-colocation-in-2015">READ FULL ARTICLE</a>
						</div>
					</div>
				</div>
				<div class="blog-card-outer col-sm-6">
					<div class="blog-card">
						<div class="blog-img-holder col-sm-4"
						style="background-image:url(cmsstatic/blog/9031/Q1_Title.png?blogThumbnail);"></div>
						<div class="blog-title col-sm-8">
							<h4>Where Data Center Professionals Searched for Colocation in Q1 2016</h4>
							<a href="/blog/where-data-center-professionals-searched-for-colocation-in-q1-2016">READ FULL ARTICLE</a>
						</div>
					</div>
				</div>
				<div class="blog-card-outer col-sm-6">
					<div class="blog-card">
						<div class="blog-img-holder col-sm-4"
						style="background-image:url(cmsstatic/blog/2516/hawkinsight.png?blogThumbnail);"></div>
						<div class="blog-title col-sm-8">
							<h4>Four Challenges to Understanding Data Center Markets (and One Breakthrough Solution)</h4>
							<a href="/blog/four-challenges-to-understanding-data-center-markets-and-one-breakthrough-solution">READ FULL ARTICLE</a>
						</div>
					</div>
				</div>
				<div class="blog-card-outer col-sm-6">
					<div class="blog-card">
						<div class="blog-img-holder col-sm-4"
												style="background-image:url(cmsstatic/blog/13954/Screen_Shot_2016.png);"></div>
												<div class="blog-title col-sm-8">
													<h4>Q2 2016 Data Center Search: Our Analysis</h4>
													<a href="/blog/q2-2016-data-center-search-our-analysis">READ FULL ARTICLE</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<button id="contactProviderModalToggle" data-toggle="modal" data-target="#contactProviderModal" class="hidden"></button>
	<div class="modal fade hawk-modal" id="contactProviderModal" tabindex="-1" role="dialog" aria-labelledby="contactProviderModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="contactProviderModalLabel"></h4>
				</div>
				<div class="modal-body contact-provider">
					<h4>CONTACT Equinix FOR A QUOTE <svg id="contact-help" data-trigger="hover" data-placement="bottom" data-content="Submitting this form sends an email directly to the provider. Your information is key confidential and is not shared with any other parties"><use xlink:href="/img/shared/icons.svg#question"></use></svg>
					</h4>

					<h5>Fill out the information below to directly connect with Equinix. Our system connects with their representatives, who will contact you regarding your requested information.</h5>

					<div class="form-wrapper">
						<form id="contact-provider-form">
							<input type="hidden" name="facilityId" value="118993" />
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-6 contact-input-column">
										<input type="text" id="firstName" placeholder="First Name" tabindex="1" name="firstName" value="" />
										<input type="email" id="emailAddress" placeholder="Your Email" tabindex="3" name="emailAddress" value="" />
									</div>
									<div class="col-md-6 contact-input-column">
										<input type="text" id="lastName" placeholder="Last Name" tabindex="2" name="lastName" value="" />
										<input type="text" id="companyName" placeholder="Company Name" tabindex="4" name="companyName" value="" />
									</div>
								</div>
								<h5 class="advanced-options" data-toggle="collapse" data-target="#contact-modal-adv-opts">ADVANCED OPTIONS</h5>
								<svg id="adv-opts-caret"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/img/shared/icons.svg#caret-down"></use></svg>
								<div id="contact-modal-adv-opts" class="collapse">
									<div class="row">
										<div class="col-md-6">
											<div class="drop-holder input-group hawk-select">
												<select id="powerRequirement" name="powerRequirement" class="select-picker">
													<option value="first-option" class="first-option">Power Requirements</option>
													<option value="1/4 Rack">1/4 Rack</option>
													<option value="1/2 Rack">1/2 Rack</option>
													<option value="1 Rack">1 Rack</option>
													<option value="5-50 kW">5-50 kW</option>
													<option value="51-250 kW">51-250 kW</option>
													<option value="251-1000 kW">251-1000 kW</option>
													<option value="1000+ kW">1000+ kW</option>
												</select><span class="input-group-addon"> <svg><use xlink:href="/img/shared/icons.svg#caret-down"></use></svg></span>
											</div>
											<div class="drop-holder input-group hawk-select">
												<select id="connectivityRequirement" name="connectivityRequirement" class="select-picker">
													<option value="first-option" class="first-option">Connectivity Requirements</option>
													<option value="1-10 Mbs">1-100 Mbps</option>
													<option value="101-1000 Mbs">101-1000 Mbps</option>
													<option value="1001+Mbs">1001+ Mbps</option>
												</select><span class="input-group-addon"> <svg><use xlink:href="/img/shared/icons.svg#caret-down"></use></svg></span>
											</div>
											<div class="drop-holder input-group hawk-select">
												<select id="complianceRequirement" name="complianceRequirement" class="select-picker">
													<option value="first-option" class="first-option">Compliance Requirements</option>
													<option value="SSAE 16">SSAE 16</option>
													<option value="HIPAA">HIPAA</option>
													<option value="PCI DSS">PCI DSS</option>
													<option value="SOC 2">SOC 2</option>
													<option value="SOC 3">SOC 3</option>
												</select><span class="input-group-addon"> <svg><use xlink:href="/img/shared/icons.svg#caret-down"></use></svg></span>
											</div>
										</div>
										<div class="col-md-6">
											<div class="drop-holder input-group hawk-select">
												<select id="cloudRequirement" name="cloudRequirement" class="select-picker">
													<option value="first-option" class="first-option">Cloud Requirements</option>
													<option value="Iaas">Infrastructure as a Service (IaaS)</option>
													<option value="Paas">Platform as a Service (PaaS)</option>
													<option value="Draas">Disaster Recovery as a Service (DRaaS)</option>
												</select><span class="input-group-addon"> <svg><use xlink:href="/img/shared/icons.svg#caret-down"></use></svg></span>
											</div>
											<div class="drop-holder input-group hawk-select">
												<select id="serviceRequirement" name="serviceRequirement" class="select-picker">
													<option value="first-option" class="first-option">Service Requirements</option>
													<option value="Remote Hands">Remote Hands</option>
													<option value="Managed Services">Managed Services</option>
													<option value="Cloud Services">Cloud Services</option>
												</select><span class="input-group-addon"> <svg><use xlink:href="/img/shared/icons.svg#caret-down"></use></svg></span>
											</div>
											<div class="drop-holder input-group hawk-select">
												<select id="timingRequirement" name="timingRequirement" class="select-picker">
													<option value="first-option" class="first-option">Timing Requirements</option>
													<option value="Immediate">Immediate</option>
													<option value="2-3 Months">2-3 Months</option>
													<option value="3-6 Months">3-6 Months</option>
													<option value="6+ Months">6+ Months</option>
												</select><span class="input-group-addon"> <svg><use xlink:href="/img/shared/icons.svg#caret-down"></use></svg></span>
											</div>
										</div>
									</div>
									<div class="row">
										<textarea rows="3" name="additional-comments" id="additional-comments" placeholder="Additional Comments"></textarea>
									</div>
								</div>
							</div>
							<div id="contact-foot-note">
								<h5>By clicking send, I agree that Connected2Fiber will send this information to the Operator listed above.</h5>
							</div>
							<button type="submit" id="sendEmail" data-dismiss="modal">Send</button>
						<input type="hidden" name="csrfToken" value="ZWNA-PFM4-9V28-6CLZ-COOO-952I-571Y-QWBG" /></form>
					</div>
				</div>
			</div>
		</div>
	</div> <!--  Show modal when email is sent -->

	<button data-toggle="modal" class="hidden" data-target="#emailSentModal" id="emailSentModalToggle"></button>
	<div class="modal fade hawk-modal" tabindex="-1" role="dialog" aria-hidden="true" aria-labelledby="emailSentModalLabel" id="emailSentModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="emailSentModalLabel"></h4>
				</div>
				<div class="modal-body">
					<h4>
						<span><svg>
								<use xlink:href="/img/shared/icons.svg#email"></use></svg></span> EMAIL Equinix
					</h4>
					<h3>Your email has been sent</h3>

					<button data-dismiss="modal" id="emailSentModalDismiss">OK</button>
				</div>
			</div>
		</div>
	</div>
 <!--  Show modal when email fails to send -->

	<button data-toggle="modal" class="hidden" data-target="#emailFailModal" id="emailFailModalToggle"></button>
	<div class="modal fade hawk-modal" tabindex="-1" role="dialog" aria-hidden="true" aria-labelledby="emailFailModalLabel" id="emailFailModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="emailFailModalLabel"></h4>
				</div>
				<div class="modal-body">
					<h4>
						<span><svg>
								<use xlink:href="/img/shared/icons.svg#delete-circle"></use></svg></span> EMAIL NOT SENT
					</h4>
					<h3>Something went wrong. Please try again</h3>

					<button data-dismiss="modal" id="emailFailModalDismiss">OK</button>
				</div>
			</div>
		</div>
	</div>

</div>

<script id="facility-card-template" type="text/x-jsrender">
	<div class="col-sm-6 col-md-3">
		<div class="facility-card" data-id="{{>id}}">
			<div class="facility-image" style="background-image:url('{{>image}}');"></div>
			<div class="extra right">
				{{if subscriptionLevel == 'Premium'}}
					<label class="premium"><svg><use xlink:href="/img/shared/icons.svg#premium"></use></svg>PREMIUM</label>
				{{/if}}
			</div>
			<h4 class="compare-header-address">{{>name}}</h4>
			<h4 class="facility-classification">{{>classification}}</h4>
			<p>
				<span class="card-address" data-field="address">{{>address}}</span>
			</p>
			<p class="card-market">{{>city}}, {{>state}}</p>
			<a class="facility-link" href="{{>url}}">VIEW DETAILS</a>
		</div>
	</div>
</script>

<script src="js/hawkMapHelper.js"></script>
<script src="js/hawkFavorite.js"></script>
<script src="js/highcharts.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-zoomslider/v0.7.0/L.Control.Zoomslider.js"></script>
<link rel="stylesheet" href="css/L.Control.Zoomslider-edited.css" />

<script>
	// <![CDATA[

	var hasAccess = false;

	var cleanUrl = $("#provider-url-link").text();

	$('.select-picker').change(function () {
		if ($("option:selected", this).val() == 'first-option') {
			$(this).css('color', '#b3b3b3');
		} else {
			$(this).css('color', 'inherit');
		}
	});

	if (cleanUrl.indexOf("http://") > -1) {
		cleanUrl = cleanUrl.replace("http://", "");
	}

	if (cleanUrl.indexOf("https://") > -1) {
		cleanUrl = cleanUrl.replace("https://", "");
	}

	if (cleanUrl.indexOf("www.") > -1) {
		cleanUrl = cleanUrl.replace("www.", "");
	}

	if (cleanUrl.indexOf("/") > -1) {
		cleanUrl = cleanUrl.replace("/", "");
	}

	$("#provider-url-link").text(cleanUrl);

	var fibers = [];
	var sanitizedUrl = $("#provider-url").attr("href");

	if (sanitizedUrl && sanitizedUrl.indexOf("http") < 0) {
		sanitizedUrl = "http://" + sanitizedUrl;
		$("#provider-url").attr("href", sanitizedUrl);
	}

	var isPrint = false;

	var completion = $("#power-progress").attr("aria-valuenow") / $("#power-progress").attr("aria-valuemax");
	$("#power-progress").css("width", (completion * 100) + "%");
	completion = $("#space-progress").attr("aria-valuenow") / $("#space-progress").attr("aria-valuemax");
	$("#space-progress").css("width", (completion * 100) + "%");

	$("#contact-help").popover();
	$("#favorite-toggle").popover();

	$("li", "#building-details").eq(3).nextAll().hide().addClass("toggleable");
	$("li", "#power-details").eq(3).nextAll().hide().addClass("toggleable");
	$("li", "#infrastructure-details").eq(3).nextAll().hide().addClass("toggleable");

	$("#description-more").click(
			function() {
				if ($(this).hasClass("less")) {
					$(this).html("MORE DETAILS <span>▾</span>")
							.removeClass("less");
				} else {
					$(this).html("LESS").addClass("less");
				}

				$(".dc-description").find("li.toggleable").slideToggle();
			});

	if ($(".dc-description").find("li.toggleable").length === 0) {
		$("#description-more").hide();
	}

	$("li", "#compliance-details").eq(3).nextAll().hide().addClass("toggleable");
	$("li", "#connectivity-details").eq(3).nextAll().hide().addClass("toggleable");
	$("li", "#services-details").eq(3).nextAll().hide().addClass("toggleable");
	$("li", "#security-details").eq(3).nextAll().hide().addClass("toggleable");

	$("#additional-more").click(
			function() {
				if ($(this).hasClass("less")) {
					$(this).html("MORE DETAILS <span>▾</span>")
							.removeClass("less");
				} else {
					$(this).html("LESS").addClass("less");
				}

				$(".additional-details").find("li.toggleable")
						.slideToggle();
			});

	$("li", "#cloud-compliance-details").eq(3).nextAll().hide().addClass("toggleable");
	$("li", "#cloud-services-details").eq(3).nextAll().hide().addClass("toggleable");
	$("li", "#support-details").eq(3).nextAll().hide().addClass("toggleable");
	$("li", "#billing-details").eq(3).nextAll().hide().addClass("toggleable");

	$("#cloud-more").click(function() {
		if ($(this).hasClass("less")) {
			$(this).html("MORE DETAILS <span>▾</span>")
					.removeClass("less");
		} else {
			$(this).html("LESS").addClass("less");
		}

		$(".cloud-overview").find("li.toggleable").slideToggle();
	});

	$("#favorite-toggle").click(function() {
		var temp = $(this).attr("alt-src");
		$(this).attr("alt-src", $(this).attr("src"));
		$(this).attr("src", temp);
	});

	$('.js-phone-tooltip').tooltip();

	if ($('#facility-map').length > 0) {
		var latitude = 33.755467000000000;
		var longitude = -84.391489000000000;

           L.mapbox.accessToken = "pk.eyJ1IjoiZGF0YWNlbnRlcmhhd2siLCJhIjoialFYZEFGMCJ9.rWMIf6AzzR708bI2-rHtEA";
		var map = L.mapbox.map("facility-map", HawkMapHelper.streetsLayer, {
			zoomControl : false,
			attributionControl : false
		}).setView([ latitude, longitude ], 17);

		var layers = {
			Satellite : L.mapbox.tileLayer(HawkMapHelper.satelliteLayer),
			Streets : L.mapbox.tileLayer(HawkMapHelper.streetsLayer)
		};

		layers.Satellite.addTo(map);
		L.control.layers(layers, null, {
			position : 'topleft'
		}).addTo(map);
		new L.Control.Zoomslider({
			position : 'topleft'
		}).addTo(map);

			map.scrollWheelZoom.disable();

			var zoom = 17;
			map.setZoom(zoom);

			// Set the default checked radio button to have the 'checked' class
	        $(".leaflet-control-layers-selector[checked]").addClass("checked");

	        $(".leaflet-control-layers-selector").click(function() {
	        	if ($(this).prop("checked")) {
	        		$(this).addClass("checked");
	        		$(".leaflet-control-layers-selector").not($(this)).removeClass("checked")
	        	}
	        });

		var city = 'Atlanta';
		var postalCode = '30303';
		var state = 'GA';
		var address = '56 Marietta Street NW; 5th Floor';
		var longitude = -84.391489000000000;
		var url = '/colo/equinix/56-marietta-street-nw-5th-floor/at2';
		var name = 'Equinix';

		var userLocations = L.mapbox.featureLayer().addTo(map);
		var locationData = [ {
			type : 'Feature',
			geometry : {
				type : "Point",
				coordinates : [ longitude, latitude ]
			},
			properties : {
				'marker-size' : 'small',
				'marker-color' : '#dd7637',
				'name' : name,
				'address' : address,
				'city' : city + ', ' + state + ' ' + postalCode,
				'url' : url
			}
		} ];
		userLocations.setGeoJSON(locationData);
           var staticImageUrl = mapboxUtils.getStaticMap(latitude, longitude, 17, 500, 400, HawkMapHelper.satelliteLayer, locationData[0]);
           $('#facility-map-static img').attr('src', staticImageUrl);
	}

	$('#fiber-carousel').carousel();

	$(".capacity-toggle button").click(function() {
		$(".selected-btn").toggleClass("selected-btn");
		$(this).toggleClass("selected-btn");

		if ($(this).attr("id") == "power-cap-btn") {
			$("#power-blocks").show();
			$("#space-blocks").hide();
		} else {
			$("#power-blocks").hide();
			$("#space-blocks").show();
		}
	});

	if ($(".capacity-overview .data-block h5:contains('TBD')").length > 5) {
		$(".capacity-overview").hide();
	}

	$(".hawk-links button").click(function(e) {
		var redirect = $(this).attr("data-redirect");
		if (redirect) {
			HawkModal.toggle(redirect.split("=")[1]);
			e.preventDefault();
		}
	});

	$("#contact-provider-form").on("submit", function(event) {
		event.preventDefault();
		$.ajax({
			type: 'POST',
			url: '/listing/contact',
			data: $(this).serialize()
		}).done(function() {
			$('#emailSentModalToggle').click();
		}).fail(function(res, status, err) {
			// Show a modal indicating failure, but print details in console
			console.error("Error code: " + res.status + " " + res.statusText);
			$('#emailFailModalToggle').click();
		});
	});

	$("#sendEmail").click(function() {
		$("#contact-provider-form").submit();
	});

	var downloadCheckTimer;

	var finishDownload = function() {
		window.clearInterval(downloadCheckTimer);
		downloadCheckTimer = null;
		$.removeCookie("hawk_download_cookie", { path: "/" });
		$(".ajax-loader").hide();
	}

	$("#marketing-flyer").click(function() {
		if (!$(this).is(".disabled")) {
			var facilityId = 118993;
			if (facilityId) {
				$.ajax("/api/v1/documents/flyer/" + facilityId);
			}
		}
	});

	$("#profile-export").click(function(e) {
		if (downloadCheckTimer) {
			e.preventDefault();
		}

		var facilityId = 118993;
		if (facilityId) {
			$(".ajax-loader").show();
			downloadCheckTimer = window.setInterval(function() {
				var cookie = $.cookie("hawk_download_cookie");
				if (cookie === facilityId) {
					finishDownload();
				}
			}, 1000);
		}
	});

	var formatPhoneNumber = function(self) {
		if ($(self).val()) {
			 var number = $(self).val()
				.replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3")
				.replace(/(\d)(\d{3})(\d{3})(\d{4})/, "$1-($2) $3-$4");
			$(self).val(number);
		}
	}

	formatPhoneNumber("#phoneNumber");

	$("#phoneNumber").on("change", function() {
		formatPhoneNumber(this);
	});

	$(".button-holder.contact").click(function() {
		$("#contactProviderModalToggle").click();
	});

	if (isPrint) {
		// Do some jQuery magic to make our PDFs look nicer
		$(".dc-description").find("li.toggleable").show();
		$(".contact-provider-button").css({display: "none"});

		// Expand the cloud-more div and show all options when printing
		var numCloudRows = 8;
		$(".cloud-overview ul").each(function() {
			var enabled = $(this).find("li:not(.disabled)");
			if (enabled.length < numCloudRows) {
				$(this).find("li.disabled").eq(numCloudRows - enabled.length - 1).nextAll().hide();
			} else if (enabled.length >= numCloudRows) {
				$(this).find("li.disabled").hide();
			}
			enabled.show();
		});

		var classification = 'Colocation'
		if (classification === 'Colocation') {
			$( ".dc-description" ).find( "h3" ).hide();
			$( ".description" ).hide();

			var numDetailRows = 8;
			$(".additional-details ul").each(function(i, element) {
				var enabled = $(this).find("li:not(.disabled)");
				if (enabled.length < numDetailRows) {
					$(this).find("li.disabled").eq(numDetailRows).prevAll().show();
					$(this).find("li.disabled").eq(numDetailRows - enabled.length - 1).nextAll().hide();
				} else if (enabled.length >= numDetailRows) {
					$(this).find("li.disabled").hide();
				}
				enabled.show();
			});
		}
	}

	$(".category-tooltip").popover({
		container : "body",
		trigger : "focus"
	});

	$(".category-tooltip").on("click", function(e) {
		e.stopPropagation();
	});

	$(".email-circle").parent().click(function() {
		$("#contactProviderModalToggle").click();
	});

	var similarFacilities = [{'address':'300 Satellite Boulevard','city':'Suwanee','classification':'Colocation','companyCode':null,'id':1816,
	'image':'cmsstatic/colo/1816/QTS300SatelliteBoulevard.png','lat':34.0348249999999978854248183779418468475341796875,'lon':-84.062466999999998051862348802387714385986328125,'market':'Atlanta','name':'QTS','postalCode':'30024','shortAddress':null,'state':'GA','subscriptionLevel':'Premium','url':'/colo/qts/300-satellite-boulevard/1816'},{'address':'1033 Jefferson Street','city':'Atlanta','classification':'Colocation','companyCode':'Atlanta-Metro','id':1808,
	'image':'cmsstatic/colo/1808/QTS1033JeffersonStreet.png','lat':33.77767000000000052750692702829837799072265625,'lon':-84.42104000000000496584107168018817901611328125,'market':'Atlanta','name':'QTS','postalCode':'30318','shortAddress':null,'state':'GA','subscriptionLevel':'Premium','url':'/colo/qts/1033-jefferson-street/atlanta-metro'},{'address':'375 Riverside Parkway','city':'Lithia Springs','classification':'Colocation','companyCode':'AT1','id':1587,
	'image':'cmsstatic/colo/1587/Screen Shot 2016-03-29 at 8.56.14 AM.png','lat':33.7442539999999979727363097481429576873779296875,'lon':-84.581220999999999321516952477395534515380859375,'market':'Atlanta','name':'CenturyLink','postalCode':'30122','shortAddress':null,'state':'GA','subscriptionLevel':'Premium','url':'/colo/centurylink/375-riverside-parkway/at1'},{'address':'345 Courtland Street NE','city':'Atlanta','classification':'Colocation','companyCode':null,'id':116449,
	'image':'cmsstatic/colo/116449/h5 atlanta.jpg','lat':33.76515200000000049840309657156467437744140625,'lon':-84.38375600000000531508703716099262237548828125,'market':'Atlanta','name':'H5 Data Centers','postalCode':'30308','shortAddress':null,'state':'GA','subscriptionLevel':'Basic','url':'/colo/h5-data-centers/345-courtland-street-ne/116449'},{'address':'1003 Donnelly Ave SW','city':'Atlanta','classification':'Colocation','companyCode':null,'id':1208,
	'image':'cmsstatic/colo/16601/star-30c80f991fa7de297cc3ef185ce5bb86.png','lat':33.72934099999999801866579218767583370208740234375,'lon':-84.420119999999997162376530468463897705078125,'market':'Atlanta','name':'EdgeConneX','postalCode':'30310','shortAddress':null,'state':'GA','subscriptionLevel':'Basic','url':'/colo/edgeconnex/1003-donnelly-ave-sw/1208'},{'address':'3200 Webb Bridge Road','city':'Alpharetta','classification':'Colocation','companyCode':'T5 @ Atlanta','id':1864,
	'image':'cmsstatic/colo/1864/T5 Atlanta-2.jpg','lat':34.0757765999999975292666931636631488800048828125,'lon':-84.2641617000000024972905521281063556671142578125,'market':'Atlanta','name':'T5 Data Centers','postalCode':'30005','shortAddress':null,'state':'GA','subscriptionLevel':'Basic','url':'/colo/t5-data-centers/3200-webb-bridge-road/t5-atlanta'},{'address':'6653 Pinecrest Drive','city':'Plano','classification':'Colocation','companyCode':'DA7','id':122828,
	'image':'cmsstatic/colo/122828/Screen Shot 2016-03-17 at 10.44.35 AM.png','lat':33.0648350000000021964297047816216945648193359375,'lon':-96.811871999999993931851349771022796630859375,'market':'Dallas/Fort Worth','name':'Equinix','postalCode':'75024','shortAddress':null,'state':'TX','subscriptionLevel':'Basic','url':'/colo/equinix/6653-pinecrest-drive/da7'},{'address':'375 Riverside Parkway','city':'Lithia Springs','classification':'Colocation','companyCode':'AT1','id':1587,
	'image':'cmsstatic/colo/1587/Screen Shot 2016-03-29 at 8.56.14 AM.png','lat':33.7442539999999979727363097481429576873779296875,'lon':-84.581220999999999321516952477395534515380859375,'market':'Atlanta','name':'CenturyLink','postalCode':'30122','shortAddress':null,'state':'GA','subscriptionLevel':'Premium','url':'/colo/centurylink/375-riverside-parkway/at1'},{'address':'300 Satellite Boulevard','city':'Suwanee','classification':'Colocation','companyCode':null,'id':1816,
	'image':'cmsstatic/colo/1816/QTS300SatelliteBoulevard.png','lat':34.0348249999999978854248183779418468475341796875,'lon':-84.062466999999998051862348802387714385986328125,'market':'Atlanta','name':'QTS','postalCode':'30024','shortAddress':null,'state':'GA','subscriptionLevel':'Premium','url':'/colo/qts/300-satellite-boulevard/1816'},{'address':'1033 Jefferson Street','city':'Atlanta','classification':'Colocation','companyCode':'Atlanta-Metro','id':1808,
	'image':'cmsstatic/colo/1808/QTS1033JeffersonStreet.png','lat':33.77767000000000052750692702829837799072265625,'lon':-84.42104000000000496584107168018817901611328125,'market':'Atlanta','name':'QTS','postalCode':'30318','shortAddress':null,'state':'GA','subscriptionLevel':'Premium','url':'/colo/qts/1033-jefferson-street/atlanta-metro'},{'address':'Riverside Parkway','city':'Lithia Springs','classification':'Colocation','companyCode':null,'id':104754,
	'image':'cmsstatic/colo/104754/compass1.png','lat':33.72282899999999727924659964628517627716064453125,'lon':-84.611863999999997076884028501808643341064453125,'market':'Atlanta','name':'Compass Datacenters','postalCode':'30122','shortAddress':null,'state':'GA','subscriptionLevel':'Premium','url':'/colo/compass-datacenters/riverside-parkway/104754'},{'address':'1055 Spring Street','city':'Atlanta','classification':'Colocation','companyCode':null,'id':120212,
	'image':'cmsstatic/colo/120212/Screen Shot 2016-04-19 at 9.04.45 AM.png','lat':33.78342099999999703641151427291333675384521484375,'lon':-84.388519000000002279193722642958164215087890625,'market':'Atlanta','name':'SunGard','postalCode':'30309','shortAddress':null,'state':'GA','subscriptionLevel':'Basic','url':'/colo/sungard/1055-spring-street/120212'}];
	$(".similar-facilities .carousel-inner").find(".item.active").append($("#facility-card-template").render(similarFacilities.slice(0, 4)));
	$(".similar-facilities .carousel-inner").find(".item:nth-child(2)").append($("#facility-card-template").render(similarFacilities.slice(4, 8)));
	$(".similar-facilities .carousel-inner").find(".item:nth-child(3)").append($("#facility-card-template").render(similarFacilities.slice(8, 12)));

	$(".tool-card:not(.scope)").click(function() {
		window.location = $(this).attr("data-url");
	});

	$(".tool-card.scope").click(function() {
		$("#scope-form").submit();
	});

	$(".more").click(function() {
		if ($(this).hasClass("less")) {
			$(this).removeClass("less");
			$(this).text("MORE");
			$(".description-body").removeClass("extend");
		} else {
			$(this).addClass("less");
			$(this).text("LESS");
			$(".description-body").addClass("extend");
		}
	});

	var imageCount = $("#image-carousel .item").size();
	if (imageCount > 0 && imageCount < 5) {
		for (var i = imageCount; i < 5; i++) {
			$("#image-carousel .carousel-controls li[data-slide-to=" + i + "]").addClass("empty");
		}
	}

	function checkMore() {
		if ($(".description-body").prop("scrollHeight") > $(".description-body").prop("clientHeight")) {
			$(".more").show();
		} else {
			$(".more:not(.less)").hide();
		}
	}

	$(window).resize(function() {
		checkMore();
	});

	checkMore();

	// ]]>
</script>

		</div>

        <!-- Start Footer----->
   		 <?php include("includes/footer.php"); ?>
        <!-- End Footer ----->


	</div>
</body>
</html>