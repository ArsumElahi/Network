<?php

// ------------------------------------- server configuration -------------------------------------
$host ='107.180.20.86';
$db = 'fiber_information';
$user = 'FiberIndustry';
$conn  = mysql_connect($host,$user,'pakistan123$$') or die('server information is not correct');
mysql_select_db($db,$conn) or die('database info not correct');
//=====================================End Server Configuration========================================

if (isset($_GET['seacrh'])) {
	$search = urldecode($search);
	$search = filter_var($_GET['seacrh'], FILTER_SANITIZE_STRING);
	$getCompany = mysql_query('select id_company from ifimt_company where company_name like "'.$search.'%"');
	$id_company = mysql_result($getCompany, 0, 'id_company');
	if (empty($id_company)) {
		$id_company = mysql_query('select id_company from ifimt_company_names where name like "'.$search.'"');
		$id_company = mysql_result($id_company,0,'id_company');
	}
	if (!empty($id_company)) {
		echo $id_company;
		exit;
	}
}
echo 0;
