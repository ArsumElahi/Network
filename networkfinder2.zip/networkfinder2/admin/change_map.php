<?php
include("../includes/checkSession.php");

// ------------------------------------- server configuration -------------------------------------
$host ='107.180.20.86';
$db = 'fiber_information';
$user = 'FiberIndustry';
$conn  = mysql_connect($host,$user,'pakistan123$$') or die('server information is not correct');
mysql_select_db($db,$conn) or die('database info not correct');

if (isset($_GET['id_provider'])) {
	$id_company = (int)$_GET['id_provider'];
	$getCompany = mysql_query('select * from ifimt_company where id_company="'.$id_company.'"');
	$getCompany = mysql_fetch_array($getCompany);
	$getCompanyAddress = mysql_query('select * from ifimt_address where id_company="'.$id_company.'"');
	$getCompanyAddress = mysql_fetch_array($getCompanyAddress);
	$getCompanyProducts = mysql_query('select * from ifimt_products where id_company="'.$id_company.'"');
	$getCompanyProducts = mysql_fetch_array($getCompanyProducts);
	$getCompanyContacts = mysql_query('select * from ifimt_contacts where id_company="'.$id_company.'" limit 0,3');
	$getCompanyPops = mysql_query('select * from ifimt_pops where id_company="'.$id_company.'" && latitude!=""');
	$count = 0;
	$cords = '';
	while ($getCompanyPop = mysql_fetch_assoc($getCompanyPops)) {
	$cords.="
		  ['".addslashes($getCompanyPop['name'])."',".$getCompanyPop['latitude'].",".$getCompanyPop['longitude'].",".$count.",'".$facilities[$count]['image']."','".addslashes($facilities[$count]['address'])."','".$facilities[$count]['url']."'],";  
		$count++;
	}
	
         $cords=substr($cords,0,-1);
		 echo $cords;
	

}
?>