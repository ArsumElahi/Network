<?php 
include("../includes/checkSession.php");

?>

<!DOCTYPE HTML>

<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if IE 9]>    <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js" lang="en" prefix="og: http://ogp.me/ns#">
<!--<![endif]-->

<head><meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />




	<title>Locations - Connected2Fiber</title>


<meta name="description" content="Search for data center providers on Connected2Fiber " />


<meta name="author" content="Connected2Fiber" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
<meta name="viewport" content="width=device-width" />


	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:site" content="@Connected2Fiber" />
	<meta property="og:title" content="Search Data Center Providers" />
	<meta property="og:description" content="Search Connected2Fiber
    to find information on industry leading data center providers." />
	


<link rel="stylesheet" href="css/jquery.rating.css" />
<link rel="icon" type="image/png" href="img/shared/favicon.png" />



<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap-edited.min.css" />

<!-- Optional theme -->
<link rel="stylesheet" href="css/bootstrap-theme.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="css/dataTables.fixedColumns.min.css" />

<link rel="stylesheet" href="css/main-1091214527.css" />

<!-- Latest compiled and minified JavaScript -->
<script src="js/jquery-2.1.1.min.js"></script>

<script src="js/jquery-ui.min.js"></script>
<script src="js/jquery.ui.touch-punch.min.js"></script>

<script src="js/bootstrap.min.js"></script>

<script src="js/libs/jquery.dataTables.min.js"></script>
<script src="js/libs/dataTables.fixedColumns.min.js"></script>

<script src="js/libs/modernizr-2.5.3.min.js"></script>

<script src="js/heap-analytics.js"></script>

<script src="js/hawk.js"></script>
<script src="js/util.js"></script>
<script src="js/media.js"></script>
<script src="js/mapbox.utils.js"></script>

<script src="js/mapbox.js"></script>
<link href="css/mapbox.css" rel="stylesheet" />
<script src="js/NonTiledLayer.js"></script>
<script src="js/NonTiledLayer.WMS.js"></script>

<script src="js/svg4everybody.js"></script>
<script src="js/jquery.placeholder.js"></script>
<!-- Google Tag Manager -->
<noscript>
	<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KRVGLX" height="0" width="0" style="display: none; visibility: hidden"></iframe>
</noscript>
<script>/*<![CDATA[*/(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NTMD2G');/*]]>*/</script>
<!-- End Google Tag Manager -->

<!-- TypeKit for ProximaNova font -->
<script src="https://use.typekit.net/aan4rbc.js"></script>
<script>
	try {
		Typekit.load();
	} catch (e) {
	}
	svg4everybody();
</script>

<script type="text/javascript" src="js/lib-1305157643.js"></script>

<script type="text/javascript" src="js/heatclinic-119894065.js"></script>

<!-- Start of zentechnologies Zendesk Widget script -->
<script>/*<![CDATA[*/window.zEmbed||function(e,t){var n,o,d,i,s,a=[],r=document.createElement("iframe");window.zEmbed=function(){a.push(arguments)},window.zE=window.zE||window.zEmbed,r.src="javascript:false",r.title="",r.role="presentation",(r.frameElement||r).style.cssText="display: none",d=document.getElementsByTagName("script"),d=d[d.length-1],d.parentNode.insertBefore(r,d),i=r.contentWindow,s=i.document;try{o=s}catch(e){n=document.domain,r.src='javascript:var d=document.open();d.domain="'+n+'";void(0);',o=s}o.open()._l=function(){var o=this.createElement("script");n&&(this.domain=n),o.id="js-iframe-async",o.src=e,this.t=+new Date,this.zendeskHost=t,this.zEQueue=a,this.body.appendChild(o)},o.write('<body onload="document._l();">'),o.close()}("https://assets.zendesk.com/embeddable_framework/main.js","zentechnologies.zendesk.com");
/*]]>*/



function checkRadio(){
		if(document.getElementById("providers").checked){
		  window.location = "index.php";	
		
		}
		if(document.getElementById("locations").checked){
             window.location = "locations.php";	
		}
	}

</script>
<!-- End of zentechnologies Zendesk Widget script -->

</head>

<body id="-catalog-provider">
	<div class="hawk-content-wrapper texture-bg">
       <!-- Start Header----->
        <?php  include("includes/header_location.php");?>
       <!-- End Header----->

<div><button id="noAccessModalToggle" data-toggle="modal" data-target="#noAccessModal" class="hidden"></button>
<div class="modal hawk-modal" id="noAccessModal" tabindex="-1" role="dialog" aria-labelledby="noAccessModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title" id="noAccessModalLabel"></h4>
			</div>
			<div class="modal-body">
				<h4 class="message ur">Upgrade now for access</h4>
				<h4 class="message sr">Subscribe now for access</h4>
				<h4 class="message sm">Select a market to begin using Hawk Products</h4>
				<span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#search"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#zoom"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#scope"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#compare"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#finance"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#research"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#swap"></use></svg></span>
				<form action="/support" class="message ur">
					<button>CONTACT US</button>
				</form>
				<form action="/plans" class="message sr">
					<button>SIGN UP</button>
				</form>
				<form action="/account/select-market" class="message sm">
					<button>SELECT MARKET</button>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	// <![CDATA[

	var isIE = /* @cc_on!@ */false || !!document.documentMode;

	var param = null;

	var HawkModal = {
		toggle : function(type) {
			$(".message", $("#noAccessModal")).hide();
			$("." + type, $("#noAccessModal")).show();
			$('#noAccessModalToggle').click();
		}
	};

	$('#noAccessModal').on('hidden.bs.modal', function () {
		if (window.location.search.indexOf("?r=") == 0) {
			window.location.search = "";
		}
	});

	$(function() {
		if (param && param.length > 0) {
			param = param[0];
			if (param == "sr" || param == "ur") {
				HawkModal.toggle(param);

			}
		}
	});
	//]]>
</script></div>
<div><button id="registerModalToggle" data-toggle="modal" data-target="#register-modal" class="hidden"></button>
<div class="modal hawk-modal" id="register-modal" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<h4>Register below to join now!</h4>
				<div class="form-wrapper">
					<form id="registration-form" method="POST" action="/register">
						<div class="col-md-12">
							<label>Company Email</label>
							<input type="email" id="customer.emailAddress" name="customer.emailAddress" />
							<div class="col-md-6">
								<label>First Name</label>
								<input type="text" id="customer.firstName" name="customer.firstName" />
							</div>
							<div class="col-md-6">
								<label>Last Name</label>
								<input type="text" id="customer.lastName" name="customer.lastName" />
							</div>
							<label>Password</label>
							<input type="password" id="password" name="password" />
							<label>Confirm Password</label>
							<input type="password" id="passwordConfirm" name="passwordConfirm" />
							<label class="tos-label"><input id="modal-confirm-tos" type="checkbox" /><span>
							I agree to Connected2Fiber's <a href="/terms-of-service" target="_blank">Terms of Service and Privacy Policy</a></span></label>
							<button type="submit" id="modal-register-button" class="register-button" data-dismiss="modal" disabled="disabled">Register</button>
						</div>
					<input type="hidden" name="csrfToken" value="6WWP-1GVX-78SP-BWII-M8JE-5INU-PCJU-HL2Q" /></form>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	//<![CDATA[

	$(".register-link, .register-text").click(function() {
		$("#registerModalToggle").click();
	});

	$("#modal-register-button").click(function() {
		$("#registration-form").submit();
	})

	$("#modal-confirm-tos").click(function() {
		$("#modal-register-button").attr("disabled", !this.checked);
	});



	//]]>
</script></div>
	<div class="xs-menu">
		<ul>
			<li>
				<a href="/products">Products</a>
			</li>
			<li>
				<a href="/register">Register</a>
			</li>
			<li>
				<a href="/blog">Blog</a>
			</li>
			<li>
				<a href="/about">About Us</a>
			</li>
			<li>
				<a href="/support">Contact Us</a>
			</li>
			<li>
				<hr />
			</li>
			<li>
				<p>sales@connected2fiber.com</p>
			</li>
			<li>
				<p>508-202-1807</p>
			</li>
			<li class="address">
				<p>105b South Street</p>
				<p>Hopkinton, MA 01748</p>
			</li>
		</ul>
	</div>


		<div class="hawk-content" role="main">




<div id="provider-content">
	<div id="loader" class="hide"></div>
      <a href="#" id="hide" >
      <img src="img/collapse.png" style="position:absolute;z-index:9999;margin-left:8%;margin-top:0.8%;height: 30px;"
      id="image1"></a>
	<div id="map"></div>
	
	<div class="search-box">
		<!--<div id="loadImg" style="position:absolute;left:41%;margin-top:35px;"><div><img src="ajax-loader.gif" /></div></div>
		<iframe style="margin-top:20px;width:100%;height:1250px;border:none;overflow:hidden;" src="http://networksonar.com/process_mapmyinvoice.php?address=105b%20South%20Street&any_city=Hopkinton&state=MA&zip=01748&country=US" onload="$('#loadImg').hide();"></iframe>-->
	</div>

	<button id="contactProviderModalToggle" data-toggle="modal" data-target="#contactProviderModal" class="hidden"></button>
	<div class="modal hawk-modal" id="contactProviderModal" tabindex="-1" role="dialog" aria-labelledby="contactProviderModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="contactProviderModalLabel"></h4>
				</div>
				<div class="modal-body contact-provider">
					<h4>
						<span class="icon-bg"><svg>
									<use xlink:href="/img/shared/icons.svg#email"></use></svg></span> EMAIL [[*{name}]] <svg id="contact-help" data-trigger="hover" data-placement="bottom" data-content="Submitting this form sends an email directly to the provider. Your information is key confidential and is not shared with any other parties"><use xlink:href="/img/shared/icons.svg#question"></use></svg>
					</h4>
					<br />
					<h5>Fill in your information below and click Send to request more information from [[*{name}]]</h5>
					<br />
					<div class="form-wrapper">
						<form id="contact-provider-form">
							<input type="hidden" name="facilityId" />
							<div class="col-md-12">
								<input type="text" id="fullName" placeholder="Your Name" name="fullName" value="" />
								<input type="email" id="emailAddress" placeholder="Your Email" name="emailAddress" value="" />
								<input type="text" id="phoneNumber" placeholder="Your Phone Number" name="phoneNumber" value="" />
							</div>
						<input type="hidden" name="csrfToken" value="6WWP-1GVX-78SP-BWII-M8JE-5INU-PCJU-HL2Q" /></form>
					</div>
					<button type="submit" id="sendEmail" data-dismiss="modal">Send</button>
				</div>
			</div>
		</div>
	</div> <!--  Show modal when email is sent -->

	<button data-toggle="modal" class="hidden" data-target="#emailSentModal" id="emailSentModalToggle"></button>
	<div class="modal fade hawk-modal" tabindex="-1" role="dialog" aria-hidden="true" aria-labelledby="emailSentModalLabel" id="emailSentModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="emailSentModalLabel"></h4>
				</div>
				<div class="modal-body">
					<h4>
						<span><svg>
								<use xlink:href="/img/shared/icons.svg#email"></use></svg></span> EMAIL null
					</h4>
					<h3>Your email has been sent</h3>

					<button data-dismiss="modal" id="emailSentModalDismiss">OK</button>
				</div>
			</div>
		</div>
	</div>
 <!--  Show modal when email fails to send -->

	<button data-toggle="modal" class="hidden" data-target="#emailFailModal" id="emailFailModalToggle"></button>
	<div class="modal fade hawk-modal" tabindex="-1" role="dialog" aria-hidden="true" aria-labelledby="emailFailModalLabel" id="emailFailModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="emailFailModalLabel"></h4>
				</div>
				<div class="modal-body">
					<h4>
						<span><svg>
								<use xlink:href="img/shared/icons.svg#delete-circle"></use></svg></span> EMAIL NOT SENT
					</h4>
					<h3>Something went wrong. Please try again</h3>

					<button data-dismiss="modal" id="emailFailModalDismiss">OK</button>
				</div>
			</div>
		</div>
	</div>

</div>

<script>
function getNetworkSonarData(e, req_address, map) {
	var code = (e.keyCode ? e.keyCode : e.which);
	if (code == 13) {
		$('.search-box').html('<div id="loadImg" style="position:absolute;left:41%;margin-top:450px;"><div><img src="ajax-loader.gif" /></div></div><iframe style="margin-top:20px;width:100%;height:1250px;border:none;overflow:hidden;" src="http://www.networksonar.com/process_mapmyinvoice.php?address='+req_address+'" onload="$(\'#loadImg\').hide();"></iframe>');
		$.getJSON( "http://maps.google.com/maps/api/geocode/json?address="+req_address+"&sensor=false", function( data ) {
				var lat = data.results[0].geometry.location.lat;
				var lng = data.results[0].geometry.location.lng;
				$('#cord_lat').val(lat);
				$('#cord_lon').val(lng);
				marker = new google.maps.Marker({
					position: new google.maps.LatLng(lat, lng),
					map: map
				});
				map.setZoom(14);
				map.setCenter(new google.maps.LatLng(lat, lng));
		});
		
    }
}
function getNetworkSonarData2(req_address, map) {
		$('.search-box').html('<div id="loadImg" style="position:absolute;left:41%;margin-top:450px;"><div><img src="ajax-loader.gif" /></div></div><iframe style="margin-top:20px;width:100%;height:1250px;border:none;overflow:hidden;" src="http://www.networksonar.com/process_mapmyinvoice.php?address='+req_address+'" onload="$(\'#loadImg\').hide();"></iframe>');
		$.getJSON( "http://maps.google.com/maps/api/geocode/json?address="+req_address+"&sensor=false", function( data ) {
				var lat = data.results[0].geometry.location.lat;
				var lng = data.results[0].geometry.location.lng;
				$('#cord_lat').val(lat);
				$('#cord_lon').val(lng);
				marker = new google.maps.Marker({
					position: new google.maps.LatLng(lat, lng),
					map: map
				});
				map.setZoom(14);
				map.setCenter(new google.maps.LatLng(lat, lng));
		});
}
</script>

<script id="provider-card-template" type="text/x-jsrender">

	<div class="col-sm-6 col-md-4">
		<div class="facility-card" data-id="{{>id}}">
			<div class="facility-image" style="background-image:url('{{>image}}');">
			</div>
			<div class="extra right">
				{{if subscriptionLevel == 'Premium'}}
					<label class="premium"><svg><use xlink:href="/img/shared/icons.svg#premium"></use></svg>PREMIUM</label>
				{{/if}}
			</div>
			<h4 class="compare-header-address">{{>name}}</h4>
			<h4 class="facility-classification">{{>classification}}</h4>
			<p>
				<span class="card-address" data-field="address">{{>address}}</span>
			</p>
			<p class="card-market">{{>city}}, {{>state}}</p>

				<a class="facility-link" href="{{>url}}">VIEW DETAILS</a>


		</div>
	</div>
</script>

<!--<script src="js/hawkMapHelper.js"></script>
<script src="https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-zoomslider/v0.7.0/L.Control.Zoomslider.js"></script>-->
<script src="js/spin.min.js"></script>
<script src="js/jquery.spin.js"></script>
<link rel="stylesheet" href="css/L.Control.Zoomslider-edited.css" />

<!--<script>
	// <![CDATA[
	L.mapbox.accessToken = "pk.eyJ1IjoiZGF0YWNlbnRlcmhhd2siLCJhIjoialFYZEFGMCJ9.rWMIf6AzzR708bI2-rHtEA";
	var map = L.mapbox.map("provider-map", HawkMapHelper.streetsLayer, {
		zoomControl : false,
		attributionControl : false
	});

	if ($(window).height() < 1000) {
		$("#provider-map").height(340);
	}

	map.setView([ 38.47939467327645, -94.9658203125 ], 4);

	var layers = {
		Streets : L.mapbox.tileLayer(HawkMapHelper.streetsLayer, {
			zIndex : 0
		}),
		Satellite : L.mapbox.tileLayer(HawkMapHelper.satelliteLayer, {
			zIndex : 0
		}),
	};

	layers.Streets.addTo(map);
	L.control.layers(layers, {}).addTo(map);

	new L.Control.Zoomslider({
		position : 'topright'
	}).addTo(map);

	map.scrollWheelZoom.disable();
    
    /*
	if (facilities && facilities.length > 0) {
		mapResults(map, facilities);
	}
	*/

	$('.js-main-img').each(function(idx, element) {
		var $element = $(element);
		var imageUrl = $element.attr('data-bg') || 'img/eye.png';
		dch.media.resolveThumbnail(imageUrl).then(function(resolvedUrl) {
			$element.css('background-image', "url(" + encodeURI(resolvedUrl) + ")");
		});
	});

	

	// ]]>
</script>-->
<style>
.leaflet-popup-pane {
	display:none;
}
</style>
		</div>
       <!-- Start Footer----->
		<?php include("includes/footer.php"); ?>
       <!-- End Footer ----->

	</div>
<input id="cord_lat" type="hidden" value="" />
<input id="cord_lon" type="hidden" value="" />
<script>
function initMap() {
	

  var map = new google.maps.Map(document.getElementById('map'), {
    center: {lat: 38.47939467327645, lng: -94.9658203125},
	zoom: 4,
	scrollwheel: false,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  });
  
  var infowindow = new google.maps.InfoWindow();

    var marker, i;
    
   $('#provider-search').keyup(function(event){
	   getNetworkSonarData(event, $(this).val(), map);
   });
   
   $('.search-magnifier').click(function(){
	   getNetworkSonarData2($('#provider-search').val(), map);
   });  

/*
  marker = new google.maps.Marker({
        position: new google.maps.LatLng(<?php echo $latitude ?>,<?php echo $longitude ?>),
        map: map
      });

  
  google.maps.event.addListener(layer, 'defaultviewport_changed', function() {
    var bounds = layer.getDefaultViewport();
    alert($('#cord_lat').val());
	var ll = new google.maps.LatLng($('#cord_lat').val(), $('#cord_lon').val());
	bounds.extend(ll);
    map.fitBounds(bounds);
  });
	*/
  
}
 $(document).ready(function(){
     $("#hide").click(function() {

      // $("#hide").text("Show");
	  // $("#hide").attr("id","show");
	 
       if($("#image1").attr("src") == "img/collapse.png"){
			//alert("testing");
			 $("#image1").attr("src", "img/maximize.png");
			 $("#image1").css("margin-left","1%");
			 $("#image1").css("width","150px");
			 $("#map").slideToggle();
			  
		}else{
			$("#image1").attr("src", "img/collapse.png");
			$("#image1").css("margin-left","8%");
			$("#image1").css("width","80px");
			$("#map").slideToggle();
		}
});

  
  
});


    </script>
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCBzUFUhEkI_lZIQnPz5PeDhrhWCtGuLKA&signed_in=true&callback=initMap">
    </script>
       <style> 
	.search-magnifier {
		cursor: pointer;
	}
	#map {
        float: left;
        width: 100%;
        height: 400px;
        margin-bottom: 20px;
		z-index:1;
      }</style>	
	
</body>
</html>
