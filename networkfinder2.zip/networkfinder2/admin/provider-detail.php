<?php 
include("../includes/checkSession.php");

// ------------------------------------- server configuration -------------------------------------
$host ='107.180.20.86';
$db = 'fiber_information';
$user = 'FiberIndustry';
$conn  = mysql_connect($host,$user,'pakistan123$$') or die('server information is not correct');
mysql_select_db($db,$conn) or die('database info not correct');
//=====================================End Server Configuration========================================

if (isset($_GET['id_provider']) && isset($_GET['id_pop'])) {
	$id_company = (int)$_GET['id_provider'];
	$id_pops = (int)$_GET['id_pop'];
	$getCompany = mysql_query('select * from ifimt_company where id_company="'.$id_company.'"');
	$getCompany = mysql_fetch_array($getCompany);
	$getCompanyAddress = mysql_query('select * from ifimt_address where id_company="'.$id_company.'"');
	$getCompanyAddress = mysql_fetch_array($getCompanyAddress);
	$getCompanyProducts = mysql_query('select * from ifimt_products where id_company="'.$id_company.'"');
	$getCompanyProducts = mysql_fetch_array($getCompanyProducts);
	$getCompanyPops = mysql_query('select * from ifimt_pops where id_company="'.$id_company.'" && id_pops="'.$id_pops.'"');
	$getCompanyPop = mysql_fetch_assoc($getCompanyPops);
}

function getlat_lon($addressVal) {
	$geocode = file_get_contents('http://maps.google.com/maps/api/geocode/json?address='.urlencode($addressVal).'&sensor=false');
	$output		= json_decode($geocode); //Store values in variable
    if ($output->status == 'OK') { // Check if address is available or not
		$latitude = $output->results[0]->geometry->location->lat; //Returns Latitude
		$longitude = $output->results[0]->geometry->location->lng; // Returns Longitude
	}
	$coords['latitude'] = $latitude;
	$coords['longitude'] = $longitude;
	return $coords;
}

?>

<!DOCTYPE HTML>

<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if IE 9]>    <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js" lang="en" prefix="og: http://ogp.me/ns#">
<!--<![endif]-->

<head><meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />




	<title><?php echo $getCompany['company_name']; ?> Provider - Connected2Fiber</title>


<meta name="description" content="<?php echo $getCompany['description']; ?>" />


<meta name="author" content="Connected2Fiber" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
<meta name="viewport" content="width=device-width" />


	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:site" content="@Connected2Fiber" />
	<meta property="og:title" content="Search Data Center Providers" />
	<meta property="og:description" content="Search Connected2Fiber
    to find information on industry leading data center providers." />
	

<link rel="stylesheet" href="css/jquery.rating.css" />
<link rel="icon" type="image/png" href="img/shared/favicon.png" />



<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap-edited.min.css" />

<!-- Optional theme -->
<link rel="stylesheet" href="css/bootstrap-theme.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="css/jquery.dataTables.min.css" />
<link rel="stylesheet" href="css/dataTables.fixedColumns.min.css" />

<link rel="stylesheet" href="css/main-1091214527.css" />

<!-- Latest compiled and minified JavaScript -->
<script src="js/jquery-2.1.1.min.js"></script>

<script src="js/jquery-ui.min.js"></script>
<script src="js/jquery.ui.touch-punch.min.js"></script>

<script src="js/bootstrap.min.js"></script>

<script src="js/libs/jquery.dataTables.min.js"></script>
<script src="js/libs/dataTables.fixedColumns.min.js"></script>

<script src="js/libs/modernizr-2.5.3.min.js"></script>

<script src="js/heap-analytics.js"></script>

<script src="js/hawk.js"></script>
<script src="js/util.js"></script>
<script src="js/media.js"></script>
<script src="js/mapbox.utils.js"></script>

<script src="js/mapbox.js"></script>
<link href="css/mapbox.css" rel="stylesheet" />
<script src="js/NonTiledLayer.js"></script>
<script src="js/NonTiledLayer.WMS.js"></script>

<script src="js/svg4everybody.js"></script>
<script src="js/jquery.placeholder.js"></script>

<script type="text/javascript" src="js/lib-1305157643.js"></script>

<script type="text/javascript" src="js/heatclinic-119894065.js"></script>

<!-- Start of zentechnologies Zendesk Widget script -->
<script>/*<![CDATA[*/window.zEmbed||function(e,t){var n,o,d,i,s,a=[],r=document.createElement("iframe");window.zEmbed=function(){a.push(arguments)},window.zE=window.zE||window.zEmbed,r.src="javascript:false",r.title="",r.role="presentation",(r.frameElement||r).style.cssText="display: none",d=document.getElementsByTagName("script"),d=d[d.length-1],d.parentNode.insertBefore(r,d),i=r.contentWindow,s=i.document;try{o=s}catch(e){n=document.domain,r.src='javascript:var d=document.open();d.domain="'+n+'";void(0);',o=s}o.open()._l=function(){var o=this.createElement("script");n&&(this.domain=n),o.id="js-iframe-async",o.src=e,this.t=+new Date,this.zendeskHost=t,this.zEQueue=a,this.body.appendChild(o)},o.write('<body onload="document._l();">'),o.close()}("https://assets.zendesk.com/embeddable_framework/main.js","zentechnologies.zendesk.com");
/*]]>*/</script>
<!-- End of zentechnologies Zendesk Widget script -->

</head>

<body id="-catalog-provider">
	<div class="hawk-content-wrapper texture-bg">
       <!-- Start Header----->
        <?php  include("includes/header.php");?>
       <!-- End Header----->

<div><button id="noAccessModalToggle" data-toggle="modal" data-target="#noAccessModal" class="hidden"></button>
<div class="modal hawk-modal" id="noAccessModal" tabindex="-1" role="dialog" aria-labelledby="noAccessModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title" id="noAccessModalLabel"></h4>
			</div>
			<div class="modal-body">
				<h4 class="message ur">Upgrade now for access</h4>
				<h4 class="message sr">Subscribe now for access</h4>
				<h4 class="message sm">Select a market to begin using Hawk Products</h4>
				<span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#search"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#zoom"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#scope"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#compare"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#finance"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#research"></use></svg></span> <span class="icon-bg"><svg><use xlink:href="/img/shared/icons.svg#swap"></use></svg></span>
				<form action="/support" class="message ur">
					<button>CONTACT US</button>
				</form>
				<form action="/plans" class="message sr">
					<button>SIGN UP</button>
				</form>
				<form action="/account/select-market" class="message sm">
					<button>SELECT MARKET</button>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	// <![CDATA[

	var isIE = /* @cc_on!@ */false || !!document.documentMode;

	var param = null;

	var HawkModal = {
		toggle : function(type) {
			$(".message", $("#noAccessModal")).hide();
			$("." + type, $("#noAccessModal")).show();
			$('#noAccessModalToggle').click();
		}
	};

	$('#noAccessModal').on('hidden.bs.modal', function () {
		if (window.location.search.indexOf("?r=") == 0) {
			window.location.search = "";
		}
	});

	$(function() {
		if (param && param.length > 0) {
			param = param[0];
			if (param == "sr" || param == "ur") {
				HawkModal.toggle(param);

			}
		}
	});
	//]]>
</script></div>
<div><button id="registerModalToggle" data-toggle="modal" data-target="#register-modal" class="hidden"></button>
<div class="modal hawk-modal" id="register-modal" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<h4>Register below to join now!</h4>
				<div class="form-wrapper">
					<form id="registration-form" method="POST" action="/register">
						<div class="col-md-12">
							<label>Company Email</label>
							<input type="email" id="customer.emailAddress" name="customer.emailAddress" />
							<div class="col-md-6">
								<label>First Name</label>
								<input type="text" id="customer.firstName" name="customer.firstName" />
							</div>
							<div class="col-md-6">
								<label>Last Name</label>
								<input type="text" id="customer.lastName" name="customer.lastName" />
							</div>
							<label>Password</label>
							<input type="password" id="password" name="password" />
							<label>Confirm Password</label>
							<input type="password" id="passwordConfirm" name="passwordConfirm" />
							<label class="tos-label"><input id="modal-confirm-tos" type="checkbox" /><span>
							I agree to Connected2Fiber's <a href="/terms-of-service" target="_blank">Terms of Service and Privacy Policy</a></span></label>
							<button type="submit" id="modal-register-button" class="register-button" data-dismiss="modal" disabled="disabled">Register</button>
						</div>
					<input type="hidden" name="csrfToken" value="6WWP-1GVX-78SP-BWII-M8JE-5INU-PCJU-HL2Q" /></form>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	//<![CDATA[

	$(".register-link, .register-text").click(function() {
		$("#registerModalToggle").click();
	});

	$("#modal-register-button").click(function() {
		$("#registration-form").submit();
	})

	$("#modal-confirm-tos").click(function() {
		$("#modal-register-button").attr("disabled", !this.checked);
	});



	//]]>
</script></div>
	<div class="xs-menu">
		<ul>
			<li>
				<a href="/products">Products</a>
			</li>
			<li>
				<a href="/register">Register</a>
			</li>
			<li>
				<a href="/blog">Blog</a>
			</li>
			<li>
				<a href="/about">About Us</a>
			</li>
			<li>
				<a href="/support">Contact Us</a>
			</li>
			<li>
				<hr />
			</li>
			<li>
				<p>sales@connected2fiber.com</p>
			</li>
			<li>
				<p>508-202-1807</p>
			</li>
			<li class="address">
				<p>105b South Street</p>
				<p>Hopkinton, MA 01748</p>
			</li>
		</ul>
	</div>

<div class="hawk-content" role="main">




<div>
	<input type="hidden" id="classification" value="Colocation" />
	<div class="listing-overview content-padding">
		<div class="container">
			<h3 class="visible-print listing-header-print"><?php echo $getCompany['company_name']; ?></h3>
			<div class="row">
				<div class="col-sm-6">
					<div class="product-card locked">
						<div class="row">
							<div class="product-title col-sm-12 col-md-9">
								<p class="not-premium"></p>
								<h3><?php echo $getCompany['company_name']; ?></h3>
								<h4><?php echo $getCompanyPop['name']; ?></h4>
								<p class="product-address">
									<span><?php echo $getCompanyPop['address'].' '.$getCompanyPop['address2']; ?></span>
								</p>
								<p class="product-address"><?php echo $getCompanyPop['city'].' '.$getCompanyPop['zip']; ?></p>
							</div>
							<div class="col-sm-3">
								<div class="product-downloads hidden-xs hidden-sm hidden-print">
									<div class="downloads-title">
										<span>DOWNLOADS</span><svg class="hidden-md"><use xlink:href="/img/shared/icons.svg#download"></use></svg>
									</div>
									<p>


										<a id="marketing-flyer" class="card-link-locked"><span class="hidden-md">Marketing </span>Flyer</a>
									</p>
									<p>

										<a id="profile-export-locked" class="card-link-locked">Profile PDF</a>
										<span><img class="ajax-loader" src="/admin/img/admin/ajax-loader.gif" style="padding-left: 5px; display: none;" /></span>
									</p>
								</div>
							</div>
						</div>
						<div class="product-actions hidden-xs hidden-print">
							<div class="row">
								<div class="action">
									<a href="/admin/index.php">
										<i class="fa fa-undo" aria-hidden="true"></i>
										<span class="return-search">RETURN TO SEARCH</span>
									</a>
									<img data-toggle="false" data-trigger="hover" data-placement="right" data-content="Add this facility to your favorites!" data-container="body" alt-src="img/star-30c80f991fa7de297cc3ef185ce5bb86.png" src="../img/star-empty-6b89bb871a323605172c2078ec570e6f.png" class="hidden-print" />
									<span class="favorites disabled">ADD TO FAVORITES</span>
								</div>
							</div>
							<form id="add-favorite-form" type="hidden" action="/account/favorites/add" method="POST">
								<input name="productId" id="productId" type="hidden" value="118993" />
								<input name="quantity" id="quantity" type="hidden" value="1" />
							<input type="hidden" name="csrfToken" value="ZWNA-PFM4-9V28-6CLZ-COOO-952I-571Y-QWBG" /></form>
							<form id="remove-favorite-form" type="hidden" method="POST" action="/account/favorites/remove">
								<input name="orderItemId" id="orderItemId" type="hidden" value="118993" />
							<input type="hidden" name="csrfToken" value="ZWNA-PFM4-9V28-6CLZ-COOO-952I-571Y-QWBG" /></form>
						</div>
						<div class="product-description hidden-xs">
							<p class="description-body"><?php echo $getCompany['description']; ?></p>
							<p class="more hidden-print">MORE</p>
						</div>
					</div>
				</div>
				<div class="col-sm-6 image-panel">
<?php
		$completeAddress = $getCompanyPop['address'].' '.$getCompanyPop['address2'].',+'.$getCompanyPop['city'].',+'.$getCompanyPop['zip'];
		$coordsVal = getlat_lon($completeAddress);
		$bgImage = 'https://maps.googleapis.com/maps/api/streetview?size=555x555&location='.$coordsVal['latitude'].','.$coordsVal['longitude'].'&fov=90&heading=235&pitch=10&key=AIzaSyCBzUFUhEkI_lZIQnPz5PeDhrhWCtGuLKA';
?>

					<div id="image-carousel" class="carousel slide">
						<div class="carousel-inner">
							<div class="item active">
								<div class="bg-image"
								style="background-image: url('<?php echo $bgImage; ?>');">
									<img class="" src="<?php echo $bgImage; ?>" />
								</div>

								<div class="media-attribution">Media by: <?php echo $getCompany['company_name']; ?></div>
							</div>
							<!--<a class="provider-logo" href="/providers/equinix"><img src="cmsstatic/dcproviders/219/Equinix_Logo_000001.jpg" />
							</a>-->
						</div>
						<!--<div class="carousel-controls hidden-print">
							<ol class="carousel-indicators">
								<li data-target="#image-carousel" data-slide-to="0" class="active"></li>
								<li data-target="#image-carousel" data-slide-to="1"></li>
								<li data-target="#image-carousel" data-slide-to="2"></li>
								<li data-target="#image-carousel" data-slide-to="3"></li>
								<li data-target="#image-carousel" data-slide-to="4"></li>
							</ol>
						</div>-->
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6">
					<div class="contact-buttons row hidden-print">
						<div class="col-sm-6">
							<div class="button-holder contact">
								<a href="/admin/index.php?id_provider=<?php echo $_GET['id_provider']; ?>">	
									<svg><use xlink:href="/img/shared/icons.svg#email"></use></svg>
									<span>CONTACT PROVIDER</span>
								</a>	
                            </div>
						</div>
						<div class="col-sm-6">
							<div class="button-holder provider-profile">
								<a href="/admin/index.php?id_provider=<?php echo $_GET['id_provider']; ?>">
									<svg><use xlink:href="/img/shared/icons.svg#list"></use></svg>
									<span>PROVIDER PROFILE</span>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>

<div class="register-section hidden-print">
		<div class="register-band dark-band">
			<h4>CONTACT <?php echo $getCompany['company_name']; ?> NOW TO LEARN MORE ABOUT <?php echo $getCompanyPop['address'].' '.$getCompanyPop['address2']; ?></h4>

		</div>
		<h3>Discover capacity, connectivity and infrastructure information.</h3>


		<h3>Find this and more with the NetworkFinder.</h3>
		<div class="container">
			<div class="tool-links row hidden-xs">
				<div class="col-sm-6">
					<div class="icon-holder">
						<svg><use xlink:href="/img/shared/icons.svg#search"></use></svg>
					</div>
					<h4 class="tool-title">Search</h4>
					<p class="tool-description">Search network operators by location, provider and POP/CO</p>
				</div>
				<div class="col-sm-6">
					<div class="icon-holder">
						<svg><use xlink:href="/img/shared/icons.svg#compare"></use></svg>
					</div>
					<h4 class="tool-title">View</h4>
					<p class="tool-description">View powerful mapping technology evaluating network infrastructure</p>
				</div>
				<!--<div class="col-sm-4">
					<div class="icon-holder">
						<svg><use xlink:href="/img/shared/icons.svg#scope"></use></svg>
					</div>
					<h4 class="tool-title">Scope</h4>
					<p class="tool-description">View powerful mapping technology evaluating power/fiber infrastructure</p>
				</div>-->
			</div>
			
			<hr class="hidden-xs" />
			<!--<form id="product-register-form" method="POST" action="/register">
				<div class="row">
					<div class="col-sm-8 col-sm-offset-2">
						<div class="row">
							<div class="col-sm-12">
								<input type="email" placeholder="Company Email" id="customer.emailAddress" name="customer.emailAddress" />
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6">
								<input type="text" placeholder="First Name" id="customer.firstName" name="customer.firstName" />
							</div>
							<div class="col-sm-6">
								<input type="text" placeholder="Last Name" id="customer.lastName" name="customer.lastName" />
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6">
								<input type="password" placeholder="Password" id="password" name="password" />
							</div>
							<div class="col-sm-6">
								<input type="password" placeholder="Confirm Password" id="passwordConfirm" name="passwordConfirm" />
							</div>
						</div>
						<button type="submit" id="register-button" class="register-button">GET STARTED</button>
					</div>
				</div>
			<input type="hidden" name="csrfToken" value="ZWNA-PFM4-9V28-6CLZ-COOO-952I-571Y-QWBG" />
			</form>-->
			<div class="row">
				<div class="col-sm-8 col-sm-offset-2">
					<a href="/admin/index.php?id_provider=<?php echo $_GET['id_provider']; ?>"><button style="font-size:15px !important;" class="register-button">Contact <?php echo $getCompany['company_name']; ?></button></a>
				</div>
			</div>
	
		</div>
	</div>


       <!-- Start Footer----->
		<?php include("includes/footer.php"); ?>
       <!-- End Footer ----->

	</div>
</body>
</html>
