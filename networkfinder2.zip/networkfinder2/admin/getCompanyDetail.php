<head>
<script src="js/jquery.unveil.js"></script>
<script>
    $(function() {
        $(".facility-image img").unveil(300);
    });
    </script>
</head>
<?php
include("../includes/checkSession.php");

// ------------------------------------- server configuration -------------------------------------
$host ='107.180.20.86';
$db = 'fiber_information';
$user = 'FiberIndustry';
$conn  = mysql_connect($host,$user,'pakistan123$$') or die('server information is not correct');
mysql_select_db($db,$conn) or die('database info not correct');
//=====================================End Server Configuration========================================

if (isset($_GET['id_provider'])) {
	$id_company = (int)$_GET['id_provider'];
	$getCompany = mysql_query('select * from ifimt_company where id_company="'.$id_company.'"');
	$getCompany = mysql_fetch_array($getCompany);
	$getCompanyAddress = mysql_query('select * from ifimt_address where id_company="'.$id_company.'"');
	$getCompanyAddress = mysql_fetch_array($getCompanyAddress);
	$getCompanyProducts = mysql_query('select * from ifimt_products where id_company="'.$id_company.'"');
	$getCompanyProducts = mysql_fetch_array($getCompanyProducts);
	$getCompanyContacts = mysql_query('select * from ifimt_contacts where id_company="'.$id_company.'" limit 0,3');
	$getCompanyPops = mysql_query('select * from ifimt_pops where id_company="'.$id_company.'" && latitude!=""');
	$count = 0;
	$cords = '';
	while ($getCompanyPop = mysql_fetch_assoc($getCompanyPops)) {
		$completeAddress = $getCompanyPop['address'].' '.$getCompanyPop['address2'].',+'.$getCompanyPop['city'].',+'.$getCompanyPop['zip'];
		//$coordsVal = getlat_lon($completeAddress);
		$facilities[$count]['address'] = addslashes($getCompanyPop['address']);
		$facilities[$count]['city'] = addslashes($getCompanyPop['city']);
		$facilities[$count]['classification'] = 'Colocation';
		$facilities[$count]['companyCode'] = $getCompanyPop['id_company'];
		$facilities[$count]['id'] = $getCompanyPop['id_pops'];
		$facilities[$count]['image'] = 'https://maps.googleapis.com/maps/api/streetview?size=243x145&location='.$getCompanyPop['latitude'].','.$getCompanyPop['longitude'].'&fov=90&heading=235&pitch=10&key=AIzaSyCBzUFUhEkI_lZIQnPz5PeDhrhWCtGuLKA';
		$facilities[$count]['lat'] = $getCompanyPop['latitude'];
		$facilities[$count]['lon'] = $getCompanyPop['longitude'];
		$facilities[$count]['market'] = 'Atlanta';
		$facilities[$count]['name'] = addslashes($getCompanyPop['name']);
		$facilities[$count]['postalCode'] = $getCompanyPop['zip'];
		$facilities[$count]['shortAddress'] = '';
		$facilities[$count]['state'] = '';
		$facilities[$count]['subscriptionLevel'] = 'Basic';
		$facilities[$count]['url'] = '/admin/provider-detail.php?id_provider='.$id_company.'&id_pop='.$getCompanyPop['id_pops'];
		$cords.="
		  ['".addslashes($getCompanyPop['name'])."',".$getCompanyPop['latitude'].",".$getCompanyPop['longitude'].",".$count.",'".$facilities[$count]['image']."','".addslashes($facilities[$count]['address'])."','".$facilities[$count]['url']."'],";  
		$count++;
	}
	$facilities = json_encode($facilities);
	//$facilities = '';
}

function getlat_lon($addressVal) {
	$geocode = file_get_contents('http://maps.google.com/maps/api/geocode/json?address='.urlencode($addressVal).'&sensor=false');
	$output		= json_decode($geocode); //Store values in variable
    if ($output->status == 'OK') { // Check if address is available or not
		$latitude = $output->results[0]->geometry->location->lat; //Returns Latitude
		$longitude = $output->results[0]->geometry->location->lng; // Returns Longitude
	}
	$coords['latitude'] = $latitude;
	$coords['longitude'] = $longitude;
	echo $coords;
}



	if (isset($id_company)) {
		
		echo '
	<div class="container content-padding">
		<div class="col-sm-3 provider-info">
			<h4>'.$getCompany['company_name'].'</h4>
			<p>'.$getCompanyAddress['address'].' '.$getCompanyAddress['address2'].'</p>
			<p>'.$getCompanyAddress['city'].','.$getCompanyAddress['state'].' '.$getCompanyAddress['zip'].'</p>
			'.(!empty($getCompany['webiste']) ? '<a target="_blank" href="http://'.$getCompany['webiste'].'">'.$getCompany['webiste'].'</a>': '' ).'
			<ul class="details">
				<li><p>Type: '.$getCompany['company_type'].'</p></li>
				<li><p>Ticker: '.$getCompany['ticker'].'</p></li>
				<!--<li><p>Number of Employees: 1001-5000</p></li>
				<li><p>Year Founded: 1998</p></li>-->
			</ul>
			<!--<img src="cmsstatic/dcproviders/219/Equinix_Logo_000001.jpg" />-->
			<h2>Services Available</h2>
			<ul class="checklist">
				<li '.($getCompanyProducts['dark_fiber'] == 1 ? '': 'class="disabled"' ).' >Dark Fiber</li>
				<li '.($getCompanyProducts['wavelengths'] == 1 ? '': 'class="disabled"' ).'>Wavelengths</li>
				<li '.($getCompanyProducts['sonet'] == 1 ? '': 'class="disabled"' ).'>SONET</li>
				<li '.($getCompanyProducts['ethernet'] == 1 ? '': 'class="disabled"' ).'>Ethernet</li>
				<li '.($getCompanyProducts['mpls'] == 1 ? '': 'class="disabled"' ).'>MPLS</li>
				<li '.($getCompanyProducts['ip_transit'] == 1 ? '': 'class="disabled"' ).'>IP Transit</li>
				<li '.($getCompanyProducts['ip_broadband'] == 1 ? '': 'class="disabled"' ).'>IP Broadband</li>
				<li '.($getCompanyProducts['ip_dedicated'] == 1 ? '': 'class="disabled"' ).'>IP Dedicated</li>
				<li '.($getCompanyProducts['ip_vpn'] == 1 ? '': 'class="disabled"' ).'>IP VPN</li>
				<li '.($getCompanyProducts['voip'] == 1 ? '': 'class="disabled"' ).'>VoIP</li>
				<li '.($getCompanyProducts['uc'] == 1 ? '': 'class="disabled"' ).'>UC</li>
				<li '.($getCompanyProducts['managed_services'] == 1 ? '': 'class="disabled"' ).'>Managed Services</li>
			</ul>
		</div>
		<div class="col-sm-9 facilities">

				<h4>Company Information</h4>
				<p>'.$getCompany['description'].'</p>';
				$contacts = mysql_num_rows($getCompanyContacts);
				if ($contacts > 0) {
					echo '<h4>Contact Information</h4>
					<table class="table">
					<tr>
					<th>Name</th>
					<th>Title</th>
					<th>Phone</th>
					<th>Email</th>
					</tr>
					';
					while ($getCompanyContact = mysql_fetch_assoc($getCompanyContacts)) {
						echo '<tr><td>'.$getCompanyContact['name'].'</td><td>'.$getCompanyContact['title'].'</td><td>'.$getCompanyContact['phone'].'</td><td>'.$getCompanyContact['email'].'</td></tr>';	
					}
					echo '
					</table>';
				}
			echo '<div id="owned-facilities">
			</div>
		</div>
	</div>';
	}
	?>
    
    <?php
    //if (!empty($facilities))
	//	echo 'var facilities = '.$facilities.';';
//	else
	//	echo  'var facilities = null';
    ?>
    
 <script id="provider-card-template" type="text/x-jsrender">

	<div class="col-sm-6 col-md-4">
		<div class="facility-card" data-id="{{>id}}">
			<div class="facility-image">
				<img data-src="{{>image}}" data-src-retina="{{>image}}" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" />
			</div>
			<div class="extra right">
				{{if subscriptionLevel == 'Premium'}}
					<label class="premium"><svg><use xlink:href="/img/shared/icons.svg#premium"></use></svg>PREMIUM</label>
				{{/if}}
			</div>
			<h4 class="compare-header-address">{{>name}}</h4>
			<h4 class="facility-classification">{{>classification}}</h4>
			<p>
				<span class="card-address" data-field="address">{{>address}}</span>
			</p>
			<p class="card-market">{{>city}}, {{>state}}</p>

				<!--<a class="facility-link" href="{{>url}}">VIEW DETAILS</a>-->
				<a class="facility-link" href="{{>url}}">VIEW DETAILS</a>


		</div>
	</div>
</script>   
   
<script>
	var facilities = <?php echo $facilities; ?>;
	if (facilities && facilities.length > 0) {
    	$("#owned-facilities").append($("#provider-card-template").render(facilities));
    }
	
	
</script>