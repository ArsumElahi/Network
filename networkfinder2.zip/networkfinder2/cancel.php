<?php 
include("includes/config.php");

if(isset($_SESSION['package_amount'])){
	
 unset($_SESSION['package_amount']);
 unset($_SESSION['v_email']);
 unset($_SESSION['v_uname']);
 unset($_SESSION['v_pswd']

 $_SESSION['error'] = "Sorry! You should have to purchase one of our package to create you Account";
 

header("location:login.php");

}

mysql_close($conection); 
?>