<?php 
include("includes/config.php");




$user_email = $_POST['u_email'];
$user_pswd  = md5($_POST['u_pswd']);

$check_user = "SELECT * FROM c2f_user_config WHERE user_email='".$user_email."' AND user_password='".$user_pswd."' AND
user_active_status=1";

$check_user_run = mysql_query($check_user) or die(mysql_error());

if(mysql_num_rows($check_user_run)>0){
	 $user_data = mysql_fetch_array($check_user_run);
   
     $_SESSION['uid']   =    $user_data['user_id'];
	 $_SESSION['uname'] =  $user_data['user_name'];
	 
	 header("location:admin/index.php");
  
}
else{
$_SESSION['error'] = "Authentication Failed! Invalid Email or Password ?";
header("location:login.php");

}

mysql_close($conection);

?>
