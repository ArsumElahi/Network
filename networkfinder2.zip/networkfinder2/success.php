<?php 
include("includes/config.php");
if(isset($_SESSION['package_amount'])){
$createuser_sql = "INSERT INTO  c2f_user_config(user_email,user_name,user_password) 
VALUES('".$_SESSION['v_email']."','".$_SESSION['v_uname']."','".$_SESSION['v_pswd']."');";	

if(mysql_query($createuser_sql)){
 $_SESSION['success'] = "Account Created Successfully";

 unset($_SESSION['package_amount']);
 unset($_SESSION['v_email']);
 unset($_SESSION['v_uname']);
 unset($_SESSION['v_pswd']);
 
 header("location:login.php");
}
}
mysql_close($conection); 
?>
