<?php 
include("includes/config.php");
?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login - Connected2Fiber</title>




        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="css/animate.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">

        <!-- FAVICON  -->
        <link rel="icon" href="/admin/img/shared/favicon.png">
<script>
  function errorwithsliding(){
   $("#myAlert").slideDown('slow').delay(2000).slideUp('slow');
  
  }


</script>

</head>

<body onLoad="<?php if(isset($_SESSION['error'])|| isset($_SESSION['success'])){?> errorwithsliding();<?php } ?>">
  <!-- MAIN NAV -->
        <nav class="navbar navbar-default navbar-fixed-top" style="background-color:#4C545F">
            <div class="container">
                <div class="navbar-header page-scroll">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-menu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <!-- MAIN NAV LOGO -->
                    <a class="logo page-scroll" href="/"><img src="//p6.zdassets.com/hc/settings_assets/1086441/200323487/t1xK5wLNxfHtRXum4xBEUA-SmallLogo.png" 
                    class="img-responsive" alt="" height="500px"></a>
                </div>
                <div class="collapse navbar-collapse" id="main-menu">
                    <!-- MAIN NAV LINKS -->
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="page-scroll" href="index.php#header">Home</a></li> 
						<li><a class="page-scroll" href="index.php#features">Features</a>
						<li><a class="page-scroll" href="index.php#brief">Brief</a></li>
                        <li><a class="page-scroll" href="index.php#video">Video</a></li>
                        <li><a class="page-scroll" href="index.php#appho_price_table">Pricing</a></li>
                        <li><a class="page-scroll" href="index.php#team">Team</a></li>
                        <li><a class="page-scroll" href="index.php#client">Clients</a></li>
                        <li><a class="page-scroll" href="index.php#contact">Contact</a></li>
                        <?php
                        session_start(); 
                        if (isset($_SESSION['uname'])) {
							echo '<li><a class="page-scroll" href="/includes/logout.php">Logout</a></li>';
						} else {
							echo '<li><a class="page-scroll" href="login.php">Login</a></li>';
						}
                        ?>
                    </ul>
                    <!-- END MAIN NAV LINKS -->
                </div>
            </div>
        </nav>
        <!-- END MAIN NAV -->
          <!-- START HEADER -->
  <header>
 	<div class="container">
	   <div class="row">
		  <div class="col-md-12 col-sm-12">
	      </div>
			<br /><br /><br />
	   </div>
	</div>
	<div id="headerbackground"></div>
 </header>
        <!-- END HEADER -->
  
 <!-- START LOGIN -->
        <section id="login"  class="features-bg">
           <form action="checklogin.php" method="post"> 
            <div class="container">
                   <div class="text-center">
                        <h2 class="section-heading wow fadeInUp" data-wow-delay=".1s">Login</h2>                 
                    </div>
                     <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                           <div class="row">
                             <div class="col-lg-3">
                             </div>
                             <div class="col-lg-6">
                              <div style="margin-bottom:25px;text-align:center">
                                 
                                 <?php if(isset($_SESSION['error'])){ ?>
                                   <div class="alert alert-danger" id="myAlert">
      									  <a href="#" class="close" data-dismiss="alert">&times;</a>
			        						<?php echo $_SESSION['error'];
											 unset($_SESSION['error']);
											 ?>
    							  </div>
                                <?php }else if(isset($_SESSION['success'])){ ?>
                                
                                  <div class="alert alert-success" id="myAlert">
      									  <a href="#" class="close" data-dismiss="alert">&times;</a>
			        						<?php echo $_SESSION['success'];
											 unset($_SESSION['success']);
											 ?>
    							  </div>
                                <?php }?>  
                                 
                                 
                                                               
                             </div>
                            </div>
                            <div class="col-lg-3">
                            </div>
                          </div>  
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                           <div class="row">
                             <div class="col-lg-3">
                             </div>
                             <div class="col-lg-6">
                              <div style="margin-bottom:35px;text-align:center">
                                
                                   <input type="email" name="u_email" id="u_email" class="form-control" 
                                   placeholder="Please Enter your Email" />
                                 
                                 
                                                               
                             </div>
                            </div>
                            <div class="col-lg-3">
                            </div>
                          </div>  
                         
                          <div class="row">
                             <div class="col-lg-3">
                             </div>
                             <div class="col-lg-6">
                              <div style="margin-bottom:35px;text-align:center">
                                
                                   <input type="password" name="u_pswd" id="u_pswd" class="form-control" 
                                   placeholder="Please Enter your Password" required />
                                
                             </div>
                            </div>
                            <div class="col-lg-3">
                            </div>
                          </div>  
                          
                          <div class="row">
                             <div class="col-lg-7">
                             <a class="regButton" style="float: right; margin-top: 10px;" href ="/signup.php">Register</a>
                             </div>
                             <div class="col-lg-2">
                              <div style="margin-bottom:35px;text-align:center">
                                   <input type="submit" name="submit" id="submit" value="Login" class="btn btn-xl"/>
                                
                             </div>
                            </div>
                            <div class="col-lg-3">
                            </div>
                          </div>  
                          
                          
                        </div>
  		           </div>
		    </div>	  
     </form>     
    </section>
        <!-- END FEATURES -->
		
     
		


      
        
<!---Footer Section-->
<?php include("includes/footer.php"); ?>
<!-- /END Footer -->
        <!-- END FOOTER -->        
        
        
  <!-- SCRIPTS -->
        <!-- jQuery -->
        <script src="js/jquery-1.12.3.min.js"></script>
        <!-- Easing -->		
        <script src="js/jquery.easing.min.js"></script>
        <!-- Bootstrap -->		
        <script src="js/bootstrap.min.js"></script>
        <!-- smoothscroll  -->
        <script src="js/smoothscroll.js"></script>
        <!-- piechart  -->
        <script src="js/jquery.easytabs.min.js"></script>
        <!-- sliders -->
        <script src="js/owl.carousel.min.js"></script>
		 <!-- counterup -->
		<script src="js/jquery.countTo.js"></script>
		 <!-- wow js -->
		<script src="js/wow.min.js"></script>
        <!-- contact form -->
        <script src="js/jqBootstrapValidation.js"></script>
        <script src="js/contact_me.js"></script>
        <!-- google map -->
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
        <!-- custom script -->
        <script src="js/scripts.js"></script>
        <style>
			.regButton:hover {
				color:#337ab7;
			}
		</style>
</body>
</html>

<?php mysql_close($conection);  ?>
