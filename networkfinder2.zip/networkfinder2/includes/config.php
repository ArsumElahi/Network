<?php 
session_start();
error_reporting(0);
	
	$host="localhost";
	$user="c2fdb";
	$password="pakistan";
	$database="availabilityengine";
	
	$conection=mysql_connect($host,$user,$password);
    mysql_select_db($database,$conection) or die(mysql_error());
	
	
	?>
