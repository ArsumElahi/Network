<footer id="footer-section">
    <div class="footer-bg">
	   <div class="container">
	   	<div class="row">
	   		<div class="col-lg-12">
			  <div class="footer-part">
	   			<div class="logo">
				  <img src="//p6.zdassets.com/hc/settings_assets/1086441/200323487/t1xK5wLNxfHtRXum4xBEUA-SmallLogo.png" alt="Logo" />
				  
	   				<div class="footer-header">
					  <h6> &copy; 2016 - <span>Connected2Fiber </span>  All rights reserved.</h6>
					  
	   					<div class="social-list">
						 <a href="https://www.facebook.com/connected2fiber"><i class="fa fa-facebook"></i></a>
						 <a href="http://www.twitter.com/connected2fiber"><i class="fa fa-twitter"></i></a>
						 <a href="https://plus.google.com/112831127646763053299"><i class="fa fa-google-plus"></i></a>
						 <a href="https://www.linkedin.com/company/connected2fiber"><i class="fa fa-linkedin"></i></a>
						</div>
	   				  </div>
				  </div>
	   			</div>
	   		 </div>
	   	 </div>
	   </div>
	</div> 
</footer>  
